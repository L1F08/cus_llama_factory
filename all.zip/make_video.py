
"""
视频生成模块
从图片序列生成时间对齐的前后摄像头视频
支持批次格式的采样文件
"""
import argparse
import bisect
import json
import cv2
from pathlib import Path
from typing import List, Dict, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

from utils import (
    ConfigManager, setup_logger, check_video_exists,
    get_image_timestamps, ensure_dir, sample_from_source
)


class VideoMaker:
    """视频生成器"""
    
    def __init__(self, config: ConfigManager, dataset_name: str):
        self.config = config
        self.dataset_name = dataset_name
        self.dataset_config = config.get_dataset_config(dataset_name)
        
        # 路径配置
        self.cache_root = Path(config.get("paths", "cache_root"))
        self.front_video_dir = Path(config.get("paths", "front_video_dir"))
        self.back_video_dir = Path(config.get("paths", "back_video_dir"))
        self.data_dir = Path(config.get("paths", "data_dir"))
        
        # 确保输出目录存在
        ensure_dir(self.front_video_dir)
        ensure_dir(self.back_video_dir)
        
        # 摄像头配置
        self.front_camera = config.get("cameras", "front", "name")
        self.back_camera = config.get("cameras", "back", "name")
        # --- 新增 ---
        self.use_cameras = config.get("cameras", "use_cameras", default=["front", "back"])

        # 动态加载并确保输出目录存在
        self.cam_configs = {}
        for cam in self.use_cameras:
            video_dir = Path(config.get("paths", f"{cam}_video_dir"))
            ensure_dir(video_dir)
            self.cam_configs[cam] = {
                "name": config.get("cameras", cam, "name"),
                "video_dir": video_dir
            }
        # 视频质量配置
        self.fps = config.get("video_quality", "fps")
        self.frame_interval = config.get("video_quality", "frame_interval")
        
        # 处理配置
        self.max_workers = config.get("processing", "max_workers")
        
        # 设置日志
        output_dir = self.data_dir / self.dataset_config["name"]
        ensure_dir(output_dir)
        self.logger = setup_logger(
            "VideoMaker",
            log_file=output_dir / "make_video.log"
        )
        
        self.failed_log = output_dir / "make_video_failed_ids.txt"
    
    def _load_all_autoscene_ids(self) -> List[Dict]:
        """加载所有autoscene_id（优先读取采样文件，兼容批次格式）"""
        # 检查是否存在采样文件
        output_dir = self.data_dir / self.dataset_config["name"]
        sampled_ids_file = output_dir / "sampled_autoscene_ids.json"
        
        if sampled_ids_file.exists():
            # 读取采样文件
            self.logger.info(f"📂 读取采样文件: {sampled_ids_file}")
            with open(sampled_ids_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # ========== 兼容新旧格式 ==========
            if isinstance(data, list):
                # 旧格式：列表
                samples = data
                self.logger.info(f"✅ 从采样文件加载 {len(samples)} 个样本（旧格式）")
            elif isinstance(data, dict):
                # 新格式：字典（批次）
                samples = []
                for batch in data.get("batches", []):
                    batch_samples = batch.get("samples", [])
                    samples.extend(batch_samples)
                    self.logger.info(
                        f"✅ 批次 {batch['batch_id']}: "
                        f"{len(batch_samples)} 个样本"
                    )
                self.logger.info(f"✅ 总计: {len(samples)} 个样本")
            else:
                self.logger.error("未知的采样文件格式")
                samples = []
            # ================================
            
            return samples
        else:
            # 如果没有采样文件，按原逻辑采样
            self.logger.warning(
                f"⚠️ 采样文件不存在: {sampled_ids_file}\n"
                "   将重新采样（可能与 download 阶段不一致）"
            )
            
            all_samples = []
            
            for class_cfg in self.dataset_config["classes"]:
                label = class_cfg["label"]
                label_description = class_cfg.get("description", f"Label {label}")
                
                for source in class_cfg["sources"]:
                    # 使用通用采样函数
                    source_samples = sample_from_source(
                        source, label, label_description, self.logger
                    )
                    all_samples.extend(source_samples)
            
            return all_samples
    
    # def _filter_existing_videos(self, samples: List[Dict]) -> List[Dict]:
    #     """过滤已存在视频的样本"""
    #     filtered = []
    #     skipped = 0
        
    #     for sample in samples:
    #         aid = sample["autoscene_id"]
    #         front_exists = check_video_exists(self.front_video_dir, aid)
    #         back_exists = check_video_exists(self.back_video_dir, aid)
            
    #         if front_exists and back_exists:
    #             skipped += 1
    #         else:
    #             filtered.append(sample)
        
    #     if skipped > 0:
    #         self.logger.info(f"跳过 {skipped} 个已存在视频的样本")
        
    #     return filtered
    def _filter_existing_videos(self, samples: List[Dict]) -> List[Dict]:
        """过滤已存在视频的样本"""
        filtered = []
        skipped = 0
        
        for sample in samples:
            aid = sample["autoscene_id"]
            # 动态检查所有配置的摄像头视频是否已全部存在
            all_exist = all(
                check_video_exists(cam_info["video_dir"], aid)
                for cam_info in self.cam_configs.values()
            )

            if all_exist:
                skipped += 1
            else:
                filtered.append(sample)
        
        if skipped > 0:
            self.logger.info(f"跳过 {skipped} 个已存在视频的样本")
        
        return filtered
    def _create_video_from_images(
        self,
        image_timestamps: List[Tuple[str, float]],
        image_dir: Path,
        output_path: Path
    ) -> bool:
        """从图片时间戳列表创建视频"""
        if not image_timestamps:
            return False
        
        # 读取第一帧获取尺寸
        first_img_path = image_dir / image_timestamps[0][0]
        first_frame = cv2.imread(str(first_img_path))
        if first_frame is None:
            self.logger.error(f"无法读取首帧: {first_img_path}")
            return False
        
        height, width = first_frame.shape[:2]
        
        # 创建视频写入器
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        video = cv2.VideoWriter(
            str(output_path),
            fourcc,
            self.fps,
            (width, height)
        )
        
        # 时间戳水印配置
        font_face = cv2.FONT_HERSHEY_SIMPLEX
        time_text_scale = 5
        color = (255, 255, 255)
        thickness = 11
        line_type = cv2.LINE_AA
        margin = 120
        
        start_time = image_timestamps[0][1]
        success_count = 0
        
        for img_name, timestamp in image_timestamps:
            img_path = image_dir / img_name
            frame = cv2.imread(str(img_path))
            
            # if frame is None:
            #     self.logger.warning(f"跳过损坏图片: {img_name}")
            #     continue
            if frame is None:
                self.logger.error(f"发现损坏图片: {img_name}，直接废弃该视频")
                # 1. 释放视频写入器
                video.release()
                # 2. 删除已经创建的半成品/空壳视频文件
                if output_path.exists():
                    output_path.unlink()
                # 3. 返回失败，该样本将被记录到 failed_ids 中
                return False
            # --- 将添加时间戳的代码注释掉 ---
            # rel_time = timestamp - start_time
            # time_text = f"+{rel_time:.2f}s"
            # cv2.putText(
            #     frame, time_text, (margin, margin),
            #     font_face, time_text_scale, color, thickness, line_type
            # )
            # ------------------------------
            
            video.write(frame)
            success_count += 1
        
        video.release()
        return success_count > 0
    
    # def _make_aligned_videos(self, sample: Dict) -> Dict:
    #     """生成长度对齐的前后视频"""
    #     autoscene_id = sample["autoscene_id"]
        
    #     # 图片目录
    #     cache_dir = self.cache_root / f"autoscenes_{autoscene_id}" / autoscene_id
    #     front_image_dir = cache_dir / "samples" / self.front_camera
    #     back_image_dir = cache_dir / "samples" / self.back_camera
        
    #     # 视频输出路径
    #     front_video_path = self.front_video_dir / f"{autoscene_id}.mp4"
    #     back_video_path = self.back_video_dir / f"{autoscene_id}.mp4"
        
    #     try:
    #         # 检查图片目录
    #         if not front_image_dir.exists():
    #             return {
    #                 "success": False,
    #                 "autoscene_id": autoscene_id,
    #                 "reason": "front_image_dir_not_exist"
    #             }
            
    #         if not back_image_dir.exists():
    #             return {
    #                 "success": False,
    #                 "autoscene_id": autoscene_id,
    #                 "reason": "back_image_dir_not_exist"
    #             }
            
    #         # 获取时间戳
    #         front_timestamps = get_image_timestamps(str(front_image_dir))
    #         back_timestamps = get_image_timestamps(str(back_image_dir))
            
    #         if not front_timestamps or not back_timestamps:
    #             return {
    #                 "success": False,
    #                 "autoscene_id": autoscene_id,
    #                 "reason": "no_valid_timestamps"
    #             }
            
    #         # 排序并按间隔抽取
    #         front_timestamps.sort(key=lambda x: x[1])
    #         back_timestamps.sort(key=lambda x: x[1])
            
    #         if self.frame_interval > 1:
    #             front_timestamps = front_timestamps[::int(self.frame_interval)]
    #             back_timestamps = back_timestamps[::int(self.frame_interval)]
            
    #         # 裁剪到相同长度
    #         min_length = min(len(front_timestamps), len(back_timestamps))
    #         front_timestamps = front_timestamps[:min_length]
    #         back_timestamps = back_timestamps[:min_length]
            
    #         # 生成前视视频
    #         if not front_video_path.exists():
    #             if not self._create_video_from_images(
    #                 front_timestamps,
    #                 front_image_dir,
    #                 front_video_path
    #             ):
    #                 return {
    #                     "success": False,
    #                     "autoscene_id": autoscene_id,
    #                     "reason": "front_video_creation_failed"
    #                 }
            
    #         # 生成后视视频
    #         if not back_video_path.exists():
    #             if not self._create_video_from_images(
    #                 back_timestamps,
    #                 back_image_dir,
    #                 back_video_path
    #             ):
    #                 return {
    #                     "success": False,
    #                     "autoscene_id": autoscene_id,
    #                     "reason": "back_video_creation_failed"
    #                 }
            
    #         return {
    #             "success": True,
    #             "autoscene_id": autoscene_id,
    #             "frame_count": min_length
    #         }
            
    #     except Exception as e:
    #         self.logger.error(f"视频生成失败 [{autoscene_id}]: {e}")
    #         return {
    #             "success": False,
    #             "autoscene_id": autoscene_id,
    #             "reason": str(e)
    #         }
    # def _make_aligned_videos(self, sample: Dict) -> Dict:
    #     """生成长度对齐的视频(动态兼容单/双摄)"""
    #     autoscene_id = sample["autoscene_id"]
    #     cache_dir = self.cache_root / f"autoscenes_{autoscene_id}" / autoscene_id
        
    #     timestamps_dict = {}
        
    #     try:
    #         # 1. 收集需要处理的摄像头数据
    #         if "front" in self.use_cameras:
    #             img_dir = cache_dir / "samples" / self.front_camera
    #             if not img_dir.exists(): return {"success": False, "autoscene_id": autoscene_id, "reason": "front_image_dir_not_exist"}
    #             ts = get_image_timestamps(str(img_dir))
    #             if not ts: return {"success": False, "autoscene_id": autoscene_id, "reason": "no_valid_front_timestamps"}
    #             ts.sort(key=lambda x: x[1])
    #             if self.frame_interval > 1: ts = ts[::int(self.frame_interval)]
    #             timestamps_dict["front"] = {"dir": img_dir, "ts": ts, "out": self.front_video_dir / f"{autoscene_id}.mp4"}
                
    #         if "back" in self.use_cameras:
    #             img_dir = cache_dir / "samples" / self.back_camera
    #             if not img_dir.exists(): return {"success": False, "autoscene_id": autoscene_id, "reason": "back_image_dir_not_exist"}
    #             ts = get_image_timestamps(str(img_dir))
    #             if not ts: return {"success": False, "autoscene_id": autoscene_id, "reason": "no_valid_back_timestamps"}
    #             ts.sort(key=lambda x: x[1])
    #             if self.frame_interval > 1: ts = ts[::int(self.frame_interval)]
    #             timestamps_dict["back"] = {"dir": img_dir, "ts": ts, "out": self.back_video_dir / f"{autoscene_id}.mp4"}
            
    #         if not timestamps_dict:
    #             return {"success": False, "autoscene_id": autoscene_id, "reason": "no_cameras_configured"}
            
    #         # 2. 裁剪到相同长度 (单摄时就是自身长度，双摄时取最小值)
    #         min_length = min([len(data["ts"]) for data in timestamps_dict.values()])
            
    #         # 3. 统一生成视频
    #         for cam, data in timestamps_dict.items():
    #             data["ts"] = data["ts"][:min_length]
    #             if not data["out"].exists():
    #                 if not self._create_video_from_images(data["ts"], data["dir"], data["out"]):
    #                     return {"success": False, "autoscene_id": autoscene_id, "reason": f"{cam}_video_creation_failed"}
            
    #         return {
    #             "success": True,
    #             "autoscene_id": autoscene_id,
    #             "frame_count": min_length
    #         }
            
    #     except Exception as e:
    #         self.logger.error(f"视频生成失败 [{autoscene_id}]: {e}")
    #         return {"success": False, "autoscene_id": autoscene_id, "reason": str(e)}
    def _make_aligned_videos(self, sample: Dict) -> Dict:
        """生成长度对齐的视频(完全动态兼容任意多摄)"""
        autoscene_id = sample["autoscene_id"]
        cache_dir = self.cache_root / f"autoscenes_{autoscene_id}" / autoscene_id
        
        timestamps_dict = {}
        
        try:
            # 1. 动态收集所有需要的摄像头数据
            for cam, cam_info in self.cam_configs.items():
                img_dir = cache_dir / "samples" / cam_info["name"]
                if not img_dir.exists(): 
                    return {"success": False, "autoscene_id": autoscene_id, "reason": f"{cam}_image_dir_not_exist"}
                
                ts = get_image_timestamps(str(img_dir))
                if not ts: 
                    return {"success": False, "autoscene_id": autoscene_id, "reason": f"no_valid_{cam}_timestamps"}
                
                ts.sort(key=lambda x: x[1])
                if self.frame_interval > 1: 
                    ts = ts[::int(self.frame_interval)]
                    
                timestamps_dict[cam] = {
                    "dir": img_dir, "ts": ts, "out": cam_info["video_dir"] / f"{autoscene_id}.mp4"
                }
            
            if not timestamps_dict:
                return {"success": False, "autoscene_id": autoscene_id, "reason": "no_cameras_configured"}
            
            # 2. 计算最大交集时间窗口（所有摄像头都覆盖的公共真实时间段）
            #    t_start = 各路首帧时间戳的最大值；t_end = 各路尾帧时间戳的最小值。
            #    这样所有摄像头视频共享同一个真实时间原点 t_start，下游 get_video_clip
            #    只需一份 crop_start_s 即可对所有摄像头同一刀切片、逐帧对齐。
            t_start = max(data["ts"][0][1] for data in timestamps_dict.values())
            t_end = min(data["ts"][-1][1] for data in timestamps_dict.values())
            if t_end <= t_start:
                return {"success": False, "autoscene_id": autoscene_id, "reason": "no_time_overlap"}

            # 3. 统一时间网格 + 最近邻重采样
            #    网格按 self.fps 取点，保证 1 视频秒 = 1 真实秒（real-time 播放），
            #    各摄像头对每个目标时刻取时间戳最近的那一帧 → 帧数一致、第 k 帧同一真实时刻。
            num_frames = int(round((t_end - t_start) * self.fps)) + 1
            targets = [t_start + k / self.fps for k in range(num_frames)]
            for cam, data in timestamps_dict.items():
                times = [t for _, t in data["ts"]]
                aligned = []
                for tg in targets:
                    j = bisect.bisect_left(times, tg)
                    if j <= 0:
                        idx = 0
                    elif j >= len(times):
                        idx = len(times) - 1
                    else:
                        idx = j if (times[j] - tg) < (tg - times[j - 1]) else j - 1
                    aligned.append(data["ts"][idx])
                data["ts"] = aligned

            # 4. 生成视频（各路帧数相同、第 k 帧对应同一真实时刻）
            for cam, data in timestamps_dict.items():
                if not data["out"].exists():
                    if not self._create_video_from_images(data["ts"], data["dir"], data["out"]):
                        return {"success": False, "autoscene_id": autoscene_id, "reason": f"{cam}_video_creation_failed"}

            return {"success": True, "autoscene_id": autoscene_id, "frame_count": num_frames}
            
        except Exception as e:
            self.logger.error(f"视频生成失败 [{autoscene_id}]: {e}")
            return {"success": False, "autoscene_id": autoscene_id, "reason": str(e)}
            
    def make_all_videos(self):
        """生成所有视频"""
        self.logger.info(f"=" * 70)
        self.logger.info(f"开始生成视频: {self.dataset_name}")
        self.logger.info(f"=" * 70)
        
        # 加载所有ID（兼容批次格式）
        samples = self._load_all_autoscene_ids()
        self.logger.info(f"总计: {len(samples)} 个样本")
        
        # 过滤已存在的视频
        samples = self._filter_existing_videos(samples)
        
        if not samples:
            self.logger.info("所有视频已存在，无需生成")
            return
        
        self.logger.info(f"需要生成: {len(samples)} 个样本")
        
        # 清空失败日志
        self.failed_log.write_text("", encoding="utf-8")
        
        # 多进程生成
        results = []
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self._make_aligned_videos, sample): sample
                for sample in samples
            }
            
            for future in tqdm(
                as_completed(futures),
                total=len(samples),
                desc="生成视频"
            ):
                result = future.result()
                results.append(result)
        
        # 统计结果
        success_count = sum(1 for r in results if r["success"])
        failed_count = len(results) - success_count
        
        # 记录失败ID
        if failed_count > 0:
            with open(self.failed_log, 'w', encoding='utf-8') as f:
                for r in results:
                    if not r["success"]:
                        f.write(
                            f"{r['autoscene_id']} | "
                            f"reason: {r.get('reason', 'unknown')}\n"
                        )
        
        self.logger.info(f"=" * 70)
        self.logger.info(f"视频生成完成: 成功 {success_count}, 失败 {failed_count}")
        self.logger.info(f"失败记录: {self.failed_log}")
        self.logger.info(f"=" * 70)


def main():
    parser = argparse.ArgumentParser(description="生成对齐的前后摄像头视频")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    
    args = parser.parse_args()
    
    config = ConfigManager(args.config)
    maker = VideoMaker(config, args.dataset)
    maker.make_all_videos()


if __name__ == "__main__":
    main()