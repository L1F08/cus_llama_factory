
"""
图片下载模块
从存储桶下载autoscene的前后摄像头图片序列
支持智能补充模式：自动检测需要补充的类别
"""
import argparse
import json
import random
from pathlib import Path
from typing import List, Dict, Set
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from datetime import datetime

from utils import (
    ConfigManager, setup_logger, load_autoscene_list,
    check_video_exists, ensure_dir, sample_from_source
)


class ImageDownloader:
    """图片下载器（智能补充版）"""
    
    def __init__(self, config: ConfigManager, dataset_name: str, retry_failed: bool = False):
        self.config = config
        self.retry_failed = retry_failed  # 记录是否开启重试
        self.dataset_name = dataset_name
        self.dataset_config = config.get_dataset_config(dataset_name)
        
        # 路径配置
        self.cache_root = Path(config.get("paths", "cache_root"))
        self.front_video_dir = Path(config.get("paths", "front_video_dir"))
        self.back_video_dir = Path(config.get("paths", "back_video_dir"))
        self.data_dir = Path(config.get("paths", "data_dir"))
        
        # 存储桶配置 - 同时加载贵阳和yd的配置
        self.yw_bucket_url = config.get("storage", "guiyang", "url")
        self.yw_ak = config.get("storage", "guiyang", "ak")
        self.yw_sk = config.get("storage", "guiyang", "sk")
        
        self.yd_bucket_url = config.get("storage", "yd", "url")
        self.yd_ak = config.get("storage", "yd", "ak")
        self.yd_sk = config.get("storage", "yd", "sk")
        
        # 摄像头配置
        self.front_camera = config.get("cameras", "front", "name")
        self.back_camera = config.get("cameras", "back", "name")
        # --- 新增读取 use_cameras 配置 ---
        self.use_cameras = config.get("cameras", "use_cameras", default=["front", "back"])
        self.cam_configs = {}
        for cam in self.use_cameras:
            self.cam_configs[cam] = {
                "name": config.get("cameras", cam, "name"),
                "video_dir": Path(config.get("paths", f"{cam}_video_dir"))
            }
        # 处理配置
        self.max_workers = config.get("processing", "max_workers")
        
        # 设置日志
        output_dir = self.data_dir / self.dataset_config["name"]
        ensure_dir(output_dir)
        self.logger = setup_logger(
            "ImageDownloader",
            log_file=output_dir / "download_images.log"
        )
        
        # 文件路径
        self.sampled_ids_file = output_dir / "sampled_autoscene_ids.json"
        self.scan_report_file = output_dir / "video_scan_report.json"
        self.failed_log = output_dir / "download_failed_ids.txt"

        # 读取配置并固定全局随机种子
        self.seed = config.get("processing", "seed")
        random.seed(self.seed)
        self.logger.info(f"已固定随机种子为: {self.seed}")
        
        self.logger.info("初始化下载器: 智能补充模式")
    
    def _load_scan_report(self) -> Dict:
        """加载扫描报告"""
        if not self.scan_report_file.exists():
            return None
        
        try:
            with open(self.scan_report_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"加载扫描报告失败: {e}")
            return None
    
    def _get_valid_counts_by_label(self, scan_report: Dict) -> Dict[int, int]:
        """从扫描报告获取每个类别的有效样本数"""
        valid_counts = {}
        
        if not scan_report:
            return valid_counts
        
        by_label = scan_report.get("by_label", {})
        
        for label_str, stats in by_label.items():
            label = int(label_str)
            valid_counts[label] = stats.get("valid", 0)
        
        return valid_counts
    
    def _determine_supplement_needs(self) -> Dict[int, int]:
        """
        决定每个类别是否需要补充，以及需要补充多少
        
        Returns:
            {label: need_count}
        """
        supplement_needs = {}
        
        # 加载扫描报告
        scan_report = self._load_scan_report()
        
        if not scan_report:
            self.logger.info("⚠️  未找到扫描报告，将下载所有配置的类别")
            # 返回配置中的所有类别
            for class_cfg in self.dataset_config["classes"]:
                label = class_cfg["label"]
                target = sum(s.get("sample_count", 0) for s in class_cfg["sources"])
                supplement_needs[label] = target
            return supplement_needs
        
        # 获取已有的有效样本数
        valid_counts = self._get_valid_counts_by_label(scan_report)
        
        self.logger.info(f"\n{'='*70}")
        self.logger.info(f"智能补充分析")
        self.logger.info(f"{'='*70}")
        
        # 分析每个类别
        for class_cfg in self.dataset_config["classes"]:
            label = class_cfg["label"]
            description = class_cfg.get("description", f"Label {label}")
            
            # 配置的目标数量
            target_count = sum(s.get("sample_count", 0) for s in class_cfg["sources"])
            
            # 当前有效数量
            current_valid = valid_counts.get(label, 0)
            
            # 判断是否需要补充
            if current_valid >= target_count:
                self.logger.info(
                    f"✅ 类别 {label} ({description}): "
                    f"有效 {current_valid}/{target_count} - 已达标，跳过"
                )
                supplement_needs[label] = 0
            else:
                need_count = target_count - current_valid
                self.logger.info(
                    f"📥 类别 {label} ({description}): "
                    f"有效 {current_valid}/{target_count} - "
                    f"需补充 {need_count} 个"
                )
                supplement_needs[label] = need_count
        
        self.logger.info(f"{'='*70}\n")
        
        return supplement_needs
    
    def _load_existing_samples(self) -> Dict:
        """加载已存在的采样记录"""
        if not self.sampled_ids_file.exists():
            return {
                "dataset_name": self.dataset_config["name"],
                "created_at": datetime.now().isoformat(),
                "batches": [],
                "total_samples": 0,
                "by_label": {}
            }
        
        try:
            with open(self.sampled_ids_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # ========== 兼容旧格式 ==========
            if isinstance(data, list):
                # 旧格式：列表
                self.logger.info("检测到旧格式采样文件，自动转换为新格式")
                
                # 统计类别
                by_label = {}
                for sample in data:
                    label = str(sample.get("label", "unknown"))
                    by_label[label] = by_label.get(label, 0) + 1
                
                return {
                    "dataset_name": self.dataset_config["name"],
                    "created_at": "unknown",
                    "last_updated": datetime.now().isoformat(),
                    "batches": [{
                        "batch_id": 1,
                        "timestamp": "unknown",
                        "total_samples": len(data),
                        "samples": data
                    }],
                    "total_samples": len(data),
                    "by_label": by_label
                }
            # ==============================
            
            return data
            
        except Exception as e:
            self.logger.error(f"加载采样文件失败: {e}")
            return {
                "dataset_name": self.dataset_config["name"],
                "created_at": datetime.now().isoformat(),
                "batches": [],
                "total_samples": 0,
                "by_label": {}
            }
            
    def _load_failed_ids(self) -> Set[str]:
        """加载需要重试的失败ID (仅提取 make_video 阶段 no_valid_front_timestamps 的数据)"""
        # 定义 make_video 失败日志的路径
        output_dir = self.data_dir / self.dataset_config["name"]
        make_video_failed_log = output_dir / "make_video_failed_ids.txt"
        
        valid_retry_ids = set()
        
        if not make_video_failed_log.exists():
            return valid_retry_ids
            
        try:
            with open(make_video_failed_log, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                        
                    # 解析 "ID | reason: xxx" 的格式
                    if " | reason: " in line:
                        parts = line.split(" | reason: ")
                        aid = parts[0].strip()
                        reason = parts[1].strip()
                        
                        # 核心过滤逻辑：只有当 reason 是这个指定错误时，才加入重试池
                        if reason == "front_image_dir_not_exist":
                            valid_retry_ids.add(aid)
                    else:
                        # 如果有旧格式只写了 ID，你可以选择忽略或者默认加入
                        # 这里我们严格一点，只处理带明确 reason 且符合要求的
                        pass
                        
            if valid_retry_ids:
                self.logger.info(f"🔍 从 make_video 错误日志中筛选出 {len(valid_retry_ids)} 个因时间戳缺失的样本待重试")
                
            return valid_retry_ids
            
        except Exception as e:
            self.logger.error(f"读取视频生成失败日志失败: {e}")
            return set()
    def _get_failed_samples(self, failed_ids: Set[str], existing_data: Dict) -> List[Dict]:
        """从已有采样数据中提取失败的样本信息"""
        failed_samples = []
        seen = set()
        for batch in existing_data.get("batches", []):
            for sample in batch.get("samples", []):
                aid = sample["autoscene_id"]
                if aid in failed_ids and aid not in seen:
                    failed_samples.append(sample)
                    seen.add(aid)
        return failed_samples
        
    def _get_existing_ids(self, existing_data: Dict) -> Set[str]:
        """从已存在的数据中提取所有ID"""
        existing_ids = set()
        
        for batch in existing_data.get("batches", []):
            for sample in batch.get("samples", []):
                existing_ids.add(sample["autoscene_id"])
        
        return existing_ids
    
    def _smart_sample(self, supplement_needs: Dict[int, int]) -> List[Dict]:
        """
        智能采样：只采样需要补充的类别
        
        Args:
            supplement_needs: {label: need_count}
        
        Returns:
            采样结果列表
        """
        all_samples = []
        
        # 加载已有的ID (来自之前已下载的批次)
        existing_data = self._load_existing_samples()
        existing_ids = self._get_existing_ids(existing_data)
        
        self.logger.info(f"已存在 {len(existing_ids)} 个历史采样ID")

        # ==================== 新增：加载训练集需要排除的ID ====================
        exclude_path = self.dataset_config.get("exclude_train_json")
        if exclude_path:
            exclude_file = Path(exclude_path)
            if exclude_file.exists():
                try:
                    with open(exclude_file, 'r', encoding='utf-8') as f:
                        train_data = json.load(f)
                    
                    train_ids_count = 0
                    for item in train_data:
                        # 训练集的JSON结构中，ID通常在 video_path 的文件名里
                        if "videos" in item and len(item["videos"]) > 0:
                            video_path = item["videos"][0]
                            # 提取不含扩展名的文件名作为 autoscene_id
                            full_name = Path(video_path).stem
                            # autoscene_id = full_name[:32]
                            autoscene_id = full_name.split('_')[0]
                            # autoscene_id = Path(video_path).stem 
                            
                            if autoscene_id not in existing_ids:
                                existing_ids.add(autoscene_id)
                                train_ids_count += 1
                                
                    self.logger.info(f"✅ 从 exclude_train_json 额外排除了 {train_ids_count} 个训练集ID")
                except Exception as e:
                    self.logger.error(f"加载 exclude_train_json 失败: {e}")
            else:
                self.logger.warning(f"⚠️ 配置了 exclude_train_json 但文件不存在: {exclude_file}")
        # ======================================================================

        self.logger.info(f"总计有 {len(existing_ids)} 个ID将被排除（不参与本次抽样）")
        
        for class_cfg in self.dataset_config["classes"]:
            label = class_cfg["label"]
            description = class_cfg.get("description", f"Label {label}")
            need_count = supplement_needs.get(label, 0)
            
            if need_count <= 0:
                # 不需要补充，跳过
                continue
            
            self.logger.info(f"\n采样类别 {label} ({description}):")
            
            # # 从所有source采样
            # label_samples = []
            # for source in class_cfg["sources"]:
            #     source_samples = sample_from_source(
            #         source, label, description, self.logger
            #     )
            #     label_samples.extend(source_samples)
            # 从所有source获取全量数据作为候选池
            label_samples = []
            seen_in_this_label = set()
            for source in class_cfg["sources"]:
                # 临时将 sample_count 覆盖为 -1，强制提取 CSV 中的所有数据
                original_count = source.get("sample_count")
                source["sample_count"] = -1 
                
                source_samples = sample_from_source(
                    source, label, description, self.logger
                )
                for s in source_samples:
                    if s["autoscene_id"] not in seen_in_this_label:
                        label_samples.append(s)
                        seen_in_this_label.add(s["autoscene_id"])
                # 恢复原有的配置（避免影响后续其他逻辑）
                if original_count is not None:
                    source["sample_count"] = original_count
                else:
                    del source["sample_count"]
                    
                label_samples.extend(source_samples)
            
            # ========== 排除已有ID和训练集ID ==========
            before_count = len(label_samples)
            label_samples = [
                s for s in label_samples 
                if s["autoscene_id"] not in existing_ids
            ]
            after_count = len(label_samples)
            
            self.logger.info(f"  原始采样: {before_count} 个")
            self.logger.info(f"  排除已有/训练集: {before_count - after_count} 个")
            self.logger.info(f"  可用样本: {after_count} 个")
            # ===============================
            
            # ========== 判断是否足够 ==========
            if after_count < need_count:
                self.logger.warning(
                    f"  ⚠️  可用样本不足！需要 {need_count} 个，"
                    f"只有 {after_count} 个"
                )
                # 全部使用
                selected = label_samples
            else:
                # 随机采样需要的数量
                selected = random.sample(label_samples, need_count)
            
            self.logger.info(f"  ✅ 实际采样: {len(selected)} 个")
            # ================================
            
            all_samples.extend(selected)
        
        return all_samples
    
    def _save_samples(self, new_samples: List[Dict], existing_data: Dict):
        """保存采样结果（追加模式）"""
        # ========== 追加批次 ==========
        batch_id = len(existing_data["batches"]) + 1
        
        new_batch = {
            "batch_id": batch_id,
            "timestamp": datetime.now().isoformat(),
            "total_samples": len(new_samples),
            "samples": new_samples
        }
        
        existing_data["batches"].append(new_batch)
        existing_data["last_updated"] = datetime.now().isoformat()
        existing_data["total_samples"] += len(new_samples)
        
        # 更新类别统计
        for sample in new_samples:
            label = str(sample["label"])
            existing_data["by_label"][label] = \
                existing_data["by_label"].get(label, 0) + 1
        
        with open(self.sampled_ids_file, 'w', encoding='utf-8') as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=2)
        
        self.logger.info(
            f"✅ 追加保存: 批次 {batch_id}，新增 {len(new_samples)} 个样本"
        )
        self.logger.info(f"   总样本数: {existing_data['total_samples']}")
        # ==============================
    
    # def _filter_existing_videos(self, samples: List[Dict]) -> List[Dict]:
    #     """过滤已存在视频的样本"""
    #     filtered = []
    #     skipped = 0
        
    #     for sample in samples:
    #         aid = sample["autoscene_id"]
    #         front_exists = check_video_exists(self.front_video_dir, aid)
    #         back_exists = check_video_exists(self.back_video_dir, aid)
            
    #         if front_exists and back_exists:
    #             skipped += 1
    #         else:
    #             filtered.append(sample)
        
    #     if skipped > 0:
    #         self.logger.info(f"跳过 {skipped} 个已存在视频的样本")
        
    #     return filtered
    # def _filter_existing_videos(self, samples: List[Dict]) -> List[Dict]:
    #     """过滤已存在视频的样本"""
    #     filtered = []
    #     skipped = 0
        
    #     for sample in samples:
    #         aid = sample["autoscene_id"]
    #         # 动态检查所需摄像头视频是否存在
    #         front_exists = check_video_exists(self.front_video_dir, aid) if "front" in self.use_cameras else True
    #         back_exists = check_video_exists(self.back_video_dir, aid) if "back" in self.use_cameras else True
            
    #         if front_exists and back_exists:
    #             skipped += 1
    #         else:
    #             filtered.append(sample)
        
    #     if skipped > 0:
    #         self.logger.info(f"跳过 {skipped} 个已存在视频的样本")
        
    #     return filtered
    def _filter_existing_videos(self, samples: List[Dict]) -> List[Dict]:
        filtered = []
        skipped = 0
        
        for sample in samples:
            aid = sample["autoscene_id"]
            # 动态检查所有配置的摄像头视频是否已全部存在
            all_exist = True
            for cam, cam_info in self.cam_configs.items():
                if not check_video_exists(cam_info["video_dir"], aid):
                    all_exist = False
                    break
            
            if all_exist:
                skipped += 1
            else:
                filtered.append(sample)
                
        if skipped > 0:
            self.logger.info(f"跳过 {skipped} 个已存在视频的样本")
        return filtered
    def _download_single(self, sample: Dict) -> Dict:
        """下载单个autoscene的图片"""
        from download_data import (
            download_autoscenes_data_by_devkit,
            remove_redundant_autoscenes_file
        )
        
        autoscene_id = sample["autoscene_id"]
        cache_dir = self.cache_root / f"autoscenes_{autoscene_id}"
        
        # camera_paths = [
        #     f"samples/{self.front_camera}",
        #     f"samples/{self.back_camera}"
        # ]
        # --- 修改后 ---
        # camera_paths = []
        # if "front" in self.use_cameras:
        #     camera_paths.append(f"samples/{self.front_camera}")
        # if "back" in self.use_cameras:
        #     camera_paths.append(f"samples/{self.back_camera}")
        # 动态组装所需拉取的底层数据路径
        camera_paths = [f"samples/{cam_info['name']}" for cam_info in self.cam_configs.values()]
        try:
            success = download_autoscenes_data_by_devkit(
                autoscene_id,
                camera_paths,
                cache_dir,
                self.config.get("processing", "is_guiyang"),
                yw_bucket_url=self.yw_bucket_url,
                yw_ak=self.yw_ak,
                yw_sk=self.yw_sk,
                yd_bucket_url=self.yd_bucket_url,
                yd_ak=self.yd_ak,
                yd_sk=self.yd_sk,
            )
            
            if not success:
                return {"success": False, "autoscene_id": autoscene_id}
            
            # 清理冗余文件
            # keep_dirs = {
            #     f"samples/{self.front_camera}",
            #     f"samples/{self.back_camera}",
            #     "archive"
            # }
            # remove_redundant_autoscenes_file(
            #     cache_dir / autoscene_id,
            #     keep_dirs
            # )
            # --- 修改后 ---
            keep_dirs = set(camera_paths)
            keep_dirs.add("archive")
            
            remove_redundant_autoscenes_file(
                cache_dir / autoscene_id,
                keep_dirs
            )
            return {"success": True, "autoscene_id": autoscene_id}
            
        except Exception as e:
            self.logger.error(f"下载失败 [{autoscene_id}]: {e}")
            return {"success": False, "autoscene_id": autoscene_id}
    
    # def download_all(self):
    #     """下载所有图片（智能补充模式）"""
    #     self.logger.info(f"=" * 70)
    #     self.logger.info(f"开始下载数据集: {self.dataset_name}")
    #     self.logger.info(f"模式: 智能补充")
    #     self.logger.info(f"=" * 70)
        
    #     # ========== 智能补充模式 ==========
    #     # 1. 分析补充需求
    #     supplement_needs = self._determine_supplement_needs()
        
    #     # 2. 检查是否有需要补充的类别
    #     total_need = sum(supplement_needs.values())
        
    #     if total_need == 0:
    #         self.logger.info("✅ 所有类别已达标，无需下载")
    #         return
        
    #     self.logger.info(f"需要补充 {total_need} 个样本")
        
    #     # 3. 智能采样
    #     samples = self._smart_sample(supplement_needs)
        
    #     if not samples:
    #         self.logger.info("⚠️  没有可用的样本（可能CSV中ID不足或全部已存在）")
    #         return
        
    #     self.logger.info(f"实际采样: {len(samples)} 个样本")
    #     # ================================
        
    #     # 保存采样结果（追加模式）
    #     existing_data = self._load_existing_samples()
    #     self._save_samples(samples, existing_data)
        
    #     # 过滤已存在的视频
    #     samples = self._filter_existing_videos(samples)
        
    #     if not samples:
    #         self.logger.info("所有视频已存在，无需下载")
    #         return
        
    #     self.logger.info(f"需要下载: {len(samples)} 个样本")
        
    #     # 清空失败日志
    #     self.failed_log.write_text("", encoding="utf-8")
        
    #     # 多进程下载
    #     results = []
    #     with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
    #         futures = {
    #             executor.submit(self._download_single, sample): sample
    #             for sample in samples
    #         }
            
    #         for future in tqdm(
    #             as_completed(futures),
    #             total=len(samples),
    #             desc="下载图片"
    #         ):
    #             result = future.result()
    #             results.append(result)
        
    #     # 统计结果
    #     success_count = sum(1 for r in results if r["success"])
    #     failed_count = len(results) - success_count
        
    #     # 记录失败ID
    #     if failed_count > 0:
    #         with open(self.failed_log, 'w', encoding='utf-8') as f:
    #             for r in results:
    #                 if not r["success"]:
    #                     f.write(f"{r['autoscene_id']}\n")
        
    #     self.logger.info(f"=" * 70)
    #     self.logger.info(f"下载完成: 成功 {success_count}, 失败 {failed_count}")
    #     self.logger.info(f"智能补充: 本批次新增 {success_count} 个样本")
    #     self.logger.info(f"失败记录: {self.failed_log}")
    #     self.logger.info(f"=" * 70)
    def download_all(self):
        """下载所有图片（智能补充 + 失败重试模式）"""
        self.logger.info(f"=" * 70)
        self.logger.info(f"开始下载数据集: {self.dataset_name}")
        self.logger.info(f"模式: 智能补充 + 失败重试")
        self.logger.info(f"=" * 70)
        
        # ========== 1. 分析补充需求 ==========
        supplement_needs = self._determine_supplement_needs()
        
        # ========== 2. 提取需要重试的失败样本 ==========
        retry_samples = []
        failed_ids = self._load_failed_ids()
        existing_data = self._load_existing_samples()
        # 只有在开启了 retry_failed 开关时，才去读取失败日志
        if self.retry_failed:
            failed_ids = self._load_failed_ids()
            existing_data = self._load_existing_samples()
            
            if failed_ids:
                all_failed_samples = self._get_failed_samples(failed_ids, existing_data)
                
                for sample in all_failed_samples:
                    label = sample["label"]
                    if supplement_needs.get(label, 0) > 0:
                        retry_samples.append(sample)
                        supplement_needs[label] -= 1
                        
                if retry_samples:
                    self.logger.info(f"🔄 发现 {len(retry_samples)} 个相关的失败样本，优先进行重试")
        else:
            self.logger.info("⏩ 未开启失败重试 (--retry-failed)，将全部从源数据中抽取全新样本")
        # ===============================================

        total_need = sum(supplement_needs.values())
        
        if total_need == 0 and not retry_samples:
            self.logger.info("✅ 所有类别已达标，且无相关失败任务需重试，无需下载")
            return
        
        if total_need > 0:
            self.logger.info(f"除了重试的样本外，还需要全新补充 {total_need} 个样本")
        
        # ========== 3. 智能采样获取全新样本 ==========
        new_samples = []
        if total_need > 0:
            new_samples = self._smart_sample(supplement_needs)
            if new_samples:
                self.logger.info(f"实际全新采样: {len(new_samples)} 个样本")
                # 只有新样本才需要追加保存到 JSON 中！(重试的样本已经在里面了)
                self._save_samples(new_samples, existing_data)
        
        # 合并新样本和重试样本
        samples = new_samples + retry_samples
        
        if not samples:
            self.logger.info("⚠️  没有可用的样本")
            return
        # ===============================================
        
        # 过滤已存在的视频
        samples = self._filter_existing_videos(samples)
        
        if not samples:
            self.logger.info("所有视频已存在，无需下载")
            return
        
        self.logger.info(f"最终实际需要发出下载请求: {len(samples)} 个样本")
        
        # 清空失败日志 (准备记录新的一批失败情况)
        self.failed_log.write_text("", encoding="utf-8")
        
        # 多进程下载
        results = []
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self._download_single, sample): sample
                for sample in samples
            }
            
            for future in tqdm(
                as_completed(futures),
                total=len(samples),
                desc="下载图片"
            ):
                result = future.result()
                results.append(result)
        
        # 统计结果
        success_count = sum(1 for r in results if r["success"])
        failed_count = len(results) - success_count
        
        # 记录失败ID
        if failed_count > 0:
            with open(self.failed_log, 'w', encoding='utf-8') as f:
                for r in results:
                    if not r["success"]:
                        f.write(f"{r['autoscene_id']}\n")
        
        self.logger.info(f"=" * 70)
        self.logger.info(f"下载完成: 成功 {success_count}, 失败 {failed_count}")
        self.logger.info(f"本批次成功获取 {success_count} 个样本")
        self.logger.info(f"失败记录已更新: {self.failed_log}")
        self.logger.info(f"=" * 70)

def main():
    parser = argparse.ArgumentParser(description="下载autoscene图片（智能补充模式）")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    # 在 parser.add_argument("--config", ...) 下方增加：
    parser.add_argument(
        "--retry-failed",
        action="store_true",
        help="是否从 make_video 失败日志中捞取因为缺少时间戳失败的样本进行重试"
    )
    
    # ...
    
    # 实例化时传入参数：
    # runner = ImageDownloader(config, args.dataset, retry_failed=args.retry_failed)
    # runner.download_all()
    args = parser.parse_args()
    
    config = ConfigManager(args.config)
    downloader = ImageDownloader(config, args.dataset)
    downloader.download_all()


if __name__ == "__main__":
    main()