"""
测试集生成脚本
直接从 sampled_autoscene_ids.json 读取ID，排除训练集，生成测试集
不依赖 video_scan_report.json，可以获取所有有效视频（包括大文件/长视频）
"""
import argparse
import json
import random
from pathlib import Path
from typing import List, Dict, Set, Optional
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

from utils import (
    ConfigManager, setup_logger, ensure_dir, extract_autoscene_id,
    get_video_info
)

# 导入车辆信息管理模块
try:
    from ego_info_manager import create_ego_info_manager_from_config, EgoInfoManager
    EGO_INFO_AVAILABLE = True
except ImportError:
    EgoInfoManager = None
    EGO_INFO_AVAILABLE = False


class TestDatasetBuilder:
    """测试集构建器（直接从采样文件构建，不依赖扫描报告）"""
    
    def __init__(self, config: ConfigManager, dataset_name: str,
                 use_cameras=None, use_ego_info=None):
        self.config = config
        self.dataset_name = dataset_name
        self.dataset_config = config.get_dataset_config(dataset_name)
        
        # 路径配置
        self.data_dir = Path(config.get("paths", "data_dir"))
        self.front_video_dir = Path(config.get("paths", "front_video_dir"))
        self.back_video_dir = Path(config.get("paths", "back_video_dir"))
        
        # 数据集配置
        self.dataset_type = self.dataset_config["type"]
        if self.dataset_type != "test":
            raise ValueError(f"此脚本只用于生成测试集，当前类型: {self.dataset_type}")
        
        self.prompt_key = self.dataset_config.get("prompt_key")
        self.instruction_prompt = config.get("prompts", self.prompt_key, default="")
        
        # ========== 摄像头配置 ==========
        if use_cameras is not None:
            self.use_cameras = use_cameras
        else:
            self.use_cameras = config.get("cameras", "use_cameras",
                                          default=["front", "back"])
        
        if isinstance(self.use_cameras, str):
            self.use_cameras = [self.use_cameras.lower()]
        else:
            self.use_cameras = [cam.lower() for cam in self.use_cameras]
        
        valid_cameras = {"front", "back"}
        for cam in self.use_cameras:
            if cam not in valid_cameras:
                raise ValueError(f"无效的摄像头配置: {cam}")
        
        if not self.use_cameras:
            raise ValueError("至少需要指定一个摄像头")
        # ================================
        
        # ========== EgoInfo 配置 ==========
        if use_ego_info is not None:
            self.use_ego_info = use_ego_info
        else:
            self.use_ego_info = self.dataset_config.get("use_ego_info", False)
        
        self.ego_info_manager: Optional[EgoInfoManager] = None
        
        if self.use_ego_info:
            if not EGO_INFO_AVAILABLE:
                raise ImportError(
                    "ego_info_manager.py 模块不可用！\n"
                    "请确保 ego_info_manager.py 在同一目录下"
                )
            
            ego_info_config = self._prepare_ego_info_config()
            self.ego_info_manager = create_ego_info_manager_from_config(ego_info_config)
        # ==================================
        
        # ========== 视频校验配置 ==========
        # 测试集的基本校验阈值（只检查基础有效性）
        self.frame_tolerance = config.get("video_quality", "frame_tolerance", default=10)
        self.duration_tolerance = config.get("video_quality", "duration_tolerance", default=1.0)
        self.max_workers = config.get("processing", "max_workers", default=32)
        # ==================================
        
        # 处理配置
        self.seed = config.get("processing", "seed")
        random.seed(self.seed)
        
        # 设置日志
        self.output_dir = self.data_dir / self.dataset_config["name"]
        ensure_dir(self.output_dir)
        self.logger = setup_logger(
            "TestDatasetBuilder",
            log_file=self.output_dir / "build_test_dataset.log"
        )
        
        # 输出路径
        self.output_path = None
        self.output_path_jsonl = None
        
        self.logger.info(f"使用摄像头: {', '.join(self.use_cameras)}")
        
        if self.use_ego_info:
            enabled_fields = self.ego_info_manager.get_enabled_fields()
            self.logger.info(f"使用车辆信息: {', '.join(enabled_fields)}")
    
    def _prepare_ego_info_config(self) -> Dict:
        """准备 EgoInfo 配置"""
        ego_info_config = {
            "cache_dir": self.config.get("ego_info", "cache_dir"),
            "interval_seconds": self.config.get("ego_info", "interval_seconds", default=0.5),
            "enabled_fields": self.config.get("ego_info", "enabled_fields",
                                             default=["velocity", "acc_long", "acc_lat", "steer"]),
            "download": self.config.get("ego_info", "download", default={}),
            "prompt": self.config.get("ego_info", "prompt", default={}),
            "storage": {
                "guiyang": self.config.get("storage", "guiyang", default={}),
                "yd": self.config.get("storage", "yd", default={})
            }
        }
        
        dataset_fields = self.dataset_config.get("ego_info_fields")
        if dataset_fields is not None:
            ego_info_config["enabled_fields"] = dataset_fields
        
        return ego_info_config
    
    def _load_sampled_ids(self) -> Dict[str, Dict]:
        """
        从 sampled_autoscene_ids.json 加载采样的ID
        
        Returns:
            {autoscene_id: {label, source, label_description}}
        """
        sampled_file = self.output_dir / "sampled_autoscene_ids.json"
        
        if not sampled_file.exists():
            raise FileNotFoundError(
                f"采样文件不存在: {sampled_file}\n"
                "请先运行 sample_data.py"
            )
        
        self.logger.info(f"📂 读取采样文件: {sampled_file}")
        
        with open(sampled_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 解析采样文件（兼容新旧格式）
        id_map = {}
        
        if isinstance(data, list):
            # 旧格式：列表
            for sample in data:
                aid = sample["autoscene_id"]
                id_map[aid] = {
                    "label": sample["label"],
                    "source": sample.get("source", "unknown"),
                    "label_description": sample.get("label_description", f"Label {sample['label']}")
                }
            self.logger.info(f"✅ 加载 {len(id_map)} 个样本（旧格式）")
        
        elif isinstance(data, dict):
            # 新格式：批次
            for batch in data.get("batches", []):
                for sample in batch.get("samples", []):
                    aid = sample["autoscene_id"]
                    id_map[aid] = {
                        "label": sample["label"],
                        "source": sample.get("source", "unknown"),
                        "label_description": sample.get("label_description", f"Label {sample['label']}")
                    }
            self.logger.info(f"✅ 加载 {len(id_map)} 个样本（批次格式）")
        
        else:
            raise ValueError("未知的采样文件格式")
        
        return id_map
    
    def _load_excluded_ids(self) -> Set[str]:
        """加载需要排除的训练集ID"""
        excluded_ids = set()
        
        exclude_path = self.dataset_config.get("exclude_train_json")
        if not exclude_path:
            self.logger.warning("未配置 exclude_train_json，不排除训练集")
            return excluded_ids
        
        exclude_path = Path(exclude_path)
        if not exclude_path.exists():
            self.logger.warning(f"训练集文件不存在: {exclude_path}")
            return excluded_ids
        
        try:
            with open(exclude_path, 'r', encoding='utf-8') as f:
                train_data = json.load(f)
            
            for item in train_data:
                if "videos" in item and len(item["videos"]) > 0:
                    video_path = item["videos"][0]
                    autoscene_id = extract_autoscene_id(video_path)
                    excluded_ids.add(autoscene_id)
            
            self.logger.info(f"从训练集排除 {len(excluded_ids)} 个ID")
        
        except Exception as e:
            self.logger.error(f"加载训练集文件失败: {e}")
        
        return excluded_ids
    
    def _check_single_video(self, sample_info: Dict) -> Optional[Dict]:
        """
        检查单个视频的有效性
        
        Args:
            sample_info: {autoscene_id, label, source, label_description}
        
        Returns:
            如果有效返回样本信息，否则返回None
        """
        autoscene_id = sample_info["autoscene_id"]
        
        front_video = self.front_video_dir / f"{autoscene_id}.mp4"
        back_video = self.back_video_dir / f"{autoscene_id}.mp4"
        
        # 检查文件存在性
        if not front_video.exists():
            return None
        
        if not back_video.exists():
            return None
        
        # 获取视频信息
        front_info = get_video_info(str(front_video))
        back_info = get_video_info(str(back_video))
        
        front_duration, front_size, front_frames, front_fps, front_valid = front_info
        back_duration, back_size, back_frames, back_fps, back_valid = back_info
        
        # 检查视频是否有效
        if not front_valid or not back_valid:
            return None
        
        # ========== 只检查前后cam一致性，不限制大小和时长 ==========
        frame_diff = abs(front_frames - back_frames)
        duration_diff = abs(front_duration - back_duration)
        
        if frame_diff > self.frame_tolerance:
            return None
        
        if duration_diff > self.duration_tolerance:
            return None
        # ===========================================================
        
        # 构建样本信息
        return {
            "autoscene_id": autoscene_id,
            "label": sample_info["label"],
            "label_description": sample_info["label_description"],
            "source": sample_info["source"],
            "front_video": str(front_video),
            "back_video": str(back_video),
            "front_duration": round(front_duration, 2),
            "back_duration": round(back_duration, 2),
            "front_size_mb": round(front_size, 2),
            "back_size_mb": round(back_size, 2),
            "front_frames": front_frames,
            "back_frames": back_frames
        }
    
    def _collect_valid_samples(self, id_map: Dict[str, Dict], excluded_ids: Set[str]) -> List[Dict]:
        """
        收集有效的样本
        
        Args:
            id_map: autoscene_id -> sample_info
            excluded_ids: 需要排除的ID集合
        
        Returns:
            有效样本列表
        """
        # 过滤排除的ID
        candidate_ids = {aid: info for aid, info in id_map.items() if aid not in excluded_ids}
        
        self.logger.info(f"候选样本: {len(candidate_ids)} 个（排除训练集后）")
        
        # 准备检查任务
        samples_to_check = [
            {"autoscene_id": aid, **info}
            for aid, info in candidate_ids.items()
        ]
        
        self.logger.info(f"开始检查视频有效性...")
        
        # 多进程检查
        valid_samples = []
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self._check_single_video, sample): sample
                for sample in samples_to_check
            }
            
            for future in tqdm(
                as_completed(futures),
                total=len(samples_to_check),
                desc="检查视频"
            ):
                result = future.result()
                if result is not None:
                    valid_samples.append(result)
        
        self.logger.info(f"✅ 有效样本: {len(valid_samples)} 个")
        self.logger.info(f"❌ 无效样本: {len(samples_to_check) - len(valid_samples)} 个")
        
        return valid_samples
    
    def _sample_by_config(self, valid_samples: List[Dict]) -> List[Dict]:
        """按配置采样"""
        # 按label和source分组
        grouped = defaultdict(lambda: defaultdict(list))
        
        for sample in valid_samples:
            label = sample["label"]
            source = sample["source"]
            grouped[label][source].append(sample)
        
        sampled_samples = []
        
        for class_cfg in self.dataset_config["classes"]:
            label = class_cfg["label"]
            description = class_cfg.get("description", f"Label {label}")
            
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"类别 {label}: {description}")
            self.logger.info(f"{'='*60}")
            
            # ========== 关键修改：跨source去重 ==========
            # 记录该类别已使用的ID
            class_used_ids = set()
            class_samples = []
            # ==========================================
            
            for source_cfg in class_cfg["sources"]:
                source_desc = source_cfg.get("description", "未知来源")
                sample_count = source_cfg.get("sample_count", -1)
                
                # ========== 修改：获取该类别的所有样本，排除已使用的 ==========
                available = []
                for source_name, samples in grouped[label].items():
                    for s in samples:
                        if s["autoscene_id"] not in class_used_ids:
                            available.append(s)
                
                # 按ID去重（防止重复）
                seen_ids = set()
                deduplicated = []
                for s in available:
                    if s["autoscene_id"] not in seen_ids:
                        deduplicated.append(s)
                        seen_ids.add(s["autoscene_id"])
                # ===============================================================
                
                self.logger.info(f"   {source_desc}: 可用 {len(deduplicated)} 个（排除已用）")
                
                # 采样
                if sample_count == -1:
                    sampled = deduplicated
                    self.logger.info(f"      使用所有 {len(sampled)} 个")
                elif sample_count == 0:
                    sampled = []
                    self.logger.info(f"      不使用任何样本")
                elif sample_count >= len(deduplicated):
                    sampled = deduplicated
                    self.logger.info(f"      需要 {sample_count} 个，可用 {len(deduplicated)} 个，全部使用")
                else:
                    sampled = random.sample(deduplicated, sample_count)
                    self.logger.info(f"      从 {len(deduplicated)} 个中采样 {sample_count} 个")
                
                # ========== 记录已使用的ID ==========
                for s in sampled:
                    class_used_ids.add(s["autoscene_id"])
                # ====================================
                
                class_samples.extend(sampled)
            
            self.logger.info(f"   实际采样总数: {len(class_samples)}")
            self.logger.info(f"   唯一ID数: {len(class_used_ids)}")
            sampled_samples.extend(class_samples)
        
        return sampled_samples
    
    def _create_test_item(self, sample: Dict) -> Dict:
        """创建测试集格式数据项（不带label）"""
        content = []
        
        # 添加车辆信息
        if self.use_ego_info and self.ego_info_manager:
            ego_info_prompt = self.ego_info_manager.get_prompt(
                sample["autoscene_id"]
            )
            content.append({"type": "text", "text": ego_info_prompt})
        
        # 添加视频
        if "front" in self.use_cameras:
            content.extend([
                {"type": "text", "text": "前视视角"},
                {
                    "type": "video",
                    "video": sample["front_video"],
                    "max_pixels": 336000
                }
            ])
        
        if "back" in self.use_cameras:
            content.extend([
                {"type": "text", "text": "后视视角"},
                {
                    "type": "video",
                    "video": sample["back_video"],
                    "max_pixels": 336000
                }
            ])
        
        content.append({"type": "text", "text": self.instruction_prompt})
        
        return [{
            "role": "user",
            "content": content
        }]
    
    def _create_test_item_with_label(self, sample: Dict) -> Dict:
        """创建带标签的测试集格式数据项（用于JSONL）"""
        content = []
        
        # 添加车辆信息
        if self.use_ego_info and self.ego_info_manager:
            ego_info_prompt = self.ego_info_manager.get_prompt(
                sample["autoscene_id"]
            )
            content.append({"type": "text", "text": ego_info_prompt})
        
        # 添加视频
        if "front" in self.use_cameras:
            content.extend([
                {"type": "text", "text": "前视视角"},
                {
                    "type": "video",
                    "video": sample["front_video"],
                    "max_pixels": 336000
                }
            ])
        
        if "back" in self.use_cameras:
            content.extend([
                {"type": "text", "text": "后视视角"},
                {
                    "type": "video",
                    "video": sample["back_video"],
                    "max_pixels": 336000
                }
            ])
        
        content.append({"type": "text", "text": self.instruction_prompt})
        
        return {
            "id": sample["autoscene_id"],
            "label": sample["label"],
            "content": content
        }
    
    def build_test_dataset(self):
        """构建测试集"""
        self.logger.info(f"=" * 60)
        self.logger.info(f"开始构建测试集: {self.dataset_name}")
        self.logger.info(f"数据源: sampled_autoscene_ids.json")
        self.logger.info(f"使用摄像头: {', '.join(self.use_cameras)}")
        if self.use_ego_info:
            enabled_fields = self.ego_info_manager.get_enabled_fields()
            self.logger.info(f"使用车辆信息: {', '.join(enabled_fields)}")
        self.logger.info(f"=" * 60)
        
        # 加载采样ID
        id_map = self._load_sampled_ids()
        
        # 加载排除ID
        excluded_ids = self._load_excluded_ids()
        
        # 收集有效样本
        valid_samples = self._collect_valid_samples(id_map, excluded_ids)
        
        if not valid_samples:
            self.logger.error("没有有效样本，无法生成测试集")
            return
        
        # 按配置采样
        sampled_samples = self._sample_by_config(valid_samples)
        
        self.logger.info(f"\n采样后总数: {len(sampled_samples)}")
        
        # 打乱顺序
        random.shuffle(sampled_samples)
        
        # 生成数据项
        total_samples = len(sampled_samples)
        
        # 文件名后缀
        camera_suffix = "_".join(self.use_cameras)
        ego_info_suffix = "_with_ego_info" if self.use_ego_info else ""
        
        # 生成两个文件
        # 1. JSON格式（不带label，用于评测）
        dataset_items_json = []
        for sample in sampled_samples:
            item = self._create_test_item(sample)
            dataset_items_json.append(item)
        
        # 2. JSONL格式（带label，用于分析）
        dataset_items_jsonl = []
        for sample in sampled_samples:
            item = self._create_test_item_with_label(sample)
            dataset_items_jsonl.append(item)
        
        # 设置输出文件名
        self.output_path = self.output_dir / \
            f"test_{self.dataset_config['name']}_{camera_suffix}{ego_info_suffix}_{total_samples}.json"
        self.output_path_jsonl = self.output_dir / \
            f"test_{self.dataset_config['name']}_{camera_suffix}{ego_info_suffix}_{total_samples}.jsonl"
        
        # 写入JSON（不带label）
        with open(self.output_path, 'w', encoding='utf-8') as f:
            json.dump(dataset_items_json, f, ensure_ascii=False, indent=2)
        
        # 写入JSONL（带label）
        with open(self.output_path_jsonl, 'w', encoding='utf-8') as f:
            for item in dataset_items_jsonl:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
        
        self.logger.info(f"\n输出文件:")
        self.logger.info(f"  JSON (评测用): {self.output_path}")
        self.logger.info(f"  JSONL (分析用): {self.output_path_jsonl}")
        
        self.logger.info(f"\n" + "=" * 60)
        self.logger.info(f"测试集构建完成")
        self.logger.info(f"总样本数: {total_samples}")
        self.logger.info(f"=" * 60)
        
        # 打印类别分布
        label_counts = defaultdict(int)
        for sample in sampled_samples:
            label_counts[sample["label"]] += 1
        
        self.logger.info(f"\n类别分布:")
        for label, count in sorted(label_counts.items()):
            description = "未知"
            for class_cfg in self.dataset_config["classes"]:
                if class_cfg["label"] == label:
                    description = class_cfg.get("description", "未知")
                    break
            
            self.logger.info(f"  类别 {label} ({description}): {count} 个")
        
        # 打印视频大小和时长统计
        self.logger.info(f"\n视频统计:")
        
        sizes = [s["front_size_mb"] for s in sampled_samples] + \
                [s["back_size_mb"] for s in sampled_samples]
        durations = [s["front_duration"] for s in sampled_samples] + \
                    [s["back_duration"] for s in sampled_samples]
        
        large_count = sum(1 for s in sizes if s > 90)
        long_count = sum(1 for s in durations if s > 30)
        
        self.logger.info(f"  大文件 (>90MB): {large_count} 个视频")
        self.logger.info(f"  长视频 (>30s): {long_count} 个视频")
        self.logger.info(f"  平均大小: {sum(sizes)/len(sizes):.1f}MB")
        self.logger.info(f"  平均时长: {sum(durations)/len(durations):.1f}s")


def main():
    parser = argparse.ArgumentParser(
        description="构建测试数据集（从采样文件直接构建，不依赖扫描报告）"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    
    # 摄像头选择
    parser.add_argument(
        "--cameras",
        type=str,
        nargs='+',
        choices=['front', 'back'],
        default=None,
        help="使用的摄像头（front, back, 或两者）"
    )
    
    # 车辆信息
    parser.add_argument(
        "--use-ego-info",
        action="store_true",
        help="启用车辆信息增强"
    )
    
    parser.add_argument(
        "--ego-info-fields",
        type=str,
        nargs='+',
        default=None,
        help="选择启用的车辆信息字段"
    )
    
    parser.add_argument(
        "--ego-info-cache",
        type=str,
        default=None,
        help="ego_pose.json 缓存目录"
    )
    
    args = parser.parse_args()
    
    config = ConfigManager(args.config)
    
    # 处理命令行参数
    if args.ego_info_fields:
        if not hasattr(config, 'config'):
            raise AttributeError("ConfigManager 缺少 config 属性")
        
        if "ego_info" not in config.config:
            config.config["ego_info"] = {}
        
        config.config["ego_info"]["enabled_fields"] = args.ego_info_fields
    
    if args.ego_info_cache:
        if "ego_info" not in config.config:
            config.config["ego_info"] = {}
        
        config.config["ego_info"]["cache_dir"] = args.ego_info_cache
    
    builder = TestDatasetBuilder(
        config,
        args.dataset,
        use_cameras=args.cameras,
        use_ego_info=args.use_ego_info
    )
    builder.build_test_dataset()


if __name__ == "__main__":
    main()