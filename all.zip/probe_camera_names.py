"""
探针脚本：下载单个 autoscene 的完整 samples 目录，打印 OBS 里真实的摄像头文件夹名。
用途：确认鱼眼摄像头在桶里到底叫什么（config.yaml 里 cameras.left/right.name 是否正确）。

用法:
    python probe_camera_names.py <autoscene_id>

说明:
    - 下载到独立的 <cache_root>/autoscenes_<id>_probe 目录，不污染正式 cache。
    - 单个 scene 的全摄像头图片可能有几百 MB，跑完可自行删除该 _probe 目录。
"""
import sys
from pathlib import Path

from utils import ConfigManager
from download_data import download_autoscenes_data_by_devkit


def main():
    if len(sys.argv) < 2:
        print("用法: python probe_camera_names.py <autoscene_id>")
        sys.exit(1)

    aid = sys.argv[1]
    config = ConfigManager("config.yaml")

    cache_root = Path(config.get("paths", "cache_root"))
    cache_dir = cache_root / f"autoscenes_{aid}_probe"

    print(f"正在下载 scene {aid} 的完整 samples 目录到 {cache_dir} ...")
    download_autoscenes_data_by_devkit(
        aid,
        ["samples"],  # 下整个 samples，不按摄像头过滤
        cache_dir,
        config.get("processing", "is_guiyang"),
        yw_bucket_url=config.get("storage", "guiyang", "url"),
        yw_ak=config.get("storage", "guiyang", "ak"),
        yw_sk=config.get("storage", "guiyang", "sk"),
        yd_bucket_url=config.get("storage", "yd", "url"),
        yd_ak=config.get("storage", "yd", "ak"),
        yd_sk=config.get("storage", "yd", "sk"),
    )

    samples_dir = cache_dir / aid / "samples"
    print("\n" + "=" * 60)
    if not samples_dir.exists():
        print(f"❌ 没有找到 samples 目录: {samples_dir}")
        print("   说明这个 scene 本身没下下来（ID 错误 / 桶路由问题）。")
        sys.exit(2)

    cams = sorted(p.name for p in samples_dir.iterdir() if p.is_dir())
    print(f"✅ scene {aid} 真实的摄像头目录（{len(cams)} 个）：")
    for c in cams:
        print(f"   - {c}")
    print("=" * 60)
    print("\n把上面带 FISHEYE/LEFT/RIGHT 的真实名字填回 config.yaml 的 "
          "cameras.left.name / cameras.right.name 即可。")


if __name__ == "__main__":
    main()
