import logging
import os
import shutil
import time
from pathlib import Path
from shutil import copyfile
from typing import Set, Dict

import pyarrow.parquet
from autoscenes import hub
from autoscenes.utils.di_api import DiRequest
from obs import ObsClient
from requests import RequestException

DELTA_SZ_PHYSICAL_BUCKET = "yw-delta-gy1"

class Golbals:
    all_data_num = 0
    invalid_data_num = 0

def config_obs(ak: str, sk: str, bucket_url: str):
    """
    配置OBS客户端的函数

    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    :return: 配置好的OBS客户端
    """

    # 移除环境变量中的http代理设置
    os.environ.pop("http_proxy", None)

    # 移除环境变量中的https代理设置
    os.environ.pop("https_proxy", None)

    # 返回配置好的OBS客户端
    return ObsClient(access_key_id=ak, secret_access_key=sk, server=bucket_url)


def download_obs_data(obs_client, full_obs_path: str, save_path: Path) -> None:
    """
    从OBS服务下载数据

    :param obs_client: OBS客户端对象
    :param full_obs_path: 完整的OBS路径
    :param save_path: 保存路径
    :raise RuntimeError: 在获取OBS文件列表或下载文件时出现错误时会抛出此异常
    """

    # 去掉路径的"obs://"前缀
    if full_obs_path.startswith("obs://"):
        full_obs_path = full_obs_path[6:]

    # 分割路径，获取OBS桶名称和桶内路径前缀
    bucket_name, prefix = full_obs_path.split("/", 1)

    # 初始化待下载的文件集合
    files = set()

    # 初始化标记
    mark = None

    # 初始化是否被截断的标志
    is_truncated = True

    # 初始化尝试次数
    num_attempt = 1

    # 当文件列表被截断时，继续获取文件列表
    while is_truncated:
        # 获取文件列表
        resp = obs_client.listObjects(bucket_name, prefix, mark, 1000)

        # 如果HTTP响应码大于等于300则重试，如果尝试3次仍大于300，抛出异常
        if resp.status >= 300:
            num_attempt += 1
            if num_attempt > 3:
                raise RuntimeError("Failed to get OBS file list")
            continue

        # 如果文件列表中的任何一个文件的key不以指定的桶内路径前缀开头，抛出异常
        if not all(content.key.startswith(prefix) for content in resp.body.contents):
            raise RuntimeError("Unexpected OBS response")

        # 更新待下载的文件集合，排除文件夹（以"/"结尾的）
        files.update(
            content.key for content in resp.body.contents if content.key[-1] != "/"
        )

        # 更新是否被截断的标志和标记
        is_truncated = resp.body.is_truncated
        mark = resp.body.next_marker

        # 重置尝试次数
        num_attempt = 1

    # 如果查询结果为空，打印错误日志并返回
    if not files:
        logging.error(f"No file to download: {full_obs_path}")
        return

    # 过滤掉已经存在的文件
    files = sorted(
        filter(
            lambda obs_path: not (save_path / obs_path[len(prefix) :]).exists(),
            files,
        )
    )

    # 初始化尝试次数
    num_attempt = 1

    # 当待下载的文件列表不为空且尝试次数小于等于3时，继续下载文件
    while files and num_attempt <= 3:
        # 下载文件，待下载文件列表中只保留下载失败的文件用于重试
        files = frozenset(
            filter(
                lambda obs_path: obs_client.getObject(
                    bucket_name, obs_path, save_path / obs_path[len(prefix) :]
                ).status
                >= 300,
                sorted(files),
            )
        )

        # 尝试次数加1
        num_attempt += 1

    # 如果待下载的文件列表仍不为空，抛出异常
    if files:
        raise RuntimeError(f"Failed to download OBS files: {sorted(files)}")


def get_request_header() -> Dict[str, str]:
    """
    从autoscenes devkit 2025/2/14版本中提取出的请求头，用于兼容不同版本的autoscenes devkit

    :return: 请求头信息
    """

    request_header = {
        "Content-Type": "application/json",
        "Accept-Language": "zh-CN",
        "connection": "close",
        "userName": "system",
        "userId": "11186",
        "Deepdata-project": "driveinsight",
        "Deepdata-platform": "datatransform-external",
        "Deepdata-region": "RaD-prod",
        "Entrypoint-version": "v2",
        "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjZkZDk4NWI3LTViZTMtNDk5Ny1iN2NjLWVlY2U4ZDUxNjIxZCIsInR5cCI6IkpXVCJ9.eyJhY3IiOiIwIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwiYXVkIjpbIlN1cGVyc2V0LWdlbmVyYWwtc2giLCJTdXBlcnNldC1hdXRvc2NlbnNlLXN6IiwiYWNjb3VudCJdLCJhdXRoX3RpbWUiOjE3MjIyNTc0NzAsImF6cCI6IkRhdGFDaXJjbGUiLCJlbWFpbCI6ImNoYW5nZnVzaGVuZ0BoLXBhcnRuZXJzLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiZXhwIjoxNzIyNTgyNTc4LCJmYW1pbHlfbmFtZSI6ImNXWDExMTc5MzciLCJnaXZlbl9uYW1lIjoiY1dYMTExNzkzNyIsImdyb3VwcyI6WyIvYmV2LXBlcmNlcHRpb24tYXV0b3NjZW5lcyJdLCJpYXQiOjE3MjI0NzAzNjMsImlzcyI6Imh0dHBzOi8vb25lY2xvdWQuYWRzLmlhcy5odWF3ZWkuY29tL2tleWNsb2FrL3JlYWxtcy9kaS1zdHVkaW8iLCJqdGkiOiI1NTMxNjI5NS02NTdiLTQzMjctODZmYi1lZTBjMTViMzUwZTIiLCJuYW1lIjoiY1dYMTExNzkzNyBjV1gxMTE3OTM3Iiwibm9uY2UiOiI5YTFjYWZhMS01Mjc2LTRiMjMtODgwMi0wZDc1YzMyZGM0M2EiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJjd3gxMTE3OTM3IiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbImRlZmF1bHQtcm9sZXMtZGktc3R1ZGlvIiwib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7IkRhdGFDaXJjbGUiOnsicm9sZXMiOlsicHVibGljOkJhc2VSb2xlIiwiZHJpdmVpbnNpZ2h0OkJhc2VSb2xlIl19LCJTdXBlcnNldC1hdXRvc2NlbnNlLXN6Ijp7InJvbGVzIjpbImJldi1wZXJjZXB0aW9uLWF1dG9zY2VuZXMtc3FsIiwiYmV2LXBlcmNlcHRpb24tYXV0b3NjZW5lcy1kYXNoYm9hcmQiLCJiZXYtcGVyY2VwdGlvbi1hdXRvc2NlbmVzLWNoYXJ0Il19LCJTdXBlcnNldC1nZW5lcmFsLXNoIjp7InJvbGVzIjpbInNxbF9sYWIiLCJzcWxfbGFiX3dpdGhfVHJpbm9fcHJvZCJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCIsInNlc3Npb25fc3RhdGUiOiJjMzA1ZjgzYi03OTY3LTQxNTEtYTU2YS04YWNhNzZjOGVlNDIiLCJzaWQiOiJjMzA1ZjgzYi03OTY3LTQxNTEtYTU2YS04YWNhNzZjOGVlNDIiLCJzdWIiOiIzNTYxYTRkMC1mNzQ3LTRiYzQtYjliYy1lMDU0ZmY3ODE3YzIiLCJ0eXAiOiJCZWFyZXIifQ.JD4XqyVnLYLtzuXKcbzVZenwQBHN97c0iT2T5WUObYH1uEp2agZyEovGk2iVoPsCcul4twr_Lc-G81zeUUE9PI1nkNMjEM4p8pyiloi4UpbqlOd74cJopSa-PTCoX34OJvVtMQ280jSGgh7z4BDfBIcYksBUCq9PGDvvWAvV0UlGpWkRN-QASwqNq7OPW5GJP4QSlbuVfKAGgt86SflaN6S_1uhmR0IRRZegk6Wuduu-WSJe8_6d1KmlEThpwSqf6zkEDrkwivvYu9wwAiJfnJP6v2mKVs878AIkVru69TC-FYU2Svyprrqw2yjPKh64puBO932G8uq8AEaEFKCBKQ",
    }
    if os.getenv("REGION_DEVKIT", "RaD-prod") == "RaD-prod-SG":
        request_header["Deepdata-project"] = "sg-driveinsight"
        request_header["Deepdata-region"] = "RaD-prod-SG"
        request_header["Authorization"] = (
            "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI0SVZRU0hwUXB2d1ZGYnpnR2NGZ25IdzZwNEktNy1kVnZtUHpwZFJlTzFrIn0.eyJleHAiOjE3MTcxNjMwMzQsImlhdCI6MTcxNzA3NjYzNCwianRpIjoiMGRjMTdiNDEtMjg5NC00OTM2LTllYWEtNGI4ZjdkYWMzN2Q3IiwiaXNzIjoiaHR0cHM6Ly9vbmVjbG91ZC5hZHMuaWFzLmh1YXdlaS5jb20va2V5Y2xvYWsvcmVhbG1zL2RpLXN0dWRpbyIsImF1ZCI6WyJhY2NvdW50IiwiRGVlcGRhdGEtdGVzdCJdLCJzdWIiOiIyOTczOWIxYy1jMjBmLTQ3NjktODExMy04NGE1NDA2NmIyZWYiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJEYXRhQ2lyY2xlIiwic2Vzc2lvbl9zdGF0ZSI6ImRlYzI1ZWYzLTM0NTgtNDU2Mi05ZmE0LTI5MmMwODllOGRlYyIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiKiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiZGVmYXVsdC1yb2xlcy1kaS1zdHVkaW8iLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiRGF0YUNpcmNsZSI6eyJyb2xlcyI6WyJ0cmFuc2Zvcm06cGxhdGZvcm06VGFza0NlbnRlciBFZGl0b3IiLCJkcml2ZWluc2lnaHQ6QmFzZVJvbGUiLCIqOnZpZXdlciJdfSwiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19LCJEZWVwZGF0YS10ZXN0Ijp7InJvbGVzIjpbIio6dmlld2VyIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwic2lkIjoiZGVjMjVlZjMtMzQ1OC00NTYyLTlmYTQtMjkyYzA4OWU4ZGVjIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJ0cmFuc2Zvcm0tcHVibGljIiwiZ2l2ZW5fbmFtZSI6IiIsImZhbWlseV9uYW1lIjoiIn0.BPtw8A_HdbORsAFAj8UjMsW2011IfyGvd7y8xoPWc7Relzz3x8PomoMAPAUoqJbmosh1EaPDmLSo7YPYq6mnS_V6r4fGke9Cm7BB3Hi7V9Uhkir4ByMBdUqCT3arU6hDS9lsLOg-IGfT-n8hefL8jg32rdb2czIv4yMniNDRJerFVF2TglQUAN0crAGwhIy7A74H-BW4EouseYL20cRNHVCwv_2pxJKNUKBuLQ31FGsIdOMhi5lbUz4ew3bQ7rDleGI1qg9pg-MQm5VRHQVXf0wW_8ViiAzbdJl4KrH4PMXFAuQzob4NcHUP_8PZZbLNZ5E6-XBzf3z_0n8Q-eVjag"
        )
    return request_header


def get_metadata_by_id(autoscenes_id: str) -> dict:
    """
    根据指定的autoscenes id获取元数据

    :param autoscenes_id: 需要查询的元数据的id
    :return: 查询到的元数据
    :raise Exception: 如果请求失败或者返回的结果中没有元数据，可能会抛出异常
    """

    # 获取请求头
    try:
        header = DiRequest.get_request_header()
    except AttributeError:
        logging.warning(
            "Failed to import DiRequest.get_request_header, using fixed implementation"
        )
        header = get_request_header()
    header = {**header, "Deepdata-platform": "datatransform-external"}

    # 获取请求体
    body = {
        "pageNum": 1,
        "pageSize": 20,
        "searchCondition": {
            "distinctFragmentId": False,
            "idList": [autoscenes_id],
            "sortFlag": True,
        },
    }

    # 初始化最大重试次数
    max_attempt = 3

    # 使用autoscenes devkit库发送POST请求，对超时异常重试3次
    # 请求的URL是一个API接口，用于获取元数据
    # 请求头中包含了内容类型、连接类型和接受语言
    # 请求体中包含了分页信息和查询条件
    for attempt in range(max_attempt):
        try:
            response = DiRequest.data_transform_request(
                "datatransform/external/v1/datafragments/list", body, header
            )
            break
        except RequestException:
            logging.warning(
                "Failed to get metadata for %d time%s", attempt + 1, "s" * bool(attempt)
            )
            if attempt + 1 == max_attempt:
                raise
            time.sleep(20)

    # 从返回的JSON数据中提取结果，并返回第一个元素
    return tuple(
        filter(
            lambda di_response_item: di_response_item["id"] == autoscenes_id,
            response["result"]["list"],
        )
    )[0]


def download_bags(
    autoscenes_id: str,
    bag_files,
    save_path,
    *,
    camera_config_files=("cam_1.yaml", "cam_2.yaml"),
    ak: str,
    sk: str,
    bucket_url: str,
):
    """
    下载ros bag包文件并解压缩

    :param autoscenes_id: 数据的唯一标识符
    :param bag_files: 需要下载的ros bag包文件列表
    :param save_path: 保存路径
    :param camera_config_files: 相机配置文件列表，默认为("cam_1.yaml", "cam_2.yaml")
    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    :return: 返回元数据结果
    """

    # 导入rosbag模块
    import rosbag

    # 获取元数据
    result = get_metadata_by_id(autoscenes_id)

    # 创建保存路径
    current_save_path = Path(save_path) / autoscenes_id
    current_save_path.mkdir(exist_ok=True, parents=True)

    # 创建bag包保存路径
    bag_save_path = current_save_path / "rosbag"
    bag_save_path.mkdir(exist_ok=True, parents=True)

    # 配置OBS客户端
    obs_client = config_obs(ak, sk, bucket_url)

    try:
        # 遍历bag包文件列表
        for bag_file in bag_files:
            # 下载bag包
            download_obs_data(
                obs_client,
                f"{result['originPath']}/archive/{bag_file}",
                bag_save_path / bag_file,
            )

            # 获取bag包的压缩类型
            with rosbag.Bag(str(bag_save_path / bag_file), allow_unindexed=True) as rbo:
                compress_type = rbo.get_compression_info().compression

            # 如果压缩类型不是lz4，则跳过
            if compress_type != "lz4":
                continue

            # 解压缩bag包
            os.system(
                f"/bin/bash -c 'source /opt/ros/kinetic/setup.bash; "
                f"rosbag decompress {bag_save_path}/{bag_file.split('.')[0]}.bag --output-dir={bag_save_path}; "
                f"rm {bag_save_path}/{bag_file.split('.')[0]}.orig.bag'"
            )
    finally:
        # 关闭OBS客户端
        obs_client.close()

    # 下载相机配置文件到bag包路径
    download_config_to_bag_path(
        autoscenes_id,
        current_save_path / "conf",
        ak=ak,
        sk=sk,
        bucket_url=bucket_url,
    )

    # 下载好的相机配置文件复制到ros bag包路径
    copy_camera_config_files(
        camera_config_files, current_save_path / "conf", bag_save_path
    )

    # 返回元数据结果
    return result


def download_config_to_bag_path(
    autoscenes_id: str, save_path: Path, *, ak: str, sk: str, bucket_url: str
) -> None:
    """
    从OBS服务器下载配置文件。

    :param autoscenes_id: 数据的唯一标识符
    :param save_path: 下载配置文件的路径
    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    """

    # 配置OBS客户端
    obs_client = config_obs(ak, sk, bucket_url)

    try:
        # 从OBS桶中下载相机配置文件
        download_obs_data(
            obs_client,
            f"{get_metadata_by_id(autoscenes_id)['originPath']}/conf/",
            save_path,
        )
    finally:
        # 关闭OBS客户端
        obs_client.close()


def copy_camera_config_files(
    camera_config_files, save_path: Path, target_path: Path
) -> None:
    """
    Copy camera configuration files from source to target path.

    :param camera_config_files: 相机配置文件列表
    :param save_path: 相机配置文件的源路径
    :param target_path: 相机配置文件的目标路径
    """
    for camera_config_file in camera_config_files:
        # 如果相机配置文件已经存在于目标路径，则跳过
        if (target_path / camera_config_file).exists():
            continue

        # 递归找到指定的文件
        conf_file_path = None
        for foldername, subfolders, filenames in os.walk(save_path):
            if camera_config_file in filenames:
                conf_file_path = os.path.join(foldername, camera_config_file)

        # 如果找不到指定的文件，则跳过
        if conf_file_path is None:
            continue

        # 将找到的相机配置文件复制到包路径
        copyfile(conf_file_path, str(target_path / camera_config_file))


def check_all_file_ready(download_target, required_files) -> bool:
    """
    检查所有必要的文件是否已经准备好

    :param download_target: 下载目标的绝对路径
    :param required_files: 需要检查的文件的列表
    :return: 所有必要的文件是否都已经准备好
    """

    # 遍历所有需要检查的文件
    for required_file in required_files:
        # 获取实际的文件路径
        real_required_file = download_target / required_file

        # 文件不存在
        if not real_required_file.exists():
            return False

        # 目录为空，这通常意味着对应的文件下载失败。
        if real_required_file.is_dir() and not tuple(real_required_file.iterdir()):
            return False

    # 所有文件都存在且目录非空，返回True
    return True


def download_autoscenes_data_by_devkit(
    autoscenes_id: str,
    parquet_files,
    save_path: Path,
    is_guiyang: bool = False,
    *,
    yw_ak: str,
    yw_sk: str,
    yw_bucket_url: str,
    yd_ak: str,
    yd_sk: str,
    yd_bucket_url: str,
):
    """
    通过devkit下载autoscenes数据

    :param autoscenes_id: 数据的唯一标识符
    :param parquet_files: 需要下载的autoscenes文件列表
    :param save_path: autoscenes文件保存路径
    :param is_guiyang：是否是贵阳云上
    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    :return: 返回元数据结果
    """

    # 查询autoscenes obs前缀
    result = get_metadata_by_id(autoscenes_id)
    result_prefix = result["sceneObsPath"].replace(autoscenes_id, "")
    # # ✅ 添加这段代码：列出所有摄像头文件夹
    # print(f"\n{'='*60}")
    # print(f"🔍 正在查询 autoscene_id: {autoscenes_id}")
    # print(f"📍 OBS完整路径: {result['sceneObsPath']}")
    
    # 贵阳环境上苏州桶的数据地址换成贵阳的
    Golbals.all_data_num += 1
    if is_guiyang:
        result_prefix_splits = result_prefix.split("/")
        if len(result_prefix_splits) >= 3:
            result_prefix_splits[2] = (
                "driveinsight-sg-gy"
                if os.getenv("REGION_DEVKIT", "RaD-prod") == "RaD-prod-SG"
                else "delta-general-guiyang"
            )
        result_prefix = "/".join(result_prefix_splits)

        # delta-sz(苏州)规范名 -> 贵阳物理桶, 改写后走 yw 凭据
    if result_prefix.startswith("obs://delta-sz") and DELTA_SZ_PHYSICAL_BUCKET:
        result_prefix = result_prefix.replace("obs://delta-sz", f"obs://{DELTA_SZ_PHYSICAL_BUCKET}", 1)
    if result_prefix.startswith("obs://delta-general-guiyang"):
        bucket_url = yd_bucket_url
        ak = yd_ak
        sk = yd_sk
    elif result_prefix.startswith("obs://yw"):
        bucket_url = yw_bucket_url
        ak = yw_ak
        sk = yw_sk
    else:
        Golbals.invalid_data_num += 1
        print(f"error! result_prefix {result_prefix} data num {Golbals.all_data_num} {Golbals.invalid_data_num}")
        return result
    # obs配置
    obs_args = (bucket_url, ak, sk, result_prefix)
    try:
        hub.set_obs(*obs_args, region=os.getenv("REGION_DEVKIT", "RaD-prod"))
    except TypeError:
        # 低版本autoscenes devkit不支持region入参，在发生相关错误时不传入此入参重试
        logging.warning("Failed to set obs region, using RaD-prod")
        hub.set_obs(*obs_args)

    # 下载路径
    hub.set_dir(save_path)

    # parquet_files用于指定下载的内容，如果没有.parquet后缀的话会自动解包
    hub.download_files_specified(autoscenes_id, parquet_files)

    # # 如果文件不存在的话，下载bag包并解压
    # download_target = save_path / autoscenes_id
    # if "samples" not in parquet_files and not check_all_file_ready(
    #     download_target, parquet_files
    # ):
    #     download_autoscenes_data_by_devkit(
    #         autoscenes_id,
    #         [
    #             "samples",
    #             *filter(
    #                 lambda parquet_file: not parquet_file.startswith("samples"),
    #                 parquet_files,
    #             ),
    #         ],
    #         save_path,
    #         is_guiyang,
    #         ak=ak,
    #         sk=sk,
    #         bucket_url=bucket_url,
    #     )

    # 返回元数据结果
    return result


def download_autoscenes_data(
    autoscenes_id: str,
    parquet_files,
    save_path: Path,
    *,
    ak: str,
    sk: str,
    bucket_url: str,
) -> None:
    """
    下载autoscenes数据

    :param autoscenes_id: 数据的唯一标识符
    :param parquet_files: 需要下载的autoscenes文件列表
    :param save_path: autoscenes文件保存路径
    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    """

    # 配置OBS客户端
    obs_client = config_obs(ak, sk, bucket_url)

    try:
        # 遍历需要下载的parquet文件列表
        for parquet_file in parquet_files:
            # 下载OBS上的数据到本地
            download_obs_data(
                obs_client,
                f"{get_metadata_by_id(autoscenes_id)['sceneObsPath']}/{parquet_file}",
                save_path / parquet_file,
            )
    finally:
        # 关闭OBS客户端
        obs_client.close()

    # 遍历下载的parquet文件列表
    for parquet_file in parquet_files:
        # 读取parquet文件
        parquet_table = pyarrow.parquet.read_table(
            (save_path / parquet_file).resolve(strict=True)
        )

        # 遍历parquet文件中的数据
        for parquet_info_name, parquet_data in zip(parquet_table[0], parquet_table[1]):
            # 将数据写入到本地文件中
            with open(
                (save_path / parquet_file)
                .resolve(strict=True)
                .with_name(str(parquet_info_name)),
                "wb",
            ) as fp:
                fp.write(parquet_data.as_py())


def upload_obs_data(
    autoscenes_id: str,
    local_file_name: str,
    file_name: str,
    is_guiyang: bool = False,
    *,
    ak: str,
    sk: str,
    bucket_url: str,
) -> int:
    """
    将数据生产结果上传到obs桶

    :param autoscenes_id: 数据的唯一标识符
    :param local_file_name: 待上传文件的完整路径
    :param file_name: 待上传文件在obs桶autoscenes id文件夹内的相对路径
    :param is_guiyang：是否是贵阳云上
    :param ak: 访问密钥ID
    :param sk: 秘密访问密钥
    :param bucket_url: 存储桶的URL
    :return: obs文件上传状态的HTTP状态码，小于300表示成功
    """

    # 配置OBS客户端
    obs_client = config_obs(ak, sk, bucket_url)

    # 去掉autoscenes_id中斜杠后内容，如果此时autoscenes_id为空则抛出异常
    valid_autoscenes_id = autoscenes_id.split("/")[0]
    if not valid_autoscenes_id:
        raise ValueError(f"Invalid autoscenes id: {autoscenes_id}")

    # 云上云下地址不同
    if is_guiyang:
        bucket_name = "ads-cloud-gy-y"
        bucket_folder_prefix = "data/god/autoscenes-prod/data"
    else:
        bucket_name = "bev4d-autolabeling"
        bucket_folder_prefix = "simulation/end2end_preprocess"

    # 调用obs客户端的putFile方法上传文件，并返回上传状态
    return obs_client.putFile(
        bucket_name,
        f"{bucket_folder_prefix}/{valid_autoscenes_id}/{file_name.rstrip('/')}",
        local_file_name,
    ).status


def remove_redundant_autoscenes_file(
    download_target: Path, files_to_keep: Set[str]
) -> None:
    """
    删除下载目标中的冗余文件

    :param download_target: 下载目标的绝对路径
    :param files_to_keep: 需要保留的文件名的集合
    """

    # 初始化冗余路径集合
    redundant_paths = set()

    # 遍历下载目标的所有子目录和文件
    for current_path, sub_directories, file_names in os.walk(download_target):

        # 如果当前路径包含需要保留的文件名或者已经被确认为是冗余路径的话，跳过当前循环
        if any(map(current_path.__contains__, files_to_keep | redundant_paths)):
            continue

        # 获取当前路径下所有子项（包括子目录和文件）相对下载根目录的路径
        normalized_child_items = (
            str((Path(current_path) / child_item).relative_to(download_target))
            for child_item in sub_directories + file_names
        )

        # 过滤出需要删除的子项（不在需要保留的文件名集合中的子项）
        redundant_child_items = filter(
            lambda normalized_child_item: not any(
                normalized_child_item in file_to_keep for file_to_keep in files_to_keep
            ),
            normalized_child_items,
        )

        # 将需要删除的子项添加到冗余路径集合中
        redundant_paths.update(redundant_child_items)

    # 冗余路径集合转为绝对路径列表
    normalized_redundant_paths = sorted(
        map(download_target.__truediv__, redundant_paths)
    )

    # 遍历冗余路径的绝对路径，删除对应的文件或目录
    frozenset(
        (
            shutil.rmtree(normalized_redundant_path, ignore_errors=True)
            if normalized_redundant_path.is_dir()
            else normalized_redundant_path.unlink(missing_ok=True)
        )
        for normalized_redundant_path in normalized_redundant_paths
    )
