import os
import json
import re
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, List, Tuple

# === 基础数据结构与你的代码保持一致 ===
@dataclass
class EgoPose:
    timestamp: float
    velocity: Optional[float]
    acc_long: Optional[float]
    acc_lat: Optional[float]
    steer: Optional[float]

def load_ego_pose_json(file_path: str) -> List[EgoPose]:
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    poses = []
    for item in sorted(data, key=lambda x: x['timestamp']):
        velocity = item.get('chassis_velocity')
        acc = item.get('acceleration', [])
        acc_long = acc[0] if acc and len(acc) >= 1 else None
        poses.append(EgoPose(item['timestamp'], velocity, acc_long, None, None))
    return poses

def detect_hard_brake_events(poses: List[EgoPose], threshold: float = -5.0) -> List[Tuple[int, int]]:
    events = []
    in_brake = False
    start_idx, peak_idx = 0, 0
    peak_value = 0.0
    recovery_counter = 0
    
    for i, pose in enumerate(poses):
        if pose.acc_long is None: continue
        if pose.acc_long < threshold and not in_brake:
            in_brake, start_idx, peak_idx, peak_value = True, i, i, pose.acc_long
            recovery_counter = 0
        elif pose.acc_long < threshold and in_brake:
            if pose.acc_long < peak_value:
                peak_idx, peak_value = i, pose.acc_long
            recovery_counter = 0
        elif pose.acc_long >= threshold:
            if in_brake:
                if pose.acc_long >= -2.0:
                    recovery_counter += 1
                    if recovery_counter >= 3:
                        in_brake = False
                        if peak_value < threshold:
                            events.append((start_idx, peak_idx))
                        recovery_counter = 0
                else:
                    recovery_counter = 0
    if in_brake and peak_value < threshold:
        events.append((start_idx, peak_idx))
    return events

def get_real_video_start_ts(autoscene_id: str, base_cache_dir: str) -> float:
    cam_dir = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples" / "CAM_FRONT_WIDE_ANGLE"
    if not cam_dir.exists():
        cam_dir = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples"
    if cam_dir.exists():
        all_timestamps = []
        for img_path in cam_dir.rglob("*.jpg"):
            match = re.search(r'_(\d{16})\.jpg', img_path.name)
            if match:
                all_timestamps.append(float(match.group(1)))
        if all_timestamps:
            return min(all_timestamps)
    return None

def main():
    target_id = "4d50d0f424ff415187a98e6b8ecdd789"
    # 请确认这里的路径与你服务器一致
    ego_pose_dir = "/home/ma-user/work/lyf/debug_cache" 
    camera_cache_dir = "/cache"
    
    autoscene_dir = Path(ego_pose_dir) / target_id
    ego_pose_files = list(autoscene_dir.rglob("ego_pose.json"))
    
    if not ego_pose_files:
        print(f"❌ 找不到数据: {target_id} 的 ego_pose.json")
        return
        
    poses = load_ego_pose_json(str(ego_pose_files[0]))
    video_start_ts = get_real_video_start_ts(target_id, camera_cache_dir)
    
    is_fallback = False
    if not video_start_ts:
        video_start_ts = poses[0].timestamp
        is_fallback = True
        
    print(f"\n{'='*60}")
    print(f"🚗 Debug 场景: {target_id}")
    print(f"{'='*60}")
    
    print("\n[1] 时间戳对齐情况:")
    print(f"  - 视频/图片起始时间 (0秒点): {video_start_ts} {'(⚠️退化使用ego_pose)' if is_fallback else ''}")
    print(f"  - Ego_pose 数据起始时间: {poses[0].timestamp}")
    print(f"  - 时间差: {(video_start_ts - poses[0].timestamp)/1e6:.2f} 秒")
    
    events = detect_hard_brake_events(poses, -5.0)
    print(f"\n[2] 检测到的所有急刹事件 (阈值 -5.0): 共 {len(events)} 次")
    
    for i, (start_idx, peak_idx) in enumerate(events):
        start_pose = poses[start_idx]
        peak_pose = poses[peak_idx]
        
        start_rel_s = (start_pose.timestamp - video_start_ts) / 1e6
        peak_rel_s = (peak_pose.timestamp - video_start_ts) / 1e6
        
        print(f"  🔹 事件 {i+1}:")
        print(f"     - 刹车【开始】相对时间: {start_rel_s:.2f} s  <-- 你的原代码取的是这个值！")
        print(f"     - 刹车【峰值】相对时间: {peak_rel_s:.2f} s  <-- 这里通常是刹车最狠的地方")
        print(f"     - 峰值加速度: {peak_pose.acc_long:.2f} m/s²")

    print(f"\n[3] 7秒 ~ 11秒 的原始纵向加速度数据走势:")
    print(f"  相对时间(s) | 加速度(m/s²) | 状态")
    print(f"  {'-'*40}")
    
    for pose in poses:
        rel_s = (pose.timestamp - video_start_ts) / 1e6
        if 7.0 <= rel_s <= 11.5:
            acc = pose.acc_long if pose.acc_long is not None else 0.0
            marker = "  ⚠️ 跌破 -5.0" if acc < -5.0 else ""
            if acc < -8.0: marker = "  🚨 严重急刹 <-8.0"
            print(f"  {rel_s:10.2f} | {acc:12.2f} | {marker}")
            
    print(f"\n{'='*60}\n")

if __name__ == "__main__":
    main()