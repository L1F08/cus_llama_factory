import os
import json
import random
import re
import subprocess
import pandas as pd
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

# ==================== 配置参数 ====================
# 改为你的测试集 JSONL 路径
TEST_JSONL_PATH = "/home/ma-user/work/lyf/data/0506_crash_1cam_2cls_test_39k_3s/test_0506_crash_1cam_2cls_test_39k_3s_front_with_ego_info_5256.jsonl"
CLASS0_EXCEL_PATH = "/home/ma-user/work/lyf/recent_AEB/AEB_class0.xlsx"
CROP_CONFIG_CSV = "/home/ma-user/work/lyf/data/0506_crash_1cam_2cls_test_39k_3s/aeb_analysis_output_3s_0513/video_crop_config.csv"
OUTPUT_DIR = "/home/ma-user/work/lyf/video_after_clip_3s"

# 自动处理后缀名替换为 _clipped_cleaned.jsonl
if TEST_JSONL_PATH.endswith(".jsonl"):
    OUTPUT_JSONL_PATH = TEST_JSONL_PATH.replace(".jsonl", "_3s_clipped_cleaned.jsonl")
else:
    OUTPUT_JSONL_PATH = TEST_JSONL_PATH + "_3s_clipped_cleaned.jsonl"

MAX_WORKERS = min(180, os.cpu_count() or 64)
TARGET_RANDOM_DURATION = 3.0

# ==================== 辅助函数 ====================
def get_video_duration(video_path: str) -> float:
    """双保险获取视频时长，提取失败直接报错，拒绝静默返回0"""
    # 方案 A: 优先使用最稳定的 ffprobe
    try:
        cmd = [
            'ffprobe', '-v', 'error', '-show_entries', 
            'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 
            str(video_path)
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = result.stdout.strip()
        if out and out != 'N/A':
            return float(out)
    except Exception:
        pass

    # 方案 B: 使用 ffmpeg 正则兜底 (兼容没有小数点的情况)
    try:
        cmd = ['ffmpeg', '-i', str(video_path)]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", result.stderr)
        if match:
            h, m, s = match.groups()
            return float(h) * 3600 + float(m) * 60 + float(s)
    except Exception:
        pass
        
    raise ValueError(f"无法读取视频时长，可能是视频文件损坏或 ffmpeg 环境异常")

# def crop_video_ffmpeg(input_path: str, output_path: str, start_s: float, duration_s: float = None):
#     cmd = ['ffmpeg', '-y', '-ss', str(start_s), '-i', str(input_path)]
#     if duration_s is not None:
#         cmd.extend(['-t', str(duration_s)]) 
#     cmd.extend(['-c', 'copy', str(output_path)])
    
#     result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
#     if result.returncode != 0:
#         err_msg = result.stderr.strip().split('\n')[-1]
#         raise RuntimeError(f"FFmpeg 裁剪失败: {err_msg}")

# def copy_video_ffmpeg(input_path: str, output_path: str):
#     cmd = ['ffmpeg', '-y', '-i', str(input_path), '-c', 'copy', str(output_path)]
#     result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
#     if result.returncode != 0:
#         err_msg = result.stderr.strip().split('\n')[-1]
#         raise RuntimeError(f"FFmpeg 复制失败: {err_msg}")


def crop_video_ffmpeg(input_path: str, output_path: str, start_s: float, duration_s: float = None):
    # 将 -ss 放在 -i 之前（快速定位），但去掉 -c copy，强制重新编码
    cmd = ['ffmpeg', '-y', '-ss', str(start_s), '-i', str(input_path)]
    if duration_s is not None:
        cmd.extend(['-t', str(duration_s)]) 
        
    # 替换掉 '-c copy'，使用重新编码 (以H.264为例)
    # -c:v libx264 重新编码视频
    # -c:a aac 重新编码音频（如果不需要音频可以加 -an）
    # -avoid_negative_ts 1 修复重新编码后首帧时间戳可能为负的问题
    cmd.extend(['-c:v', 'libx264', '-c:a', 'aac', '-avoid_negative_ts', '1', str(output_path)])
    
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        err_msg = result.stderr.strip().split('\n')[-1]
        raise RuntimeError(f"FFmpeg 裁剪失败: {err_msg}")

# ==================== 核心 Worker ====================
def process_single_video(task_info: dict) -> dict:
    vid_id = task_info['id']
    v_type = task_info['type']
    input_path = task_info['input_path']
    output_path = task_info['output_path']
    
    result_log = {"id": vid_id, "status": "success", "msg": ""}

    if not os.path.exists(input_path):
        result_log["status"] = "error"
        result_log["msg"] = f"原视频不存在: {input_path}"
        return result_log

    try:
        if v_type == 'target_with_config':
            crop_start = task_info['crop_start_s']
            duration = task_info['duration_s']
            crop_video_ffmpeg(input_path, output_path, crop_start, duration)
            result_log["msg"] = f"精准裁剪: {crop_start}s -> {crop_start+duration}s"

        elif v_type == 'random_crop':
            dur = get_video_duration(input_path)
            if dur <= TARGET_RANDOM_DURATION:
                copy_video_ffmpeg(input_path, output_path)
                result_log["msg"] = f"原片过短({dur:.2f}s)直接复制"
            else:
                # 同一场景的多个摄像头用相同随机起点（按 autoscene_id 设种子），跨摄像头对齐
                rng = random.Random(vid_id)
                random_start = rng.uniform(0, dur - TARGET_RANDOM_DURATION)
                crop_video_ffmpeg(input_path, output_path, random_start, TARGET_RANDOM_DURATION)
                result_log["msg"] = f"随机裁剪({dur:.2f}s原片) 起点:{random_start:.2f}s"
                
    except Exception as e:
        result_log["status"] = "error"
        result_log["msg"] = str(e)

    return result_log

# ==================== 主控逻辑 ====================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    print("=" * 60)
    print("AEB 数据集视频并发裁剪 & 自动清洗死数据 (JSONL 版)")
    print("=" * 60)

    # 1. 解析 Excel 白名单
    allowed_class0_ids = set()
    if os.path.exists(CLASS0_EXCEL_PATH):
        df_excel = pd.read_excel(CLASS0_EXCEL_PATH)
        allowed_class0_ids = set(df_excel['data_name'].astype(str).str.strip().tolist())

    # 2. 读取 CSV 裁剪配置
    crop_config_dict = {}
    if os.path.exists(CROP_CONFIG_CSV):
        df_csv = pd.read_csv(CROP_CONFIG_CSV)
        for _, row in df_csv.iterrows():
            crop_config_dict[str(row['autoscene_id']).strip()] = {
                'start': float(row['crop_start_s']),
                'duration': float(row['duration_s'])
            }

    # 3. 解析 JSONL 并在内存中构建清理后的新 JSONL 列表
    tasks = []
    task_counts = {'target_with_config': 0, 'deleted_missing_config': 0, 'random_crop': 0}
    filtered_jsonl_data = [] 
    
    # 逐行读取 JSONL
    with open(TEST_JSONL_PATH, 'r', encoding='utf-8') as f:
        lines = f.readlines()


    # 在 for line in lines: 之前加两个计数器
    id_counter = {}
    multi_video_ids = []
    
    for line in lines:
        item = json.loads(line)
        autoscene_id = str(item.get("id", ""))
        
        # 统计 ID 出现次数 (排查情况2)
        id_counter[autoscene_id] = id_counter.get(autoscene_id, 0) + 1
        
        # 统计单条数据里的视频数量 (排查情况1)
        video_count = sum(1 for c in item.get("content", []) if c.get("type") == "video")
        if video_count > 1:
            multi_video_ids.append(autoscene_id)
    
    # 循环结束后打印看看
    print(f"包含多个视频的 ID 数量: {len(multi_video_ids)}")
    print(f"在 JSONL 中出现重复的 ID 数量: {len([k for k, v in id_counter.items() if v > 1])}")
    for line in lines:
        if not line.strip():
            continue
            
        item = json.loads(line)
        # 从顶层获取 label 和 id
        label = int(item.get("label", 0))  # 这里已经是数字格式了
        autoscene_id = str(item.get("id", ""))
        
        keep_this_item = True
        item_tasks = []

        # 遍历 content 列表寻找 video 字典
        for content_dict in item.get("content", []):
            if content_dict.get("type") == "video":
                video_path = content_dict.get("video")
                # 按来源摄像头目录分桶输出，避免 front/left/right 同名 <id>.mp4 互相覆盖
                cam_subdir = Path(video_path).parent.name
                os.makedirs(os.path.join(OUTPUT_DIR, cam_subdir), exist_ok=True)
                output_path = os.path.join(OUTPUT_DIR, cam_subdir, f"{autoscene_id}.mp4")
                
                # 判定逻辑保持一致
                if label == 1 or (label == 0 and autoscene_id in allowed_class0_ids):
                    if autoscene_id in crop_config_dict:
                        # 正常处理，原地更新路径
                        content_dict["video"] = output_path
                        item_tasks.append({
                            'id': autoscene_id, 'type': 'target_with_config',
                            'input_path': video_path, 'output_path': output_path,
                            'crop_start_s': crop_config_dict[autoscene_id]['start'],
                            'duration_s': crop_config_dict[autoscene_id]['duration']
                        })
                    else:
                        # 缺失配置，标记为遗弃整个 item
                        keep_this_item = False
                else:
                    # 负样例随机裁剪，原地更新路径
                    content_dict["video"] = output_path
                    item_tasks.append({
                        'id': autoscene_id, 'type': 'random_crop',
                        'input_path': video_path, 'output_path': output_path
                    })

        # 如果 item 被标记为保留，且确实含有至少一个视频任务，则存入过滤列表
        if keep_this_item and len(item_tasks) > 0:
            tasks.extend(item_tasks)
            filtered_jsonl_data.append(item)
            for t in item_tasks:
                task_counts[t['type']] += 1
        else:
            # 被拦截的数据
            task_counts['deleted_missing_config'] += 1

    print("\n[清洗与任务分布清单]")
    print(f"  👉 准备按 CSV 精准裁剪: {task_counts['target_with_config']} 个视频")
    print(f"  👉 负样例准备随机截 {TARGET_RANDOM_DURATION} 秒: {task_counts['random_crop']} 个视频")
    print(f"  🗑️ 已从新 JSONL 中彻底删除缺失配置的废数据: {task_counts['deleted_missing_config']} 条")
    print(f"  ➡️ 总计进入视频处理队列: {len(tasks)} 个")
    
    # 4. 并发裁剪
    print(f"\n启动并发引擎 (核心数: {MAX_WORKERS})...")
    success_count = 0
    error_count = 0
    
    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(process_single_video, task): task for task in tasks}
        
        for future in tqdm(as_completed(futures), total=len(tasks), desc="处理进度", unit="个"):
            result = future.result()
            if result["status"] == "success":
                success_count += 1
            else:
                error_count += 1
                tqdm.write(f"❌ 失败 [{result['id']}]: {result['msg']}")

    # 5. 保存清理后的新 JSONL
    try:
        with open(OUTPUT_JSONL_PATH, 'w', encoding='utf-8') as f:
            for new_item in filtered_jsonl_data:
                # 逐行转储为 JSON 字符串并写入
                f.write(json.dumps(new_item, ensure_ascii=False) + '\n')
        print(f"\n✅ 经过清洗的全新 JSONL (共 {len(filtered_jsonl_data)} 条数据) 已保存: {OUTPUT_JSONL_PATH}")
    except Exception as e:
        print(f"\n❌ 保存 JSONL 失败: {str(e)}")

    print("\n" + "=" * 60)
    print(f"🎉 全部执行完毕！")
    print(f"  ✅ 成功处理: {success_count} 个")
    print(f"  ❌ 失败或报错: {error_count} 个")
    print("=" * 60)

if __name__ == "__main__":
    main()