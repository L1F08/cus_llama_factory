import os
import json
import random
import subprocess
import re
import pandas as pd
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

# ==================== 配置参数 ====================
TRAIN_JSON_PATH = "/home/ma-user/work/lyf/data/0604_crash_1cam_2cls_train_all_3s_-3_0/train_0604_crash_1cam_2cls_train_all_3s_-3_0_front_with_ego_info_54906.json"
CLASS0_EXCEL_PATH = "/home/ma-user/work/lyf/recent_AEB/AEB_class0.xlsx"
CROP_CONFIG_CSV = "/home/ma-user/work/lyf/data/0604_crash_1cam_2cls_train_all_3s_-3_0/aeb_analysis_output_3s/video_crop_config_3s.csv"
OUTPUT_DIR = "/home/ma-user/work/lyf/video_after_clip_3s_-3_0_all"

OUTPUT_JSON_PATH = TRAIN_JSON_PATH.replace(".json", "_3s_clipped_cleaned.json")
# 【新增】定义随机切片记录的保存路径
RANDOM_RECORD_CSV_PATH = os.path.join(OUTPUT_DIR, "random_crop_records.csv")

MAX_WORKERS = min(180, os.cpu_count() or 64)
TARGET_RANDOM_DURATION = 3.0

# ==================== 辅助函数 ====================
def get_video_duration(video_path: str) -> float:
    """双保险获取视频时长，提取失败直接报错，拒绝静默返回0"""
    # 方案 A: 优先使用最稳定的 ffprobe
    try:
        cmd = [
            'ffprobe', '-v', 'error', '-show_entries', 
            'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', 
            str(video_path)
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = result.stdout.strip()
        if out and out != 'N/A':
            return float(out)
    except Exception:
        pass

    # 方案 B: 使用 ffmpeg 正则兜底 (兼容没有小数点的情况)
    try:
        cmd = ['ffmpeg', '-i', str(video_path)]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        # 正则优化：(\d+(?:\.\d+)?) 兼容 "15.03" 和纯整数 "15"
        match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", result.stderr)
        if match:
            h, m, s = match.groups()
            return float(h) * 3600 + float(m) * 60 + float(s)
    except Exception:
        pass
        
    # 如果都失败了，抛出异常，让主程序捕获
    raise ValueError(f"无法读取视频时长，可能是视频文件损坏或 ffmpeg 环境异常")


def crop_video_ffmpeg(input_path: str, output_path: str, start_s: float, duration_s: float = None):
    # 将 -ss 放在 -i 之前（快速定位），但去掉 -c copy，强制重新编码
    cmd = ['ffmpeg', '-y', '-ss', str(start_s), '-i', str(input_path)]
    if duration_s is not None:
        cmd.extend(['-t', str(duration_s)]) 
        
    # 替换掉 '-c copy'，使用重新编码 (以H.264为例)
    # -c:v libx264 重新编码视频
    # -c:a aac 重新编码音频（如果不需要音频可以加 -an）
    # -avoid_negative_ts 1 修复重新编码后首帧时间戳可能为负的问题
    cmd.extend(['-c:v', 'libx264', '-c:a', 'aac', '-avoid_negative_ts', '1', str(output_path)])
    
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        err_msg = result.stderr.strip().split('\n')[-1]
        raise RuntimeError(f"FFmpeg 裁剪失败: {err_msg}")

def copy_video_ffmpeg(input_path: str, output_path: str):
    cmd = ['ffmpeg', '-y', '-i', str(input_path), '-c', 'copy', str(output_path)]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        err_msg = result.stderr.strip().split('\n')[-1]
        raise RuntimeError(f"FFmpeg 复制失败: {err_msg}")

# ==================== 核心 Worker ====================
def process_single_video(task_info: dict) -> dict:
    vid_id = task_info['id']
    v_type = task_info['type']
    input_path = task_info['input_path']
    output_path = task_info['output_path']
    
    result_log = {"id": vid_id, "status": "success", "msg": "", "v_type": v_type}

    if not os.path.exists(input_path):
        result_log["status"] = "error"
        result_log["msg"] = f"原视频不存在: {input_path}"
        return result_log

    try:
        if v_type == 'target_with_config':
            crop_start = task_info['crop_start_s']
            duration = task_info['duration_s']
            crop_video_ffmpeg(input_path, output_path, crop_start, duration)
            result_log["msg"] = f"精准裁剪: {crop_start}s -> {crop_start+duration}s"

        elif v_type == 'random_crop':
            dur = get_video_duration(input_path)
            
            # 【修改】记录具体切片的起始和结束时间
            if dur <= TARGET_RANDOM_DURATION:
                copy_video_ffmpeg(input_path, output_path)
                result_log["msg"] = f"原片过短({dur:.2f}s)直接复制"
                result_log["crop_start"] = 0.0
                result_log["crop_end"] = dur
                result_log["duration"] = dur
            else:
                # 同一场景的多个摄像头用相同随机起点（按 autoscene_id 设种子），
                # 保证负样例跨摄像头切到同一真实时间段、对齐（前提：各路时长已被 make_video 对齐为一致）
                rng = random.Random(vid_id)
                random_start = rng.uniform(0, dur - TARGET_RANDOM_DURATION)
                crop_video_ffmpeg(input_path, output_path, random_start, TARGET_RANDOM_DURATION)
                result_log["msg"] = f"随机裁剪({dur:.2f}s原片) 起点:{random_start:.2f}s"
                result_log["crop_start"] = round(random_start, 3)
                result_log["crop_end"] = round(random_start + TARGET_RANDOM_DURATION, 3)
                result_log["duration"] = TARGET_RANDOM_DURATION
                
    except Exception as e:
        result_log["status"] = "error"
        result_log["msg"] = str(e)

    return result_log

# ==================== 主控逻辑 ====================
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    print("=" * 60)
    print("AEB 数据集视频并发裁剪 & 自动清洗死数据")
    print("=" * 60)

    # 1. 解析 Excel 白名单
    allowed_class0_ids = set()
    if os.path.exists(CLASS0_EXCEL_PATH):
        df_excel = pd.read_excel(CLASS0_EXCEL_PATH)
        allowed_class0_ids = set(df_excel['data_name'].astype(str).str.strip().tolist())

    # 2. 读取 CSV 裁剪配置
    crop_config_dict = {}
    if os.path.exists(CROP_CONFIG_CSV):
        df_csv = pd.read_csv(CROP_CONFIG_CSV)
        for _, row in df_csv.iterrows():
            crop_config_dict[str(row['autoscene_id']).strip()] = {
                'start': float(row['crop_start_s']),
                'duration': float(row['duration_s'])
            }

    # 3. 解析 JSON 并在内存中构建清理后的新 JSON 列表
    tasks = []
    task_counts = {'target_with_config': 0, 'deleted_missing_config': 0, 'random_crop': 0}
    filtered_json_data = [] 
    
    with open(TRAIN_JSON_PATH, 'r', encoding='utf-8') as f:
        json_data = json.load(f)
        
    for item in json_data:
        label = "0"
        for msg in item.get("messages", []):
            if msg.get("role") == "assistant":
                label = str(msg.get("content", "")).strip()
                break
        
        new_video_paths = []
        for video_path in item.get("videos", []):
            autoscene_id = Path(video_path).stem
            # 按来源摄像头目录分桶输出，避免 front/left/right 同名 <id>.mp4 互相覆盖
            cam_subdir = Path(video_path).parent.name
            os.makedirs(os.path.join(OUTPUT_DIR, cam_subdir), exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, cam_subdir, f"{autoscene_id}.mp4")
            
            if label == "1" or (label == "0" and autoscene_id in allowed_class0_ids):
                if autoscene_id in crop_config_dict:
                    new_video_paths.append(output_path)
                    task_info = {
                        'id': autoscene_id, 'type': 'target_with_config',
                        'input_path': video_path, 'output_path': output_path,
                        'crop_start_s': crop_config_dict[autoscene_id]['start'],
                        'duration_s': crop_config_dict[autoscene_id]['duration']
                    }
                    tasks.append(task_info)
                    task_counts['target_with_config'] += 1
                else:
                    task_counts['deleted_missing_config'] += 1
                    pass 
            else:
                new_video_paths.append(output_path)
                task_info = {
                    'id': autoscene_id, 'type': 'random_crop',
                    'input_path': video_path, 'output_path': output_path
                }
                tasks.append(task_info)
                task_counts['random_crop'] += 1
                
        if len(new_video_paths) > 0:
            item["videos"] = new_video_paths
            filtered_json_data.append(item)

    print("\n[清洗与任务分布清单]")
    print(f"  👉 准备按 CSV 精准裁剪: {task_counts['target_with_config']} 个视频")
    print(f"  👉 负样例准备随机截 5 秒: {task_counts['random_crop']} 个视频")
    print(f"  🗑️ 已从新 JSON 中彻底删除缺失配置的废数据: {task_counts['deleted_missing_config']} 个")
    print(f"  ➡️ 总计进入处理队列: {len(tasks)} 个")
    
    # 4. 并发裁剪
    print(f"\n启动并发引擎 (核心数: {MAX_WORKERS})...")
    success_count = 0
    error_count = 0
    
    # 【新增】存放记录的 List
    random_crop_records = []
    
    with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(process_single_video, task): task for task in tasks}
        
        for future in tqdm(as_completed(futures), total=len(tasks), desc="处理进度", unit="个"):
            result = future.result()
            if result["status"] == "success":
                success_count += 1
                # 【新增】捕获随机切片的起止时间
                if result.get("v_type") == "random_crop":
                    random_crop_records.append({
                        "autoscene_id": result["id"],
                        "crop_start_s": result["crop_start"],
                        "crop_end_s": result["crop_end"],
                        "duration_s": result["duration"]
                    })
            else:
                error_count += 1
                tqdm.write(f"❌ 失败 [{result['id']}]: {result['msg']}")

    # 【新增】5. 保存随机切片的时间记录为 CSV
    if random_crop_records:
        try:
            df_records = pd.DataFrame(random_crop_records)
            df_records.to_csv(RANDOM_RECORD_CSV_PATH, index=False, encoding='utf-8')
            print(f"\n✅ 已保存负样例随机切片记录表 (共 {len(random_crop_records)} 条): {RANDOM_RECORD_CSV_PATH}")
        except Exception as e:
            print(f"\n❌ 保存随机切片记录表失败: {str(e)}")

    # 6. 保存清理后的新 JSON
    try:
        with open(OUTPUT_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(filtered_json_data, f, ensure_ascii=False, indent=2)
        print(f"✅ 经过清洗的全新 JSON (共 {len(filtered_json_data)} 条对话) 已保存: {OUTPUT_JSON_PATH}")
    except Exception as e:
        print(f"❌ 保存 JSON 失败: {str(e)}")

    print("\n" + "=" * 60)
    print(f"🎉 全部执行完毕！")
    print(f"  ✅ 成功处理: {success_count} 个")
    print(f"  ❌ 失败或报错: {error_count} 个")
    print("=" * 60)

if __name__ == "__main__":
    main()