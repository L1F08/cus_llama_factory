# import os
# import json
# import re
# import pandas as pd
# from pathlib import Path
# from typing import Set, Tuple, Dict, List
# from concurrent.futures import ProcessPoolExecutor, as_completed
# from tqdm import tqdm  # 用于显示牛逼的进度条

# # 导入你之前的核心算法
# from analysis_new import (
#     Config, 
#     load_ego_pose_json,  # 注意：这里只需要底层的单个加载函数
#     detect_hard_brake_events
# )

# class ExtendedConfig(Config):
#     CLASS0_EXCEL_PATH = "/home/ma-user/work/lyf/recent_AEB/AEB_class0.xlsx"
#     TEST_JSONL_PATH = "/home/ma-user/work/lyf/data/0417_crash_1cam_2cls_test_v5_3s/test_0417_crash_1cam_2cls_test_v5_3s_front_with_ego_info_1000.jsonl"  # 替换为你的jsonl路径
#     OUTPUT_DIR = "/home/ma-user/work/lyf/data/0417_crash_1cam_2cls_test_v5_3s/aeb_analysis_output_3s"
#     POSITIVE_LABEL = "1" # 确保统一为字符串形式处理
#     NEGATIVE_LABEL = "0"
#     CAMERA_CACHE_DIR = "/cache"
#     MAX_WORKERS = min(30, os.cpu_count() or 180)


# def extract_target_autoscene_ids(jsonl_path: str, excel_path: str, positive_label: str, negative_label: str) -> Set[str]:
#     # 1. 读取允许的负样例ID (保持不变)
#     allowed_negative_ids = set()
#     if os.path.exists(excel_path):
#         try:
#             df = pd.read_excel(excel_path)
#             for _, row in df.iterrows():
#                 uid = str(row.get('data_name', '')).strip()
#                 if uid:
#                     allowed_negative_ids.add(uid)
#             print(f"  [读取Excel] 加载了 {len(allowed_negative_ids)} 个允许的负样例 ID。")
#         except Exception as e:
#             print(f"  [读取Excel] 失败: {e}")

#     target_ids = set()
    
#     # 2. 逐行解析 JSONL 文件
#     with open(jsonl_path, 'r', encoding='utf-8') as f:
#         for line in f:
#             line = line.strip()
#             if not line:
#                 continue
            
#             try:
#                 item = json.loads(line)
#             except json.JSONDecodeError:
#                 continue

#             # 提取 label (直接读取顶层字段并转为字符串)
#             label = str(item.get("label", "")).strip()

#             # 提取当前数据包含的场景 ID (解析 content 列表寻找 video 路径)
#             current_item_ids = set()
#             for content_item in item.get("content", []):
#                 if content_item.get("type") == "video" and "video" in content_item:
#                     video_path = content_item["video"]
#                     autoscene_id = Path(video_path).stem
#                     if autoscene_id:
#                         current_item_ids.add(autoscene_id)
            
#             # (备用方案：如果你的 "id" 字段和视频文件名完全一致，也可以直接提取)
#             # autoscene_id = str(item.get("id", "")).strip()
#             # if autoscene_id:
#             #     current_item_ids.add(autoscene_id)

#             # 3. 判断是否加入目标队列 (逻辑与之前完全保持一致)
#             if label == positive_label:
#                 target_ids.update(current_item_ids)
#             elif label == negative_label:
#                 target_ids.update(current_item_ids.intersection(allowed_negative_ids))

#     return target_ids


# def get_real_video_start_ts(autoscene_id: str, base_cache_dir: str) -> float:
#     # (此函数保持不变)
#     cam_dir = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples" / "CAM_FRONT_WIDE_ANGLE"
#     if not cam_dir.exists():
#         cam_dir = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples"
        
#     if cam_dir.exists():
#         all_timestamps = []
#         for img_path in cam_dir.rglob("*.jpg"):
#             match = re.search(r'_(\d{16})\.jpg', img_path.name)
#             if match:
#                 all_timestamps.append(float(match.group(1)))
#         if all_timestamps:
#             return min(all_timestamps)
#     return None


# # ==========================================
# # 核心 Worker 函数：处理单个场景（完全独立，线程安全）
# # ==========================================
# def process_single_scene(autoscene_id: str, config: ExtendedConfig) -> Tuple[Dict, List[Dict], str]:
#     """
#     独立处理单个场景。
#     返回: (截短配置字典, 长间隔异常列表, 需要打印的日志信息)
#     """
#     log_msg = ""
    
#     # 1. 加载本场景的 ego_pose
#     autoscene_dir = Path(config.EGO_POSE_DIR) / autoscene_id
#     ego_pose_files = list(autoscene_dir.rglob("ego_pose.json"))
    
#     if not ego_pose_files:
#         return None, [], ""  # 缺失数据，静默跳过或可记录日志
        
#     poses = load_ego_pose_json(str(ego_pose_files[0]))
#     if not poses:
#         return None, [], ""

#     # 2. 检测急刹
#     events = detect_hard_brake_events(poses, config.HARD_BRAKE_THRESHOLD)
#     if not events:
#         return None, [], ""

#     # 3. 找视频绝对 0 秒
#     video_start_ts = get_real_video_start_ts(autoscene_id, config.CAMERA_CACHE_DIR)
#     if not video_start_ts:
#         video_start_ts = poses[0].timestamp
#         log_msg = f"  ⚠️ [图片缺失] {autoscene_id} 退化使用 ego_pose 时间\n"

#     # 4. 寻找视频内的首次有效刹车
#     valid_brake_idx = -1
#     valid_brake_ts = 0.0
#     valid_brake_time_s = 0.0

#     for i, event in enumerate(events):
#         brake_ts = poses[event[0]].timestamp
#         brake_time_s = (brake_ts - video_start_ts) / 1e6
#         if brake_time_s >= 0:
#             valid_brake_idx = i
#             valid_brake_ts = brake_ts
#             valid_brake_time_s = brake_time_s
#             break

#     if valid_brake_idx == -1:
#         return None, [], log_msg + f"  ⚠️ [全在画外] {autoscene_id} 所有刹车均在图片之前，跳过\n"

#     # 5. 生成截短字典
#     crop_start_s = max(0.0, valid_brake_time_s - 2.0)
#     crop_end_s = valid_brake_time_s + 1.0

#     crop_dict = {
#         'autoscene_id': autoscene_id,
#         'video_start_ts': video_start_ts, 
#         'first_valid_brake_ts': valid_brake_ts, 
#         'brake_time_s': round(valid_brake_time_s, 2),
#         'crop_start_s': round(crop_start_s, 2),
#         'crop_end_s': round(crop_end_s, 2),
#         'duration_s': round(crop_end_s - crop_start_s, 2)
#     }

#     # 6. 生成长间隔异常列表
#     long_interval_list = []
#     if len(events) > 1:
#         for i in range(1, len(events)):
#             prev_ts = poses[events[i-1][0]].timestamp
#             curr_ts = poses[events[i][0]].timestamp
#             interval_s = (curr_ts - prev_ts) / 1e6

#             if interval_s > 5.0:
#                 long_interval_list.append({
#                     'autoscene_id': autoscene_id,
#                     'brake_index': i + 1,
#                     'interval_s': round(interval_s, 2),
#                     'prev_brake_time_s': round((prev_ts - video_start_ts) / 1e6, 2),
#                     'curr_brake_time_s': round((curr_ts - video_start_ts) / 1e6, 2)
#                 })

#     return crop_dict, long_interval_list, log_msg


# # ==========================================
# # 主函数：调度多进程并发
# # ==========================================
# def generate_crop_and_filter_configs_mp():
#     config = ExtendedConfig()
#     output_dir = config.OUTPUT_DIR
#     os.makedirs(output_dir, exist_ok=True)

#     print("=" * 60)
#     print(f"视频截短配置生成器 (⚡ 192核多进程满血版 - 并发数: {config.MAX_WORKERS})")
#     print("=" * 60)

#     # 1. 提取目标 ID
#     print("\n[1/2] 提取并解析目标 autoscene_id...")
#     target_ids = extract_target_autoscene_ids(
#         config.TEST_JSONL_PATH,  # <--- 替换为新的配置项
#         config.CLASS0_EXCEL_PATH, 
#         config.POSITIVE_LABEL, 
#         config.NEGATIVE_LABEL
#     )
#     if not target_ids:
#         print("未找到任何目标 ID，退出。")
#         return

#     # 准备收集结果的容器
#     all_crop_data = []
#     all_long_intervals = []
    
#     print(f"\n[2/2] 启动多进程并发处理 {len(target_ids)} 条数据...")
    
#     # 2. 核心：启动进程池
#     # 使用 ProcessPoolExecutor 绕过 Python GIL，实现真正的多核并行
#     with ProcessPoolExecutor(max_workers=config.MAX_WORKERS) as executor:
#         # 提交所有任务
#         futures = {executor.submit(process_single_scene, uid, config): uid for uid in target_ids}
        
#         # 使用 tqdm 包裹，实时显示完成进度
#         for future in tqdm(as_completed(futures), total=len(target_ids), desc="处理进度", unit="场景"):
#             try:
#                 crop_dict, long_interval_list, log_msg = future.result()
                
#                 # 如果工作线程传回了警告日志，直接打印出来
#                 if log_msg:
#                     tqdm.write(log_msg.strip())  # 使用 tqdm.write 防止打乱进度条显示
                
#                 # 收集有效结果
#                 if crop_dict:
#                     all_crop_data.append(crop_dict)
#                 if long_interval_list:
#                     all_long_intervals.extend(long_interval_list)
                    
#             except Exception as e:
#                 uid = futures[future]
#                 tqdm.write(f"  ❌ [致命错误] 处理 {uid} 时崩溃: {e}")

#     # 3. 输出汇总结果
#     print("\n" + "=" * 60)
#     print("[处理完成！正在保存 CSV 文件...]")
    
#     crop_df = pd.DataFrame(all_crop_data)
#     if not crop_df.empty:
#         crop_csv_path = os.path.join(output_dir, 'video_crop_config.csv')
#         crop_df.to_csv(crop_csv_path, index=False)
#         print(f"✅ 截短配置文件已保存至: {crop_csv_path} (共 {len(crop_df)} 条)")
    
#     long_interval_df = pd.DataFrame(all_long_intervals)
#     if not long_interval_df.empty:
#         long_interval_csv_path = os.path.join(output_dir, 'long_interval_brakes_to_review.csv')
#         long_interval_df.to_csv(long_interval_csv_path, index=False)
#         print(f"⚠️ 长时间间隔(>5s)多刹车场景已保存至: {long_interval_csv_path} (共 {len(long_interval_df)} 条)")


# if __name__ == "__main__":
#     generate_crop_and_filter_configs_mp()

import os
import json
import re
import pandas as pd
from collections import defaultdict
from pathlib import Path
from typing import Set, Tuple, Dict, List
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm  # 用于显示牛逼的进度条

# 导入你之前的核心算法
from analysis_new import (
    Config, 
    load_ego_pose_json,  # 注意：这里只需要底层的单个加载函数
    detect_hard_brake_events
)

class ExtendedConfig(Config):
    CLASS0_EXCEL_PATH = "/home/ma-user/work/lyf/recent_AEB/AEB_class0.xlsx"
    TEST_JSONL_PATH = "/home/ma-user/work/lyf/data/0506_crash_1cam_2cls_test_39k_3s/test_0506_crash_1cam_2cls_test_39k_3s_front_with_ego_info_5256.jsonl"  # 替换为你的jsonl路径
    OUTPUT_DIR = "/home/ma-user/work/lyf/data/0506_crash_1cam_2cls_test_39k_3s/aeb_analysis_output_3s_0513"
    POSITIVE_LABEL = "1" # 确保统一为字符串形式处理
    NEGATIVE_LABEL = "0"
    CAMERA_CACHE_DIR = "/cache"
    # ★★★ 必须与 config.yaml 的 cameras.use_cameras 及 make_video 使用的摄像头一致 ★★★
    # 缓存 /cache/.../samples 下真实的摄像头目录名；决定裁剪原点 t0 = max(各摄像头首帧)。
    USED_CAMERAS = ["CAM_FRONT_WIDE_ANGLE", "CAM_FISHEYE_LEFT", "CAM_FISHEYE_RIGHT"]
    MAX_WORKERS = min(30, os.cpu_count() or 180)


def extract_target_autoscene_ids(jsonl_path: str, excel_path: str, positive_label: str, negative_label: str) -> Set[str]:
    # 1. 读取允许的负样例ID
    allowed_negative_ids = set()
    if os.path.exists(excel_path):
        try:
            df = pd.read_excel(excel_path)
            for _, row in df.iterrows():
                uid = str(row.get('data_name', '')).strip()
                if uid:
                    allowed_negative_ids.add(uid)
            print(f"  [读取Excel] 加载了 {len(allowed_negative_ids)} 个允许的负样本 ID 白名单。")
        except Exception as e:
            print(f"  [读取Excel] 失败: {e}")

    target_ids = set()
    
    # === 新增：用于 DEBUG 统计的计数器 ===
    stats = {
        'total_json_lines': 0,
        'pos_samples_found': 0,
        'neg_samples_found': 0,
        'neg_samples_allowed_by_excel': 0
    }
    
    # 2. 逐行解析 JSONL 文件
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            stats['total_json_lines'] += 1
            
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue

            # 提取 label (直接读取顶层字段并转为字符串)
            label = str(item.get("label", "")).strip()

            # 提取当前数据包含的场景 ID (解析 content 列表寻找 video 路径)
            current_item_ids = set()
            for content_item in item.get("content", []):
                if content_item.get("type") == "video" and "video" in content_item:
                    video_path = content_item["video"]
                    autoscene_id = Path(video_path).stem
                    if autoscene_id:
                        current_item_ids.add(autoscene_id)
            
            # 3. 判断是否加入目标队列
            if label == positive_label:
                stats['pos_samples_found'] += len(current_item_ids)
                target_ids.update(current_item_ids)
            elif label == negative_label:
                stats['neg_samples_found'] += len(current_item_ids)
                # 计算有多少负样本通过了 Excel 过滤
                allowed_current = current_item_ids.intersection(allowed_negative_ids)
                stats['neg_samples_allowed_by_excel'] += len(allowed_current)
                target_ids.update(allowed_current)

    # === 打印提取阶段的流失情况 ===
    print("\n--- 🔍 第一阶段：ID 提取漏斗统计 ---")
    print(f"  1. 解析 JSONL 总行数: {stats['total_json_lines']}")
    print(f"  2. 发现正样本 (Label={positive_label}) ID 数量: {stats['pos_samples_found']} -> 全部保留")
    print(f"  3. 发现负样本 (Label={negative_label}) ID 数量: {stats['neg_samples_found']}")
    print(f"  4. 负样本被 Excel 白名单放行的数量: {stats['neg_samples_allowed_by_excel']}")
    print(f"  5. 第一阶段被拦截的负样本数量: {stats['neg_samples_found'] - stats['neg_samples_allowed_by_excel']}")
    print(f"  👉 最终进入多进程处理池的 ID 总数: {len(target_ids)}")
    print("------------------------------------\n")

    return target_ids


def get_real_video_start_ts(autoscene_id: str, base_cache_dir: str, used_cameras) -> float:
    """
    返回所有使用摄像头的「最大交集起点」= max(各摄像头首帧时间戳)，与 make_video 的 t_start 一致。
    任一摄像头缺失/无图 → 返回 None（由调用方退化处理）。
    """
    base = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples"
    starts = []
    for cam_name in used_cameras:
        cam_dir = base / cam_name
        if not cam_dir.exists():
            return None
        cam_ts = []
        for img_path in cam_dir.rglob("*.jpg"):
            match = re.search(r'_(\d{16})\.jpg', img_path.name)
            if match:
                cam_ts.append(float(match.group(1)))
        if not cam_ts:
            return None
        starts.append(min(cam_ts))
    return max(starts)


# ==========================================
# 核心 Worker 函数：处理单个场景
# ==========================================
def process_single_scene(autoscene_id: str, config: ExtendedConfig) -> Tuple[Dict, List[Dict], str]:
    """
    独立处理单个场景。
    返回: (截短配置字典, 长间隔异常列表, 日志/丢弃原因信息)
    """
    log_msg = ""
    
    # 1. 加载本场景的 ego_pose
    autoscene_dir = Path(config.EGO_POSE_DIR) / autoscene_id
    ego_pose_files = list(autoscene_dir.rglob("ego_pose.json"))
    
    if not ego_pose_files:
        # 丢弃原因 1：找不到文件
        return None, [], f"📉 [过滤] {autoscene_id}: 缺失 ego_pose.json"
        
    poses = load_ego_pose_json(str(ego_pose_files[0]))
    if not poses:
        # 丢弃原因 2：文件为空或损坏
        return None, [], f"📉 [过滤] {autoscene_id}: ego_pose 读取为空"

    # 2. 检测急刹
    events = detect_hard_brake_events(poses, config.HARD_BRAKE_THRESHOLD)
    if not events:
        # 丢弃原因 3：没有达到急刹阈值
        return None, [], f"📉 [过滤] {autoscene_id}: 未检测到急刹(未达设定的减速阈值)"

    # 3. 找视频绝对 0 秒（多摄像头：取最大交集起点，与 make_video 的 t_start 一致）
    video_start_ts = get_real_video_start_ts(autoscene_id, config.CAMERA_CACHE_DIR, config.USED_CAMERAS)
    if not video_start_ts:
        video_start_ts = poses[0].timestamp
        log_msg = f"  ⚠️ [降级提示] {autoscene_id}: 图片缺失，退化使用 ego_pose 时间\n"

    # 4. 寻找视频内的首次有效刹车
    valid_brake_idx = -1
    valid_brake_ts = 0.0
    valid_brake_time_s = 0.0

    for i, event in enumerate(events):
        brake_ts = poses[event[0]].timestamp
        brake_time_s = (brake_ts - video_start_ts) / 1e6
        if brake_time_s >= 0:
            valid_brake_idx = i
            valid_brake_ts = brake_ts
            valid_brake_time_s = brake_time_s
            break

    if valid_brake_idx == -1:
        # 丢弃原因 4：刹车时间早于视频开始时间
        return None, [], log_msg + f"📉 [过滤] {autoscene_id}: 所有刹车均在图片/视频时间之前(发生在画外)"

    # 5. 生成截短字典
    crop_start_s = max(0.0, valid_brake_time_s - 2.0)
    crop_end_s = valid_brake_time_s + 1.0

    crop_dict = {
        'autoscene_id': autoscene_id,
        'video_start_ts': video_start_ts, 
        'first_valid_brake_ts': valid_brake_ts, 
        'brake_time_s': round(valid_brake_time_s, 2),
        'crop_start_s': round(crop_start_s, 2),
        'crop_end_s': round(crop_end_s, 2),
        'duration_s': round(crop_end_s - crop_start_s, 2)
    }

    # 6. 生成长间隔异常列表
    long_interval_list = []
    if len(events) > 1:
        for i in range(1, len(events)):
            prev_ts = poses[events[i-1][0]].timestamp
            curr_ts = poses[events[i][0]].timestamp
            interval_s = (curr_ts - prev_ts) / 1e6

            if interval_s > 5.0:
                long_interval_list.append({
                    'autoscene_id': autoscene_id,
                    'brake_index': i + 1,
                    'interval_s': round(interval_s, 2),
                    'prev_brake_time_s': round((prev_ts - video_start_ts) / 1e6, 2),
                    'curr_brake_time_s': round((curr_ts - video_start_ts) / 1e6, 2)
                })

    # 返回成功结果
    return crop_dict, long_interval_list, log_msg + f"✅ [成功] {autoscene_id} 处理完毕"


# ==========================================
# 主函数：调度多进程并发
# ==========================================
def generate_crop_and_filter_configs_mp():
    config = ExtendedConfig()
    output_dir = config.OUTPUT_DIR
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 60)
    print(f"视频截短配置生成器 (⚡ 包含数据流失追踪 - 并发数: {config.MAX_WORKERS})")
    print("=" * 60)

    # 1. 提取目标 ID
    print("\n[1/2] 提取并解析目标 autoscene_id...")
    target_ids = extract_target_autoscene_ids(
        config.TEST_JSONL_PATH,  
        config.CLASS0_EXCEL_PATH, 
        config.POSITIVE_LABEL, 
        config.NEGATIVE_LABEL
    )
    if not target_ids:
        print("未找到任何目标 ID，退出。")
        return

    # 准备收集结果的容器
    all_crop_data = []
    all_long_intervals = []
    
    # 丢弃原因统计器
    filter_reasons = defaultdict(int)
    
    print(f"\n[2/2] 启动多进程并发处理 {len(target_ids)} 条数据...")
    
    # 2. 核心：启动进程池
    with ProcessPoolExecutor(max_workers=config.MAX_WORKERS) as executor:
        futures = {executor.submit(process_single_scene, uid, config): uid for uid in target_ids}
        
        for future in tqdm(as_completed(futures), total=len(target_ids), desc="处理进度", unit="场景"):
            try:
                crop_dict, long_interval_list, log_msg = future.result()
                
                # 分析日志，归类过滤原因
                if log_msg and "📉 [过滤]" in log_msg:
                    reason = log_msg.split("📉 [过滤]")[1].split(":")[1].strip()
                    filter_reasons[reason] += 1
                
                # 可选：如果你想看具体的跳过日志，可以取消注释下面这行
                # if log_msg and "📉" in log_msg:
                #     tqdm.write(log_msg.strip())
                
                # 收集有效结果
                if crop_dict:
                    all_crop_data.append(crop_dict)
                if long_interval_list:
                    all_long_intervals.extend(long_interval_list)
                    
            except Exception as e:
                uid = futures[future]
                tqdm.write(f"  ❌ [致命错误] 处理 {uid} 时崩溃: {e}")
                filter_reasons["代码运行崩溃 (Exception)"] += 1

    # 3. 输出汇总结果
    print("\n" + "=" * 60)
    print("[处理完成！正在保存 CSV 文件...]")
    
    crop_df = pd.DataFrame(all_crop_data)
    if not crop_df.empty:
        crop_csv_path = os.path.join(output_dir, 'video_crop_config.csv')
        crop_df.to_csv(crop_csv_path, index=False)
        print(f"✅ 截短配置文件已保存至: {crop_csv_path} (共 {len(crop_df)} 条)")
    
    long_interval_df = pd.DataFrame(all_long_intervals)
    if not long_interval_df.empty:
        long_interval_csv_path = os.path.join(output_dir, 'long_interval_brakes_to_review.csv')
        long_interval_df.to_csv(long_interval_csv_path, index=False)
        print(f"⚠️ 长时间间隔(>5s)多刹车场景保存至: {long_interval_csv_path} (共 {len(long_interval_df)} 条)")

    # === 新增：打印第二阶段的数据流失追踪报告 ===
    print("\n--- 🔍 第二阶段：数据流失追踪报告 ---")
    print(f"输入进程池的总任务数: {len(target_ids)}")
    print(f"成功产出配置的总任务数: {len(all_crop_data)}")
    print(f"丢失任务数: {len(target_ids) - len(all_crop_data)}")
    if filter_reasons:
        print("\n丢失原因具体占比:")
        for reason, count in sorted(filter_reasons.items(), key=lambda x: x[1], reverse=True):
            print(f"  ❌ {reason} : 导致 {count} 条数据被拦截")
    print("------------------------------------\n")

if __name__ == "__main__":
    generate_crop_and_filter_configs_mp()