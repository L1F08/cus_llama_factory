"""
AEB纵向加速度数据分析脚本
支持从训练集JSON筛选正样例进行分析
自动递归搜索ego_pose.json，不依赖固定子目录
"""
import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Set
from dataclasses import dataclass
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# ==================== 配置参数 ======================
@dataclass
class Config:
    # 数据路径
    TRAIN_JSON_PATH = "/home/ma-user/work/lyf/data/0604_crash_1cam_2cls_train_all_3s_-3_0/train_0604_crash_1cam_2cls_train_all_3s_-3_0_front_with_ego_info_54906.json"
    EGO_POSE_DIR = "/home/ma-user/work/lyf/debug_cache"
    OUTPUT_DIR = "/home/ma-user/work/lyf/data/0604_crash_1cam_2cls_train_all_3s_-3_0/aeb_analysis_output_3s"
    
    # 筛选条件
    POSITIVE_LABEL = "1"
    
    # AEB分析参数
    HARD_BRAKE_THRESHOLD = -6.0
    SEVERE_BRAKE_THRESHOLD = -8.0
    STOP_SPEED_THRESHOLD = 0.5


@dataclass
class EgoPose:
    timestamp: float
    velocity: Optional[float]
    acc_long: Optional[float]
    acc_lat: Optional[float]
    steer: Optional[float]


# ==================== 从训练集JSON提取ID ======================
def extract_positive_autoscene_ids(train_json_path: str, positive_label: str = "1") -> Set[str]:
    """从训练集JSON中提取正样例的autoscene_id"""
    positive_ids = set()
    label_counts = {}
    
    with open(train_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    for item in data:
        label = None
        messages = item.get("messages", [])
        for msg in messages:
            if msg.get("role") == "assistant":
                label = msg.get("content", "")
                break
        
        label_key = str(label).strip()
        label_counts[label_key] = label_counts.get(label_key, 0) + 1
        
        if label_key == positive_label:
            videos = item.get("videos", [])
            for video_path in videos:
                autoscene_id = Path(video_path).stem
                if autoscene_id:
                    positive_ids.add(autoscene_id)
    
    print(f"  Label分布统计: {label_counts}")
    
    return positive_ids


def load_ego_pose_json(file_path: str) -> List[EgoPose]:
    """加载单个ego_pose.json文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    poses = []
    for item in sorted(data, key=lambda x: x['timestamp']):
        velocity = item.get('chassis_velocity')
        acc = item.get('acceleration', [])
        acc_long = acc[0] if acc and len(acc) >= 1 else None
        acc_lat = acc[1] if acc and len(acc) >= 2 else None
        steer = item.get('chassis_steer_angle')
        
        poses.append(EgoPose(
            timestamp=item['timestamp'],
            velocity=velocity,
            acc_long=acc_long,
            acc_lat=acc_lat,
            steer=steer
        ))
    
    return poses


def load_all_ego_poses(ego_pose_dir: str, autoscene_ids: Set[str] = None) -> Tuple[Dict[str, List[EgoPose]], int, int, List[str]]:
    """
    加载多个ego_pose.json文件
    自动递归搜索 ego_pose.json，不依赖固定子目录
    """
    all_poses = {}
    ego_path = Path(ego_pose_dir)
    missing_ids = []
    
    if autoscene_ids:
        ids_to_load = list(autoscene_ids)
    else:
        ids_to_load = [p.name for p in ego_path.iterdir() if p.is_dir()]
    
    loaded_count = 0
    missing_count = 0
    
    for autoscene_id in ids_to_load:
        autoscene_dir = ego_path / autoscene_id
        
        if not autoscene_dir.exists():
            missing_count += 1
            missing_ids.append(autoscene_id)
            continue
        
        # 递归搜索 ego_pose.json
        ego_pose_files = list(autoscene_dir.rglob("ego_pose.json"))
        
        if ego_pose_files:
            ego_pose_path = ego_pose_files[0]
            try:
                all_poses[autoscene_id] = load_ego_pose_json(str(ego_pose_path))
                loaded_count += 1
                continue
            except Exception as e:
                print(f"    解析失败 {ego_pose_path}: {e}")
        
        missing_count += 1
        missing_ids.append(autoscene_id)
    
    return all_poses, loaded_count, missing_count, missing_ids


# ==================== 事件检测 ======================
def detect_hard_brake_events(poses: List[EgoPose], threshold: float = -5.0) -> List[Tuple[int, int]]:
    """
    检测急刹事件

    Args:
        threshold: 刹车阈值（默认-5.0 m/s²，对应 HARD_BRAKE_THRESHOLD）

    Returns:
        List of (start_idx, peak_idx) tuples for each detected brake event
    """
    events = []
    in_brake = False
    start_idx = 0
    peak_idx = 0
    peak_value = 0.0
    recovery_counter = 0
    RECOVERY_THRESHOLD = -2.0
    RECOVERY_FRAMES = 3

    for i, pose in enumerate(poses):
        if pose.acc_long is None:
            continue

        if pose.acc_long < threshold and not in_brake:
            in_brake = True
            start_idx = i
            peak_idx = i
            peak_value = pose.acc_long
            recovery_counter = 0
        elif pose.acc_long < threshold and in_brake:
            if pose.acc_long < peak_value:
                peak_idx = i
                peak_value = pose.acc_long
            recovery_counter = 0
        elif pose.acc_long >= threshold:
            if in_brake:
                if pose.acc_long >= RECOVERY_THRESHOLD:
                    recovery_counter += 1
                    if recovery_counter >= RECOVERY_FRAMES:
                        in_brake = False
                        if peak_value < threshold:
                            events.append((start_idx, peak_idx))
                        recovery_counter = 0
                else:
                    recovery_counter = 0

    if in_brake and peak_value < threshold:
        events.append((start_idx, peak_idx))

    return events


def detect_severe_brake_events(poses: List[EgoPose], threshold: float = -8.0) -> List[Tuple[int, int]]:
    """
    检测严重急刹事件（更严格的阈值）
    
    Args:
        threshold: 严重刹车阈值（默认-8.0 m/s²，对应 SEVERE_BRAKE_THRESHOLD）
    """
    return detect_hard_brake_events(poses, threshold)


def classify_brake_severity(peak_acc: float) -> str:
    """
    根据峰值加速度分类刹车严重程度
    
    Args:
        peak_acc: 峰值加速度（负值表示减速）
    
    Returns:
        '普通': -5 ~ -8 m/s²
        '严重': < -8 m/s²
        '轻微': >= -5 m/s² (不应出现在检测结果中)
    """
    if peak_acc < -8.0:
        return '严重'
    elif peak_acc < -5.0:
        return '普通'
    else:
        return '轻微'


def find_stop_event(poses: List[EgoPose], start_idx: int, threshold: float = 0.5) -> Optional[int]:
    """从给定索引开始，找到刹停时间点"""
    for i in range(start_idx, len(poses)):
        if poses[i].velocity is not None and poses[i].velocity < threshold:
            return i
    return None


# ==================== 统计分析 ======================
def calculate_statistics(values: List[float]) -> Dict:
    """计算基本统计量"""
    values = np.array([v for v in values if v is not None])
    if len(values) == 0:
        return {}
    
    return {
        'count': len(values),
        'mean': np.mean(values),
        'std': np.std(values),
        'min': np.min(values),
        'max': np.max(values),
        'Q25': np.percentile(values, 25),
        'Q50': np.percentile(values, 50),
        'Q75': np.percentile(values, 75),
        'Q90': np.percentile(values, 90),
        'Q95': np.percentile(values, 95),
        'Q99': np.percentile(values, 99),
    }


def analyze_brake_events(all_poses: Dict[str, List[EgoPose]], config: Config) -> Tuple[pd.DataFrame, Dict]:
    """
    分析所有刹车事件
    
    Returns:
        (events_df, brake区间内的空缺统计)
    """
    events = []
    
    # 急刹区间内的空缺统计
    brake_interval_stats = {
        'velocity': {'total': 0, 'valid': 0, 'missing': 0},
        'acc_long': {'total': 0, 'valid': 0, 'missing': 0},
    }
    
    for autoscene_id, poses in all_poses.items():
        brake_events = detect_hard_brake_events(poses, config.HARD_BRAKE_THRESHOLD)
        
        scene_start_timestamp = poses[0].timestamp
        
        for start_idx, peak_idx in brake_events:
            start_pose = poses[start_idx]
            peak_pose = poses[peak_idx]
            
            stop_idx = find_stop_event(poses, start_idx, config.STOP_SPEED_THRESHOLD)
            stop_time = poses[stop_idx].timestamp if stop_idx else None

            initial_velocity = start_pose.velocity if start_pose.velocity else 0
            velocity_values = [p.velocity for p in poses[start_idx:peak_idx+1] if p.velocity is not None]
            min_velocity = min(velocity_values) if velocity_values else None

            duration = (peak_pose.timestamp - start_pose.timestamp) / 1e6

            relative_time_s = (start_pose.timestamp - scene_start_timestamp) / 1e6
            peak_relative_time_s = (peak_pose.timestamp - scene_start_timestamp) / 1e6
            stop_relative_time_s = (stop_time - scene_start_timestamp) / 1e6 if stop_time else None

            severity = classify_brake_severity(peak_pose.acc_long)

            events.append({
                'autoscene_id': autoscene_id,
                'scene_start_timestamp': scene_start_timestamp,
                'start_time': start_pose.timestamp,
                'start_relative_time_s': relative_time_s,
                'peak_time': peak_pose.timestamp,
                'peak_relative_time_s': peak_relative_time_s,
                'peak_acc': peak_pose.acc_long,
                'severity': severity,
                'initial_velocity': initial_velocity,
                'min_velocity': min_velocity,
                'stop_time': stop_time,
                'stop_relative_time_s': stop_relative_time_s,
                'duration': duration,
                'has_stop': stop_idx is not None
            })
            
            # 统计急刹区间内的空缺
            for pose in poses[start_idx:peak_idx+1]:
                brake_interval_stats['velocity']['total'] += 1
                if pose.velocity is not None:
                    brake_interval_stats['velocity']['valid'] += 1
                else:
                    brake_interval_stats['velocity']['missing'] += 1
                
                brake_interval_stats['acc_long']['total'] += 1
                if pose.acc_long is not None:
                    brake_interval_stats['acc_long']['valid'] += 1
                else:
                    brake_interval_stats['acc_long']['missing'] += 1
    
    # 计算空缺率
    for field, stats in brake_interval_stats.items():
        total = stats['total']
        if total > 0:
            stats['missing_rate'] = stats['missing'] / total * 100
            stats['valid_rate'] = stats['valid'] / total * 100
        else:
            stats['missing_rate'] = 0
            stats['valid_rate'] = 0
    
    return pd.DataFrame(events), brake_interval_stats


def analyze_brake_count_per_scene(brake_events_df: pd.DataFrame) -> Dict:
    """
    分析每个场景的刹车次数分布
    
    Returns:
        包含各场景刹车次数统计的字典
    """
    brake_counts = brake_events_df.groupby('autoscene_id').size()
    
    count_distribution = brake_counts.value_counts().sort_index()
    
    single_brake_scenes = (brake_counts == 1).sum()
    multiple_brake_scenes = (brake_counts > 1).sum()
    
    return {
        'total_scenes': len(brake_counts),
        'single_brake_scenes': single_brake_scenes,
        'multiple_brake_scenes': multiple_brake_scenes,
        'multi_brake_ratio': multiple_brake_scenes / len(brake_counts) * 100 if len(brake_counts) > 0 else 0,
        'total_brake_events': len(brake_events_df),
        'mean_brakes_per_scene': brake_counts.mean(),
        'max_brakes_single_scene': brake_counts.max(),
        'count_distribution': count_distribution.to_dict()
    }


def analyze_brake_interval_statistics(brake_events_df: pd.DataFrame) -> Dict:
    """
    分析多次刹车之间的时间间隔
    
    Returns:
        包含时间间隔统计的字典
    """
    all_intervals = []
    scene_interval_details = []
    
    for autoscene_id, scene_events in brake_events_df.groupby('autoscene_id'):
        if len(scene_events) < 2:
            continue
        
        scene_events_sorted = scene_events.sort_values('start_time')
        timestamps = scene_events_sorted['start_time'].tolist()
        
        for i in range(1, len(timestamps)):
            interval_ms = timestamps[i] - timestamps[i-1]
            interval_s = (timestamps[i] - timestamps[i-1]) / 1e6
            all_intervals.append(interval_s)
            
            scene_interval_details.append({
                'autoscene_id': autoscene_id,
                'brake_index': i + 1,
                'interval_s': interval_s
            })
    
    if not all_intervals:
        return {
            'has_multi_brake': False,
            'count': 0,
            'mean': 0,
            'std': 0,
            'min': 0,
            'max': 0,
            'p25': 0,
            'p50': 0,
            'p75': 0,
            'p90': 0
        }
    
    import numpy as np
    intervals_array = np.array(all_intervals)
    
    return {
        'has_multi_brake': True,
        'count': len(all_intervals),
        'mean': float(np.mean(intervals_array)),
        'std': float(np.std(intervals_array)),
        'min': float(np.min(intervals_array)),
        'max': float(np.max(intervals_array)),
        'p25': float(np.percentile(intervals_array, 25)),
        'p50': float(np.percentile(intervals_array, 50)),
        'p75': float(np.percentile(intervals_array, 75)),
        'p90': float(np.percentile(intervals_array, 90))
    }


def extract_long_interval_brakes(brake_events_df: pd.DataFrame, threshold_s: float = 5.0) -> pd.DataFrame:
    """
    提取多次刹车间隔时间过长的场景数据
    
    Args:
        brake_events_df: 刹车事件DataFrame
        threshold_s: 间隔时间阈值（秒）
    
    Returns:
        包含长时间间隔刹车场景的DataFrame
    """
    long_interval_scenes = []
    
    for autoscene_id, scene_events in brake_events_df.groupby('autoscene_id'):
        if len(scene_events) < 2:
            continue
        
        scene_events_sorted = scene_events.sort_values('start_time')
        timestamps = scene_events_sorted['start_time'].tolist()
        scene_start_timestamp = scene_events_sorted.iloc[0]['scene_start_timestamp']
        
        for i in range(1, len(timestamps)):
            interval_s = (timestamps[i] - timestamps[i-1]) / 1e6
            if interval_s > threshold_s:
                long_interval_scenes.append({
                    'autoscene_id': autoscene_id,
                    'brake_index': i + 1,
                    'interval_s': interval_s,
                    'previous_brake_time': timestamps[i-1],
                    'previous_brake_relative_time': (timestamps[i-1] - scene_start_timestamp) / 1e6,
                    'current_brake_time': timestamps[i],
                    'current_brake_relative_time': (timestamps[i] - scene_start_timestamp) / 1e6,
                    'previous_peak_acc': scene_events_sorted.iloc[i-1]['peak_acc'],
                    'current_peak_acc': scene_events_sorted.iloc[i]['peak_acc']
                })
    
    return pd.DataFrame(long_interval_scenes)


def plot_brake_count_distribution(brake_stats: Dict, output_dir: str):
    """绘制刹车次数分布图"""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    ax1 = axes[0]
    counts = list(brake_stats['count_distribution'].keys())
    values = list(brake_stats['count_distribution'].values())
    ax1.bar(counts, values, color='steelblue', edgecolor='black')
    ax1.set_xlabel('每场景刹车次数')
    ax1.set_ylabel('场景数量')
    ax1.set_title(f'每场景刹车次数分布\n(总计: {brake_stats["total_scenes"]} 个场景)')
    for i, v in enumerate(values):
        ax1.text(counts[i], v + 0.5, str(v), ha='center')
    ax1.grid(True, alpha=0.3, axis='y')
    
    ax2 = axes[1]
    labels = ['单次刹车', '多次刹车']
    sizes = [brake_stats['single_brake_scenes'], brake_stats['multiple_brake_scenes']]
    colors = ['lightgreen', 'coral']
    explode = (0, 0.05)
    ax2.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%',
            shadow=True, startangle=90)
    ax2.set_title('单次刹车 vs 多次刹车场景')
    
    ax3 = axes[2]
    ax3.axis('off')
    summary_data = [
        ['指标', '数值'],
        ['总场景数', f"{brake_stats['total_scenes']}"],
        ['总刹车事件数', f"{brake_stats['total_brake_events']}"],
        ['单次刹车场景', f"{brake_stats['single_brake_scenes']} ({100-brake_stats['multi_brake_ratio']:.1f}%)"],
        ['多次刹车场景', f"{brake_stats['multiple_brake_scenes']} ({brake_stats['multi_brake_ratio']:.1f}%)"],
        ['平均每场景刹车次数', f"{brake_stats['mean_brakes_per_scene']:.2f}"],
        ['单场景最大刹车次数', f"{brake_stats['max_brakes_single_scene']}"],
    ]
    table = ax3.table(cellText=summary_data, loc='center', cellLoc='left')
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.2, 1.8)
    ax3.set_title('刹车次数统计摘要', fontsize=12, pad=20)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'brake_count.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"已保存: {output_dir}/brake_count.png")


def analyze_brake_timing(all_poses: Dict[str, List[EgoPose]], brake_events_df: pd.DataFrame, config: Config) -> pd.DataFrame:
    """
    分析刹车过程的时间分布
    
    关键指标:
    - pre_brake_duration: 刹车开始前（从数据起点到刹车开始）持续时间
    - brake_duration: 急刹过程持续时间（刹车开始到速度最低点）
    - deceleration_duration: 减速过程持续时间（刹车开始到刹停）
    - recovery_duration: 速度恢复/稳定过程持续时间
    - total_relevant_duration: 总相关时长（用于视频截短建议）
    """
    timing_data = []
    
    for autoscene_id, poses in all_poses.items():
        scene_events = brake_events_df[brake_events_df['autoscene_id'] == autoscene_id]
        if len(scene_events) == 0:
            continue
        
        first_event = scene_events.iloc[0]
        start_timestamp = poses[0].timestamp
        brake_start_timestamp = first_event['start_time']
        peak_timestamp = first_event['peak_time']
        
        pre_brake_duration = (brake_start_timestamp - start_timestamp) / 1e6
        brake_duration = (peak_timestamp - brake_start_timestamp) / 1e6
        
        deceleration_duration = None
        if first_event['has_stop'] and first_event['stop_time']:
            deceleration_duration = (first_event['stop_time'] - brake_start_timestamp) / 1e6
        
        timing_data.append({
            'autoscene_id': autoscene_id,
            'pre_brake_duration': pre_brake_duration,
            'brake_duration': brake_duration,
            'deceleration_duration': deceleration_duration,
            'initial_velocity': first_event['initial_velocity'],
            'peak_acc': first_event['peak_acc'],
            'has_stop': first_event['has_stop']
        })
    
    return pd.DataFrame(timing_data)


def plot_brake_timing_distribution(timing_df: pd.DataFrame, output_dir: str):
    """绘制刹车时间分布图"""
    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    
    def format_stats(series: pd.Series) -> str:
        return f"均值: {series.mean():.1f}s\n中位数: {series.median():.1f}s\n标准差: {series.std():.1f}s\n25分位: {series.quantile(0.25):.1f}s\n75分位: {series.quantile(0.75):.1f}s\n90分位: {series.quantile(0.90):.1f}s"
    
    def format_stats_dec(series: pd.Series) -> str:
        valid = series.dropna()
        if len(valid) == 0:
            return "无数据"
        return f"均值: {valid.mean():.1f}s\n中位数: {valid.median():.1f}s\n标准差: {valid.std():.1f}s\n25分位: {valid.quantile(0.25):.1f}s\n75分位: {valid.quantile(0.75):.1f}s\n90分位: {valid.quantile(0.90):.1f}s"
    
    # 1. 刹车前持续时间分布
    ax1 = axes[0, 0]
    valid_pre = timing_df['pre_brake_duration'].dropna()
    if len(valid_pre) > 0:
        ax1.hist(valid_pre, bins=30, edgecolor='black', alpha=0.7, color='steelblue')
        ax1.axvline(x=valid_pre.median(), color='red', linestyle='--', linewidth=2, label=f'中位数: {valid_pre.median():.1f}s')
        ax1.axvline(x=valid_pre.quantile(0.25), color='orange', linestyle=':', label=f'25分位: {valid_pre.quantile(0.25):.1f}s')
        ax1.axvline(x=valid_pre.quantile(0.75), color='orange', linestyle=':', label=f'75分位: {valid_pre.quantile(0.75):.1f}s')
        ax1.set_xlabel('持续时间 (秒)')
        ax1.set_ylabel('频次')
        ax1.set_title('刹车前持续时间（数据起点到刹车开始）')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
    
    # 2. 急刹过程持续时间分布
    ax2 = axes[0, 1]
    brake_durations = timing_df['brake_duration'].dropna()
    if len(brake_durations) > 0:
        ax2.hist(brake_durations, bins=30, edgecolor='black', alpha=0.7, color='coral')
        ax2.axvline(x=brake_durations.median(), color='red', linestyle='--', linewidth=2, label=f'中位数: {brake_durations.median():.1f}s')
        ax2.axvline(x=brake_durations.quantile(0.25), color='orange', linestyle=':', label=f'25分位: {brake_durations.quantile(0.25):.1f}s')
        ax2.axvline(x=brake_durations.quantile(0.75), color='orange', linestyle=':', label=f'75分位: {brake_durations.quantile(0.75):.1f}s')
        ax2.set_xlabel('持续时间 (秒)')
        ax2.set_ylabel('频次')
        ax2.set_title('急刹过程持续时间（刹车开始到峰值减速）')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
    
    # 3. 减速/刹停持续时间分布
    ax3 = axes[0, 2]
    dec_durations = timing_df['deceleration_duration'].dropna()
    if len(dec_durations) > 0:
        ax3.hist(dec_durations, bins=30, edgecolor='black', alpha=0.7, color='purple')
        ax3.axvline(x=dec_durations.median(), color='red', linestyle='--', linewidth=2, label=f'中位数: {dec_durations.median():.1f}s')
        ax3.axvline(x=dec_durations.quantile(0.25), color='orange', linestyle=':', label=f'25分位: {dec_durations.quantile(0.25):.1f}s')
        ax3.axvline(x=dec_durations.quantile(0.75), color='orange', linestyle=':', label=f'75分位: {dec_durations.quantile(0.75):.1f}s')
        ax3.set_xlabel('持续时间 (秒)')
        ax3.set_ylabel('频次')
        ax3.set_title('减速/刹停持续时间（刹车开始到停止）')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
    
    # 4. 刹停 vs 未刹停对比
    ax4 = axes[1, 0]
    stopped = timing_df[timing_df['has_stop'] == True]['brake_duration']
    not_stopped = timing_df[timing_df['has_stop'] == False]['brake_duration']
    data_to_plot = [stopped, not_stopped]
    bp = ax4.boxplot(data_to_plot, labels=['已刹停', '未刹停'], patch_artist=True)
    bp['boxes'][0].set_facecolor('lightgreen')
    bp['boxes'][1].set_facecolor('lightyellow')
    ax4.set_ylabel('急刹持续时间 (秒)')
    ax4.set_title('刹车持续时间对比：已刹停 vs 未刹停')
    ax4.grid(True, alpha=0.3)
    
    # 5. 刹车持续时间 vs 初始速度散点图
    ax5 = axes[1, 1]
    scatter = ax5.scatter(timing_df['initial_velocity'], timing_df['brake_duration'],
                          c=np.abs(timing_df['peak_acc']), cmap='Reds', alpha=0.6, s=30)
    ax5.set_xlabel('初始速度 (m/s)')
    ax5.set_ylabel('刹车持续时间 (秒)')
    ax5.set_title('刹车持续时间与初始速度关系')
    plt.colorbar(scatter, ax=ax5, label='峰值减速度 (m/s²)')
    ax5.grid(True, alpha=0.3)
    
    # 6. 视频截短建议统计（详细版）
    ax6 = axes[1, 2]
    ax6.axis('off')
    
    pre_median = timing_df['pre_brake_duration'].median()
    brake_median = timing_df['brake_duration'].median()
    dec_median = timing_df['deceleration_duration'].median()
    pre_p25 = timing_df['pre_brake_duration'].quantile(0.25)
    pre_p75 = timing_df['pre_brake_duration'].quantile(0.75)
    brake_p25 = timing_df['brake_duration'].quantile(0.25)
    brake_p75 = timing_df['brake_duration'].quantile(0.75)
    
    recommended_before_min = max(1, pre_p25 - 2)
    recommended_before_median = max(1, pre_median - 2)
    recommended_before_max = max(1, pre_p75 - 2)
    
    recommended_after_stopped_min = brake_p25 + dec_median * 0.5 + 1
    recommended_after_stopped_median = brake_median + dec_median + 1
    recommended_after_stopped_max = brake_p75 + dec_median * 1.5 + 1
    
    recommended_after_not_stopped_median = brake_median + 2
    
    table_data = [
        ['时间指标', '25分位', '中位数', '75分位'],
        ['刹车前', f'{pre_p25:.1f}s', f'{pre_median:.1f}s', f'{pre_p75:.1f}s'],
        ['急刹', f'{brake_p25:.1f}s', f'{brake_median:.1f}s', f'{brake_p75:.1f}s'],
        ['减速（刹停）', f'{dec_median*0.5:.1f}s', f'{dec_median:.1f}s', f'{dec_median*1.5:.1f}s'],
        ['', '', '', ''],
        ['截短建议', '', '', ''],
        ['刹车前', f'~{recommended_before_min:.0f}s', f'~{recommended_before_median:.0f}s', f'~{recommended_before_max:.0f}s'],
        ['刹车后（刹停）', f'~{recommended_after_stopped_min:.0f}s', f'~{recommended_after_stopped_median:.0f}s', f'~{recommended_after_stopped_max:.0f}s'],
        ['刹车后（未刹停）', f'~{brake_p25+2:.0f}s', f'~{recommended_after_not_stopped_median:.0f}s', f'~{brake_p75+2:.0f}s'],
    ]
    
    table = ax6.table(cellText=table_data, loc='center', cellLoc='left')
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1.2, 1.8)
    ax6.set_title('视频截短建议（详细版）', fontsize=12, pad=20)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'brake_timing.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"已保存: {output_dir}/brake_timing.png")
    
    return {
        'recommended_before': recommended_before_median,
        'recommended_after_stopped': recommended_after_stopped_median,
        'recommended_after_not_stopped': recommended_after_not_stopped_median,
        'pre_median': pre_median, 'brake_median': brake_median, 'dec_median': dec_median,
        'pre_p25': pre_p25, 'pre_p75': pre_p75,
        'brake_p25': brake_p25, 'brake_p75': brake_p75
    }


# ==================== 可视化 ======================
def plot_acc_long_distribution(df: pd.DataFrame, output_dir: str):
    """绘制加速度分布图"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    ax1 = axes[0, 0]
    ax1.hist(df['peak_acc'], bins=50, edgecolor='black', alpha=0.7, color='steelblue')
    ax1.axvline(x=-3.0, color='red', linestyle='--', label='急刹阈值 (-3 m/s²)')
    ax1.axvline(x=df['peak_acc'].median(), color='orange', linestyle='--', label=f'中位数 ({df["peak_acc"].median():.2f})')
    ax1.set_xlabel('峰值纵向加速度 (m/s²)')
    ax1.set_ylabel('频次')
    ax1.set_title('急刹期间峰值减速度分布')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    ax2 = axes[0, 1]
    bp = ax2.boxplot(df['peak_acc'].dropna(), vert=True, patch_artist=True)
    bp['boxes'][0].set_facecolor('lightblue')
    ax2.axhline(y=-3.0, color='red', linestyle='--', label='阈值')
    ax2.set_ylabel('峰值加速度 (m/s²)')
    ax2.set_title('峰值减速度箱线图')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    ax3 = axes[1, 0]
    sorted_acc = np.sort(df['peak_acc'])
    cdf = np.arange(1, len(sorted_acc) + 1) / len(sorted_acc)
    ax3.plot(sorted_acc, cdf, 'b-', linewidth=2)
    ax3.axvline(x=-3.0, color='red', linestyle='--', label='急刹阈值')
    ax3.axhline(y=0.5, color='gray', linestyle=':', alpha=0.5)
    ax3.set_xlabel('峰值加速度 (m/s²)')
    ax3.set_ylabel('累积概率')
    ax3.set_title('累积分布函数 (CDF)')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    
    ax4 = axes[1, 1]
    stopped = df[df['has_stop'] == True]['peak_acc']
    not_stopped = df[df['has_stop'] == False]['peak_acc']
    data_to_plot = [stopped, not_stopped]
    bp2 = ax4.boxplot(data_to_plot, labels=['已刹停', '未刹停'], patch_artist=True)
    bp2['boxes'][0].set_facecolor('lightgreen')
    bp2['boxes'][1].set_facecolor('lightyellow')
    ax4.set_ylabel('峰值加速度 (m/s²)')
    ax4.set_title('峰值减速度对比：已刹停 vs 未刹停')
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'acc_long_distribution.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"已保存: {output_dir}/acc_long_distribution.png")


def plot_velocity_profile(poses: List[EgoPose], autoscene_id: str, brake_events: List, output_dir: str):
    """绘制单个场景的速度和加速度时序图"""
    timestamps = [(p.timestamp - poses[0].timestamp) / 1e6 for p in poses]
    velocities = [p.velocity if p.velocity else np.nan for p in poses]
    acc_longs = [p.acc_long if p.acc_long else np.nan for p in poses]
    
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
    
    ax1 = axes[0]
    ax1.plot(timestamps, velocities, 'b-', linewidth=1.5, label='速度')
    ax1.fill_between(timestamps, velocities, alpha=0.3)
    ax1.set_ylabel('速度 (m/s)', fontsize=12)
    ax1.set_title(f'速度曲线 - {autoscene_id}', fontsize=14)
    ax1.axhline(y=0.5, color='red', linestyle='--', alpha=0.7, label='停止阈值')
    ax1.legend(loc='upper right')
    ax1.grid(True, alpha=0.3)
    
    for start_idx, peak_idx in brake_events:
        start_t = timestamps[start_idx]
        peak_t = timestamps[peak_idx]
        ax1.axvspan(start_t, peak_t, alpha=0.2, color='red')
    
    ax2 = axes[1]
    ax2.plot(timestamps, acc_longs, 'r-', linewidth=1.5, label='加速度')
    ax2.axhline(y=-3.0, color='orange', linestyle='--', label='急刹阈值')
    ax2.axhline(y=0, color='gray', linestyle='-', alpha=0.5)
    ax2.fill_between(timestamps, acc_longs, 0, where=np.array(acc_longs) < 0, alpha=0.3, color='red')
    ax2.set_xlabel('时间 (秒)', fontsize=12)
    ax2.set_ylabel('加速度 (m/s²)', fontsize=12)
    ax2.set_title('纵向加速度曲线', fontsize=14)
    ax2.legend(loc='upper right')
    ax2.grid(True, alpha=0.3)
    
    for start_idx, peak_idx in brake_events:
        start_t = timestamps[start_idx]
        peak_t = timestamps[peak_idx]
        ax2.axvspan(start_t, peak_t, alpha=0.2, color='red')
    
    plt.tight_layout()
    safe_filename = autoscene_id.replace('/', '_').replace('\\', '_')
    plt.savefig(os.path.join(output_dir, f'velocity_profile_{safe_filename}.png'), dpi=150, bbox_inches='tight')
    plt.close()


def analyze_data_quality(all_poses: Dict[str, List[EgoPose]]) -> Dict[str, Dict]:
    """
    分析数据质量，统计各字段的空缺情况
    
    Returns:
        {
            'velocity': {'total': N, 'valid': N, 'missing': N, 'missing_rate': float},
            'acc_long': {...},
            'acc_lat': {...},
            'steer': {...}
        }
    """
    quality_stats = {
        'velocity': {'total': 0, 'valid': 0, 'missing': 0},
        'acc_long': {'total': 0, 'valid': 0, 'missing': 0},
        'acc_lat': {'total': 0, 'valid': 0, 'missing': 0},
        'steer': {'total': 0, 'valid': 0, 'missing': 0},
    }
    
    for autoscene_id, poses in all_poses.items():
        for pose in poses:
            quality_stats['velocity']['total'] += 1
            if pose.velocity is not None:
                quality_stats['velocity']['valid'] += 1
            else:
                quality_stats['velocity']['missing'] += 1
            
            quality_stats['acc_long']['total'] += 1
            if pose.acc_long is not None:
                quality_stats['acc_long']['valid'] += 1
            else:
                quality_stats['acc_long']['missing'] += 1
            
            quality_stats['acc_lat']['total'] += 1
            if pose.acc_lat is not None:
                quality_stats['acc_lat']['valid'] += 1
            else:
                quality_stats['acc_lat']['missing'] += 1
            
            quality_stats['steer']['total'] += 1
            if pose.steer is not None:
                quality_stats['steer']['valid'] += 1
            else:
                quality_stats['steer']['missing'] += 1
    
    # 计算空缺率
    for field, stats in quality_stats.items():
        total = stats['total']
        if total > 0:
            stats['missing_rate'] = stats['missing'] / total * 100
            stats['valid_rate'] = stats['valid'] / total * 100
        else:
            stats['missing_rate'] = 0
            stats['valid_rate'] = 0
    
    return quality_stats


def plot_data_quality(quality_stats: Dict, output_dir: str):
    """绘制数据质量（空缺率）统计图"""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    fields = list(quality_stats.keys())
    valid_rates = [quality_stats[f]['valid_rate'] for f in fields]
    missing_rates = [quality_stats[f]['missing_rate'] for f in fields]
    
    # 1. 堆叠柱状图
    ax1 = axes[0]
    x = np.arange(len(fields))
    width = 0.6
    
    bars1 = ax1.bar(x, valid_rates, width, label='有效', color='steelblue')
    bars2 = ax1.bar(x, missing_rates, width, bottom=valid_rates, label='缺失', color='coral')
    
    ax1.set_ylabel('百分比 (%)', fontsize=12)
    ax1.set_title('数据质量：各字段有效率 vs 缺失率', fontsize=14)
    ax1.set_xticks(x)
    ax1.set_xticklabels(['速度', '纵向加速度', '侧向加速度', '方向盘转角'])
    ax1.legend()
    ax1.set_ylim(0, 105)
    ax1.grid(True, alpha=0.3, axis='y')
    
    # 添加数值标签
    for i, (v_rate, m_rate) in enumerate(zip(valid_rates, missing_rates)):
        if m_rate > 1:  # 只在缺失率大于1%时显示
            ax1.text(i, v_rate + m_rate - 3, f'{m_rate:.1f}%', 
                    ha='center', va='top', fontsize=9, color='white', fontweight='bold')
    
    # 2. 空缺率对比柱状图
    ax2 = axes[1]
    colors = ['coral' if r > 0 else 'lightgreen' for r in missing_rates]
    bars = ax2.bar(fields, missing_rates, color=colors, edgecolor='black')
    
    ax2.set_ylabel('缺失率 (%)', fontsize=12)
    ax2.set_title('各字段缺失率', fontsize=14)
    ax2.set_xticklabels(['速度', '纵向加速度', '侧向加速度', '方向盘转角'])
    ax2.grid(True, alpha=0.3, axis='y')
    
    # 添加数值标签
    for bar, rate in zip(bars, missing_rates):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height + 0.5,
                f'{rate:.2f}%', ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'data_quality.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"已保存: {output_dir}/data_quality.png")


def plot_statistics_summary(stats: Dict, df: pd.DataFrame, output_dir: str):
    """绘制统计摘要图"""
    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    
    ax1 = axes[0, 0]
    ax1.hist(df['initial_velocity'], bins=30, edgecolor='black', alpha=0.7, color='steelblue')
    ax1.set_xlabel('初始速度 (m/s)')
    ax1.set_ylabel('频次')
    ax1.set_title('急刹时初始速度分布')
    ax1.grid(True, alpha=0.3)
    
    ax2 = axes[0, 1]
    ax2.hist(df['duration'], bins=30, edgecolor='black', alpha=0.7, color='coral')
    ax2.set_xlabel('持续时间 (秒)')
    ax2.set_ylabel('频次')
    ax2.set_title('急刹持续时间分布')
    ax2.grid(True, alpha=0.3)
    
    ax3 = axes[0, 2]
    stop_counts = df['has_stop'].value_counts()
    ax3.pie([stop_counts.get(True, 0), stop_counts.get(False, 0)], 
            labels=['已刹停', '未刹停'], 
            autopct='%1.1f%%', 
            colors=['lightgreen', 'lightyellow'],
            explode=(0.05, 0))
    ax3.set_title('刹停事件占比')
    
    ax4 = axes[1, 0]
    ax4.hist(df['min_velocity'], bins=30, edgecolor='black', alpha=0.7, color='purple')
    ax4.set_xlabel('最小速度 (m/s)')
    ax4.set_ylabel('频次')
    ax4.set_title('刹车期间最小速度分布')
    ax4.grid(True, alpha=0.3)
    
    ax5 = axes[1, 1]
    scatter = ax5.scatter(df['initial_velocity'], df['peak_acc'], 
                          c=df['duration'], cmap='coolwarm', alpha=0.6, s=30)
    ax5.set_xlabel('初始速度 (m/s)')
    ax5.set_ylabel('峰值加速度 (m/s²)')
    ax5.set_title('峰值加速度与初始速度关系')
    plt.colorbar(scatter, ax=ax5, label='持续时间 (秒)')
    ax5.axhline(y=-3.0, color='red', linestyle='--', alpha=0.5)
    ax5.grid(True, alpha=0.3)
    
    ax6 = axes[1, 2]
    ax6.axis('off')
    table_data = [
        ['指标', '数值'],
        ['总事件数', f"{len(df)}"],
        ['刹停事件数', f"{df['has_stop'].sum()} ({df['has_stop'].mean()*100:.1f}%)"],
        ['平均峰值加速度', f"{df['peak_acc'].mean():.2f} m/s²"],
        ['中位数峰值加速度', f"{df['peak_acc'].median():.2f} m/s²"],
        ['最小峰值加速度', f"{df['peak_acc'].min():.2f} m/s²"],
        ['平均初始速度', f"{df['initial_velocity'].mean():.2f} m/s"],
        ['平均持续时间', f"{df['duration'].mean():.2f} s"],
    ]
    table = ax6.table(cellText=table_data, loc='center', cellLoc='left')
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1.2, 1.8)
    ax6.set_title('统计摘要', fontsize=14, pad=20)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_summary.png'), dpi=150, bbox_inches='tight')
    plt.close()
    print(f"已保存: {output_dir}/statistics_summary.png")


def generate_report(stats: Dict, brake_events_df: pd.DataFrame, quality_stats: Dict, brake_interval_stats: Dict, timing_df: pd.DataFrame, config: Config, output_dir: str):
    """生成文本分析报告"""
    report = []
    report.append("=" * 60)
    report.append("AEB纵向加速度分析报告（正样例）")
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 60)
    report.append("")
    
    report.append("【1. 数据来源】")
    report.append(f"  训练集JSON: {config.TRAIN_JSON_PATH}")
    report.append(f"  正样例标签: {config.POSITIVE_LABEL}")
    report.append(f"  ego_pose目录: {config.EGO_POSE_DIR}")
    report.append("")
    
    report.append("【2. 数据概览】")
    report.append(f"  正样例总数: {len(brake_events_df)}")
    report.append(f"  刹停事件数: {brake_events_df['has_stop'].sum()} ({brake_events_df['has_stop'].mean()*100:.1f}%)")
    stop_time_missing = brake_events_df['stop_time'].isna().sum()
    report.append(f"  stop_time为空数: {stop_time_missing}")
    if stop_time_missing > 0:
        report.append("")
        report.append("  【说明】stop_time为空的原因:")
        report.append("    - 在从刹车开始的后续数据中，速度始终没有降到阈值以下 (默认阈值: 0.5 m/s)")
        report.append("    - 可能的原因包括:")
        report.append("      1. 数据采集在车辆完全停止前就结束了")
        report.append("      2. 刹车力度不足，车辆未能在数据记录期间完全停止")
        report.append("      3. 刹车过程中车辆速度波动，未稳定低于阈值")
    report.append("")
    
    report.append("【3. 峰值加速度统计】")
    if stats.get('peak_acc'):
        report.append(f"  均值: {stats['peak_acc']['mean']:.3f} m/s²")
        report.append(f"  标准差: {stats['peak_acc']['std']:.3f} m/s²")
        report.append(f"  最小值: {stats['peak_acc']['min']:.3f} m/s²")
        report.append(f"  最大值: {stats['peak_acc']['max']:.3f} m/s²")
        report.append(f"  中位数: {stats['peak_acc']['Q50']:.3f} m/s²")
        report.append(f"  90分位: {stats['peak_acc']['Q90']:.3f} m/s²")
        report.append(f"  95分位: {stats['peak_acc']['Q95']:.3f} m/s²")
    report.append("")
    
    report.append("【4. 初始速度统计】")
    if stats.get('initial_velocity'):
        report.append(f"  均值: {stats['initial_velocity']['mean']:.3f} m/s")
        report.append(f"  中位数: {stats['initial_velocity']['Q50']:.3f} m/s")
    report.append("")
    
    report.append("【5. 急刹持续时间统计】")
    if stats.get('duration'):
        report.append(f"  均值: {stats['duration']['mean']:.3f} s")
        report.append(f"  中位数: {stats['duration']['Q50']:.3f} s")
    report.append("")
    
    report.append("【6. 阈值分析】")
    normal_count = (brake_events_df['severity'] == '普通').sum()
    severe_count = (brake_events_df['severity'] == '严重').sum()
    report.append(f"  急刹事件总数: {len(brake_events_df)}")
    report.append(f"  普通急刹 (HARD_BRAKE, -5~-8 m/s²): {normal_count} ({normal_count/len(brake_events_df)*100:.1f}%)")
    report.append(f"  严重急刹 (SEVERE_BRAKE, <-8 m/s²): {severe_count} ({severe_count/len(brake_events_df)*100:.1f}%)")
    report.append("")
    
    report.append("【6.5 刹车次数分析（单次 vs 多次刹车）】")
    brake_stats = analyze_brake_count_per_scene(brake_events_df)
    
    report.append(f"  正样例场景总数: {brake_stats['total_scenes']}")
    report.append(f"  刹车事件总数: {brake_stats['total_brake_events']} (平均每场景 {brake_stats['mean_brakes_per_scene']:.2f} 次)")
    report.append(f"  单次刹车场景: {brake_stats['single_brake_scenes']} ({100-brake_stats['multi_brake_ratio']:.1f}%)")
    report.append(f"  多次刹车场景: {brake_stats['multiple_brake_scenes']} ({brake_stats['multi_brake_ratio']:.1f}%)")
    report.append("")
    
    interval_stats = analyze_brake_interval_statistics(brake_events_df)
    if interval_stats['has_multi_brake']:
        report.append("  多次刹车间隔时间统计:")
        report.append(f"    间隔次数: {interval_stats['count']}")
        report.append(f"    均值: {interval_stats['mean']:.2f}s | 标准差: {interval_stats['std']:.2f}s")
        report.append(f"    最小: {interval_stats['min']:.2f}s | 最大: {interval_stats['max']:.2f}s")
        report.append(f"    P25: {interval_stats['p25']:.2f}s | P50: {interval_stats['p50']:.2f}s | P75: {interval_stats['p75']:.2f}s | P90: {interval_stats['p90']:.2f}s")
        
        long_interval_df = extract_long_interval_brakes(brake_events_df, threshold_s=5.0)
        if len(long_interval_df) > 0:
            report.append("")
            report.append("  【长时间间隔刹车（>5秒）】")
            report.append(f"    共发现 {len(long_interval_df)} 次间隔时间超过 5.0s 的刹车")
            report.append(f"    占比: {len(long_interval_df)/interval_stats['count']*100:.1f}%")
            report.append(f"    间隔时间范围: {long_interval_df['interval_s'].min():.2f}s ~ {long_interval_df['interval_s'].max():.2f}s")
            report.append(f"    详细数据已保存至: {config.OUTPUT_DIR}/long_interval_brakes.csv")
    report.append("")

    relative_times = brake_events_df['start_relative_time_s'].dropna()
    if len(relative_times) > 0:
        report.append("  刹车发生时刻统计（相对视频起点的秒数）:")
        report.append(f"    均值: {relative_times.mean():.2f}s | 标准差: {relative_times.std():.2f}s")
        report.append(f"    最小: {relative_times.min():.2f}s | 最大: {relative_times.max():.2f}s")
        report.append(f"    P25: {relative_times.quantile(0.25):.2f}s | P50: {relative_times.quantile(0.50):.2f}s | P75: {relative_times.quantile(0.75):.2f}s | P90: {relative_times.quantile(0.90):.2f}s")
    report.append("")

    report.append("【7. 数据质量（空缺率统计）】")
    report.append("  全局数据:")
    report.append(f"    {'字段':<12} {'有效':<10} {'缺失':<10} {'空缺率':<10}")
    report.append(f"    {'-'*44}")
    for field, q in quality_stats.items():
        field_name = {'velocity': '速度', 'acc_long': '纵向加速度', 'acc_lat': '侧向加速度', 'steer': '方向盘转角'}.get(field, field)
        report.append(f"    {field_name:<12} {q['valid']:<10} {q['missing']:<10} {q['missing_rate']:.2f}%")
    report.append("")
    report.append("  急刹区间内数据:")
    report.append(f"    {'字段':<12} {'有效':<10} {'缺失':<10} {'空缺率':<10}")
    report.append(f"    {'-'*44}")
    for field, q in brake_interval_stats.items():
        field_name = {'velocity': '速度', 'acc_long': '纵向加速度'}.get(field, field)
        report.append(f"    {field_name:<12} {q['valid']:<10} {q['missing']:<10} {q['missing_rate']:.2f}%")
    report.append("")
    
    report.append("【8. 刹车时间分析（视频截短建议）】")
    if len(timing_df) > 0:
        pre = timing_df['pre_brake_duration']
        brake = timing_df['brake_duration']
        dec = timing_df['deceleration_duration'].dropna()
        
        report.append("")
        report.append("  [8.1 刹车前持续时间 - 从数据起点到刹车开始]")
        report.append(f"    均值: {pre.mean():.2f}s | 标准差: {pre.std():.2f}s")
        report.append(f"    最小: {pre.min():.2f}s | 最大: {pre.max():.2f}s")
        report.append(f"    P25: {pre.quantile(0.25):.2f}s | P50: {pre.quantile(0.50):.2f}s | P75: {pre.quantile(0.75):.2f}s")
        report.append(f"    P90: {pre.quantile(0.90):.2f}s | P95: {pre.quantile(0.95):.2f}s")
        report.append("")
        
        report.append("  [8.2 急刹过程持续时间 - 从刹车开始到速度最低点]")
        report.append(f"    均值: {brake.mean():.2f}s | 标准差: {brake.std():.2f}s")
        report.append(f"    最小: {brake.min():.2f}s | 最大: {brake.max():.2f}s")
        report.append(f"    P25: {brake.quantile(0.25):.2f}s | P50: {brake.quantile(0.50):.2f}s | P75: {brake.quantile(0.75):.2f}s")
        report.append(f"    P90: {brake.quantile(0.90):.2f}s | P95: {brake.quantile(0.95):.2f}s")
        report.append("")
        
        report.append("  [8.3 减速/刹停持续时间 - 从刹车开始到完全停止]")
        if len(dec) > 0:
            report.append(f"    均值: {dec.mean():.2f}s | 标准差: {dec.std():.2f}s")
            report.append(f"    最小: {dec.min():.2f}s | 最大: {dec.max():.2f}s")
            report.append(f"    P25: {dec.quantile(0.25):.2f}s | P50: {dec.quantile(0.50):.2f}s | P75: {dec.quantile(0.75):.2f}s")
            report.append(f"    P90: {dec.quantile(0.90):.2f}s")
        else:
            report.append("    无有效的刹停数据")
        report.append("")
        
        pre_median = pre.median()
        brake_median = brake.median()
        dec_median = dec.median() if len(dec) > 0 else None
        
        report.append("  [8.4 视频截短建议]")
        report.append("    保守建议（使用P25，覆盖75%案例）:")
        pre_p25 = pre.quantile(0.25)
        brake_p25 = brake.quantile(0.25)
        recommended_before_min = max(1, pre_p25 - 2)
        recommended_after_stopped_min = brake_p25 + (dec_median * 0.5 if dec_median else 2) + 1
        report.append(f"      刹车前: ~{recommended_before_min:.0f}s | 刹车后（刹停）: ~{recommended_after_stopped_min:.0f}s")
        report.append("")
        report.append("    均衡建议（使用中位数，覆盖50%案例）:")
        recommended_before = max(1, pre_median - 2)
        recommended_after_stopped = brake_median + (dec_median if dec_median else 0) + 1
        recommended_after_not_stopped = brake_median + 2
        report.append(f"      刹车前: ~{recommended_before:.0f}s")
        report.append(f"      刹车后（会刹停）: ~{recommended_after_stopped:.0f}s")
        report.append(f"      刹车后（不会刹停）: ~{recommended_after_not_stopped:.0f}s")
        report.append("")
        report.append("    充分建议（使用P75，覆盖25%案例）:")
        pre_p75 = pre.quantile(0.75)
        brake_p75 = brake.quantile(0.75)
        recommended_before_max = max(1, pre_p75 - 2)
        recommended_after_stopped_max = brake_p75 + (dec_median * 1.5 if dec_median else 3) + 1
        report.append(f"      刹车前: ~{recommended_before_max:.0f}s | 刹车后（刹停）: ~{recommended_after_stopped_max:.0f}s")
        report.append("")
        report.append("    汇总推荐（综合建议）:")
        report.append(f"      前: {recommended_before_min:.0f}~{recommended_before_max:.0f}s (推荐: ~{recommended_before:.0f}s)")
        report.append(f"      后（刹停）: {recommended_after_stopped_min:.0f}~{recommended_after_stopped_max:.0f}s (推荐: ~{recommended_after_stopped:.0f}s)")
        report.append(f"      总计（刹停）: 约{recommended_before + recommended_after_stopped:.0f}s")
        report.append(f"      总计（未刹停）: 约{recommended_before + recommended_after_not_stopped:.0f}s")
    else:
        report.append("  无有效时间分析数据")
    report.append("")
    
    report.append("=" * 60)
    
    report_text = "\n".join(report)
    print(report_text)
    
    with open(os.path.join(output_dir, 'analysis_report.txt'), 'w', encoding='utf-8') as f:
        f.write(report_text)
    print(f"\n报告已保存: {output_dir}/analysis_report.txt")
    
    return report_text


# ==================== 主函数 ======================
def main():
    config = Config()
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    
    print("=" * 60)
    print("AEB纵向加速度分析工具（正样例筛选版）")
    print("=" * 60)
    
    # 1. 从训练集JSON提取正样例ID
    print("\n[1/6] 从训练集JSON提取正样例autoscene_id...")
    positive_ids = extract_positive_autoscene_ids(config.TRAIN_JSON_PATH, config.POSITIVE_LABEL)
    print(f"  正样例（label={config.POSITIVE_LABEL}）数量: {len(positive_ids)}")
    
    if len(positive_ids) == 0:
        print("错误: 未找到正样例！请检查训练集JSON格式和标签值")
        return
    
    # 2. 加载正样例对应的ego_pose数据
    print("\n[2/6] 加载正样例的ego_pose数据...")
    all_poses, loaded_count, missing_count, missing_ids = load_all_ego_poses(config.EGO_POSE_DIR, positive_ids)
    print(f"  成功加载: {loaded_count} 个")
    print(f"  缺失: {missing_count} 个（无ego_pose数据）")
    
    if missing_count > 0 and missing_count <= 10:
        print(f"  缺失的ID示例: {missing_ids[:5]}")
    
    if len(all_poses) == 0:
        print("错误: 未找到任何ego_pose数据！")
        print(f"  请确认数据路径: {config.EGO_POSE_DIR}")
        return
    
    # 3. 合并所有加速度数据用于统计
    print("\n[3/6] 提取加速度数据...")
    all_acc_long = []
    all_velocities = []
    for poses in all_poses.values():
        for pose in poses:
            if pose.acc_long is not None:
                all_acc_long.append(pose.acc_long)
            if pose.velocity is not None:
                all_velocities.append(pose.velocity)
    
    print(f"  加速度数据点: {len(all_acc_long)}")
    print(f"  速度数据点: {len(all_velocities)}")
    
    # 3.5 分析数据质量（空缺统计）
    print("\n[3.5/7] 分析数据质量（空缺统计）...")
    quality_stats = analyze_data_quality(all_poses)
    for field, q in quality_stats.items():
        print(f"  {field}: 有效 {q['valid']}/{q['total']} ({q['valid_rate']:.2f}%), 缺失 {q['missing']} ({q['missing_rate']:.2f}%)")
    
    # 4. 检测急刹事件
    print("\n[4/7] 检测急刹事件...")
    brake_events_df, brake_interval_stats = analyze_brake_events(all_poses, config)
    print(f"  检测到 {len(brake_events_df)} 次急刹事件")
    if len(brake_events_df) > 0:
        print(f"  其中 {brake_events_df['has_stop'].sum()} 次最终刹停")
    
    # 4.5 打印急刹区间内的空缺统计
    print("\n[4.5/9] 急刹区间内的空缺统计...")
    for field, q in brake_interval_stats.items():
        field_name = {'velocity': '速度', 'acc_long': '纵向加速度'}.get(field, field)
        print(f"  {field_name}: 有效 {q['valid']}/{q['total']} ({q['valid_rate']:.2f}%), 缺失 {q['missing']} ({q['missing_rate']:.2f}%)")
    
    # 4.6 分析刹车次数分布
    print("\n[4.6/9] 分析刹车次数分布（单次 vs 多次刹车）...")
    brake_stats = analyze_brake_count_per_scene(brake_events_df)
    print(f"  正样例场景总数: {brake_stats['total_scenes']}")
    print(f"  单次刹车场景: {brake_stats['single_brake_scenes']} ({100-brake_stats['multi_brake_ratio']:.1f}%)")
    print(f"  多次刹车场景: {brake_stats['multiple_brake_scenes']} ({brake_stats['multi_brake_ratio']:.1f}%)")
    print(f"  刹车事件总数: {brake_stats['total_brake_events']}")
    print(f"  平均每场景刹车次数: {brake_stats['mean_brakes_per_scene']:.2f}")
    
    interval_stats = analyze_brake_interval_statistics(brake_events_df)
    if interval_stats['has_multi_brake']:
        print(f"  多次刹车间隔统计:")
        print(f"    间隔次数: {interval_stats['count']}")
        print(f"    均值: {interval_stats['mean']:.2f}s | 标准差: {interval_stats['std']:.2f}s")
        print(f"    最小: {interval_stats['min']:.2f}s | 最大: {interval_stats['max']:.2f}s")
        print(f"    P25: {interval_stats['p25']:.2f}s | P50: {interval_stats['p50']:.2f}s | P75: {interval_stats['p75']:.2f}s | P90: {interval_stats['p90']:.2f}s")
    else:
        print("  无多次刹车场景，跳过刹车间隔分析")
    
    # 5. 分析刹车时间分布
    print("\n[5/9] 分析刹车时间分布...")
    timing_df = analyze_brake_timing(all_poses, brake_events_df, config)
    print(f"  有效时间分析样本: {len(timing_df)}")
    if len(timing_df) > 0:
        print(f"  刹车前持续时间 中位数: {timing_df['pre_brake_duration'].median():.1f}s")
        print(f"  急刹过程持续时间 中位数: {timing_df['brake_duration'].median():.1f}s")
        dec_median = timing_df['deceleration_duration'].median()
        print(f"  减速/刹停持续时间 中位数: {dec_median:.1f}s" if pd.notna(dec_median) else "  减速/刹停持续时间 中位数: N/A")
    
    # 6. 计算统计量
    print("\n[6/9] 计算统计指标...")
    stats = {
        'acc_long': calculate_statistics(all_acc_long),
        'velocity': calculate_statistics(all_velocities),
        'peak_acc': calculate_statistics(brake_events_df['peak_acc'].tolist()) if len(brake_events_df) > 0 else {},
        'initial_velocity': calculate_statistics(brake_events_df['initial_velocity'].tolist()) if len(brake_events_df) > 0 else {},
        'duration': calculate_statistics(brake_events_df['duration'].tolist()) if len(brake_events_df) > 0 else {},
    }
    
    # 7. 生成可视化和报告
    print("\n[7/9] 生成可视化图表...")
    
    # 数据质量图
    plot_data_quality(quality_stats, config.OUTPUT_DIR)
    
    # 刹车次数分布图
    plot_brake_count_distribution(brake_stats, config.OUTPUT_DIR)
    
    # 刹车时间分布图
    if len(timing_df) > 0:
        timing_recommend = plot_brake_timing_distribution(timing_df, config.OUTPUT_DIR)
    
    if len(brake_events_df) > 0:
        plot_acc_long_distribution(brake_events_df, config.OUTPUT_DIR)
        plot_statistics_summary(stats, brake_events_df, config.OUTPUT_DIR)
        
        print("\n  生成详细时序图（前5个场景）...")
        for i, (autoscene_id, poses) in enumerate(list(all_poses.items())[:5]):
            brake_events = detect_hard_brake_events(poses, config.HARD_BRAKE_THRESHOLD)
            if brake_events:
                plot_velocity_profile(poses, autoscene_id, brake_events, config.OUTPUT_DIR)
    
    # 8. 保存时间分析数据
    print("\n[8/9] 保存分析数据...")
    if len(brake_events_df) > 0:
        csv_path = os.path.join(config.OUTPUT_DIR, 'brake_events.csv')
        
        # 为列名添加中文解释
        column_mapping = {
            'autoscene_id': 'autoscene_id_场景ID',
            'scene_start_timestamp': 'scene_start_timestamp_场景第一帧时间戳(微秒)',
            'start_time': 'start_time_开始时间戳(微秒)',
            'start_relative_time_s': 'start_relative_time_s_开始相对时间(秒)',
            'peak_time': 'peak_time_峰值时间戳(微秒)',
            'peak_relative_time_s': 'peak_relative_time_s_峰值相对时间(秒)',
            'peak_acc': 'peak_acc_峰值加速度(m/s²)',
            'severity': 'severity_严重程度',
            'initial_velocity': 'initial_velocity_初始速度(m/s)',
            'min_velocity': 'min_velocity_最小速度(m/s)',
            'stop_time': 'stop_time_刹停时间戳(微秒)',
            'stop_relative_time_s': 'stop_relative_time_s_刹停相对时间(秒)',
            'duration': 'duration_持续时间(秒)',
            'has_stop': 'has_stop_是否刹停'
        }
        
        brake_events_df_with_chinese = brake_events_df.rename(columns=column_mapping)
        brake_events_df_with_chinese.to_csv(csv_path, index=False)
        print(f"刹车事件数据已保存: {csv_path}")
    
    if len(timing_df) > 0:
        timing_csv_path = os.path.join(config.OUTPUT_DIR, 'brake_timing.csv')
        
        # 为列名添加中文解释
        timing_column_mapping = {
            'autoscene_id': 'autoscene_id_场景ID',
            'pre_brake_duration': 'pre_brake_duration_刹车前持续时间(秒)',
            'brake_duration': 'brake_duration_急刹持续时间(秒)',
            'deceleration_duration': 'deceleration_duration_减速持续时间(秒)',
            'initial_velocity': 'initial_velocity_初始速度(m/s)',
            'peak_acc': 'peak_acc_峰值加速度(m/s²)',
            'has_stop': 'has_stop_是否刹停'
        }
        
        timing_df_with_chinese = timing_df.rename(columns=timing_column_mapping)
        timing_df_with_chinese.to_csv(timing_csv_path, index=False)
        print(f"刹车时间分析已保存: {timing_csv_path}")
    
    ids_path = os.path.join(config.OUTPUT_DIR, 'positive_autoscene_ids.txt')
    with open(ids_path, 'w') as f:
        for vid in sorted(positive_ids):
            f.write(f"{vid}\n")
    print(f"正样例ID列表已保存: {ids_path}")
    
    # 8.5 提取长时间间隔的多次刹车数据
    if interval_stats['has_multi_brake']:
        print("\n[8.5/9] 提取长时间间隔的多次刹车数据...")
        threshold_s = 5.0
        long_interval_df = extract_long_interval_brakes(brake_events_df, threshold_s)
        if len(long_interval_df) > 0:
            long_interval_csv_path = os.path.join(config.OUTPUT_DIR, 'long_interval_brakes.csv')
            column_mapping_long = {
                'autoscene_id': 'autoscene_id_场景ID',
                'brake_index': 'brake_index_第几次刹车',
                'interval_s': 'interval_s_间隔时间(秒)',
                'previous_brake_time': 'previous_brake_time_前一次刹车时间戳(微秒)',
                'previous_brake_relative_time': 'previous_brake_relative_time_前一次刹车相对时间(秒)',
                'current_brake_time': 'current_brake_time_当前刹车时间戳(微秒)',
                'current_brake_relative_time': 'current_brake_relative_time_当前刹车相对时间(秒)',
                'previous_peak_acc': 'previous_peak_acc_前一次峰值加速度(m/s²)',
                'current_peak_acc': 'current_peak_acc_当前峰值加速度(m/s²)'
            }
            long_interval_df_with_chinese = long_interval_df.rename(columns=column_mapping_long)
            long_interval_df_with_chinese.to_csv(long_interval_csv_path, index=False)
            print(f"  长时间间隔刹车数据已保存: {long_interval_csv_path}")
            print(f"  共发现 {len(long_interval_df)} 次间隔时间超过 {threshold_s}s 的刹车")
        else:
            print(f"  未发现间隔时间超过 {threshold_s}s 的刹车")
    else:
        print("\n[8.5/9] 跳过长时间间隔刹车数据提取（无多次刹车场景）")
    
    generate_report(stats, brake_events_df, quality_stats, brake_interval_stats, timing_df, config, config.OUTPUT_DIR)
    
    print("\n" + "=" * 60)
    print("分析完成！")
    print(f"输出目录: {config.OUTPUT_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()