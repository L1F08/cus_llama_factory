import os
import json
import re
import pandas as pd
from pathlib import Path
from typing import Set, Tuple, Dict, List, Optional
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

# 导入你之前的核心算法
from analysis_new import (
    Config, 
    load_ego_pose_json,  # 注意：这里只需要底层的单个加载函数
    detect_hard_brake_events
)

class ExtendedConfig(Config):
    CLASS0_EXCEL_PATH = "/home/ma-user/work/lyf/AEB0417/AEB_class0.xlsx"
    NEGATIVE_LABEL = "0"
    CAMERA_CACHE_DIR = "/cache"
    # ★★★ 必须与 config.yaml 的 cameras.use_cameras 以及 make_video 使用的摄像头一致 ★★★
    # 这里填缓存 /cache/.../samples 下真实的摄像头目录名。
    # 决定裁剪原点 t0 = max(这些摄像头各自的首帧时间戳)，与 make_video 的交集起点对齐。
    USED_CAMERAS = ["CAM_FRONT_WIDE_ANGLE", "CAM_FISHEYE_LEFT", "CAM_FISHEYE_RIGHT"]
    # 你可以保留几个核心给系统，比如用 180 个核狂跑
    MAX_WORKERS = min(180, os.cpu_count() or 180)


def extract_target_autoscene_ids(train_json_path: str, excel_path: str, positive_label: str, negative_label: str) -> Dict[str, str]:
    """
    修改后：返回字典 {autoscene_id: label}，用于追踪标签
    """
    allowed_negative_ids = set()
    if os.path.exists(excel_path):
        try:
            df = pd.read_excel(excel_path)
            for _, row in df.iterrows():
                uid = str(row.get('data_name', '')).strip()
                if uid:
                    allowed_negative_ids.add(uid)
            print(f"  [读取Excel] 加载了 {len(allowed_negative_ids)} 个允许的负样例 ID。")
        except Exception as e:
            print(f"  [读取Excel] 失败: {e}")

    target_dict = {}
    with open(train_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    for item in data:
        label = None
        for msg in item.get("messages", []):
            if msg.get("role") == "assistant":
                label = str(msg.get("content", "")).strip()
                break

        current_item_ids = set()
        for video_path in item.get("videos", []):
            autoscene_id = Path(video_path).stem
            if autoscene_id:
                current_item_ids.add(autoscene_id)

        if label == positive_label:
            for uid in current_item_ids:
                target_dict[uid] = positive_label
        elif label == negative_label:
            for uid in current_item_ids.intersection(allowed_negative_ids):
                target_dict[uid] = negative_label

    return target_dict


def get_real_video_start_ts(autoscene_id: str, base_cache_dir: str, used_cameras) -> float:
    """
    返回所有使用摄像头的「最大交集起点」= max(各摄像头首帧时间戳)。
    必须与 make_video 的 t_start 规则一致：make_video 让每路视频都从该原点开始，
    所以 crop_start_s 相对此原点计算后，对 front/left/right 同一刀切片都正确。
    used_cameras: 缓存 samples 下真实的摄像头目录名列表。
    任一摄像头缺失/无图 → 返回 None（交集起点无定义，由调用方退化处理）。
    """
    base = Path(base_cache_dir) / f"autoscenes_{autoscene_id}" / autoscene_id / "samples"
    starts = []
    for cam_name in used_cameras:
        cam_dir = base / cam_name
        if not cam_dir.exists():
            print(f"  [Debug] ⚠️ 硬盘上找不到图片目录: {cam_dir}")
            return None
        cam_ts = []
        for img_path in cam_dir.rglob("*.[jJ][pP][gG]"):
            match = re.search(r'_(\d+)\.[jJ][pP][gG]', img_path.name)
            if match:
                cam_ts.append(float(match.group(1)))
        if not cam_ts:
            print(f"  [Debug] ⚠️ 目录 {cam_dir} 存在，但没有匹配到正确格式的图片！")
            return None
        starts.append(min(cam_ts))
    # 最大交集起点：取所有摄像头首帧中最晚的那个
    return max(starts)


# ==========================================
# 核心 Worker 函数：处理单个场景（完全独立，线程安全）
# ==========================================
def process_single_scene(autoscene_id: str, label: str, config: ExtendedConfig) -> Tuple[Optional[Dict], List[Dict], str, str]:
    """
    修改后返回: (截短配置字典, 长间隔异常列表, 需要打印的日志信息, 状态码用于统计损耗)
    """
    log_msg = ""
    
    # 1. 加载本场景的 ego_pose
    autoscene_dir = Path(config.EGO_POSE_DIR) / autoscene_id
    ego_pose_files = list(autoscene_dir.rglob("ego_pose.json"))
    
    if not ego_pose_files:
        return None, [], "", "MISSING_EGO_POSE"  # 损耗：找不到ego_pose文件
        
    poses = load_ego_pose_json(str(ego_pose_files[0]))
    if not poses:
        return None, [], "", "EMPTY_EGO_POSE"    # 损耗：ego_pose文件内无数据

    # 2. 检测急刹
    events = detect_hard_brake_events(poses, config.HARD_BRAKE_THRESHOLD)
    if not events:
        return None, [], "", "NO_HARD_BRAKE"     # 损耗：没有检测到满足阈值的急刹

    # 3. 找视频绝对 0 秒（多摄像头：取最大交集起点，与 make_video 的 t_start 一致）
    video_start_ts = get_real_video_start_ts(autoscene_id, config.CAMERA_CACHE_DIR, config.USED_CAMERAS)
    if not video_start_ts:
        video_start_ts = poses[0].timestamp
        log_msg = f"  ⚠️ [图片缺失] {autoscene_id} 退化使用 ego_pose 时间\n"

    # 4. 寻找视频内的首次有效刹车
    valid_brake_idx = -1
    valid_brake_ts = 0.0
    valid_brake_time_s = 0.0

    for i, event in enumerate(events):
        brake_ts = poses[event[0]].timestamp
        brake_time_s = (brake_ts - video_start_ts) / 1e6
        if brake_time_s >= 0:
            valid_brake_idx = i
            valid_brake_ts = brake_ts
            valid_brake_time_s = brake_time_s
            break

    if valid_brake_idx == -1:
        return None, [], log_msg + f"  ⚠️ [全在画外] {autoscene_id} 所有刹车均在图片之前，跳过\n", "ALL_BRAKES_OUT_OF_BOUNDS" # 损耗：刹车时间在视频第一帧之前

    # 5. 生成截短字典
    crop_start_s = max(0.0, valid_brake_time_s - 3.0)
    crop_end_s = valid_brake_time_s + 0.0

    crop_dict = {
        'autoscene_id': autoscene_id,
        'label': label, # 把label也存进去，之后输出CSV会带上此列，方便验证
        'video_start_ts': video_start_ts, 
        'first_valid_brake_ts': valid_brake_ts, 
        'brake_time_s': round(valid_brake_time_s, 2),
        'crop_start_s': round(crop_start_s, 2),
        'crop_end_s': round(crop_end_s, 2),
        'duration_s': round(crop_end_s - crop_start_s, 2)
    }

    # 6. 生成长间隔异常列表
    long_interval_list = []
    if len(events) > 1:
        for i in range(1, len(events)):
            prev_ts = poses[events[i-1][0]].timestamp
            curr_ts = poses[events[i][0]].timestamp
            interval_s = (curr_ts - prev_ts) / 1e6

            if interval_s > 5.0:
                long_interval_list.append({
                    'autoscene_id': autoscene_id,
                    'brake_index': i + 1,
                    'interval_s': round(interval_s, 2),
                    'prev_brake_time_s': round((prev_ts - video_start_ts) / 1e6, 2),
                    'curr_brake_time_s': round((curr_ts - video_start_ts) / 1e6, 2)
                })

    return crop_dict, long_interval_list, log_msg, "SUCCESS"


# ==========================================
# 主函数：调度多进程并发
# ==========================================
def generate_crop_and_filter_configs_mp():
    config = ExtendedConfig()
    output_dir = config.OUTPUT_DIR
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 60)
    print(f"视频截短配置生成器 (⚡ 追踪增强版 - 并发数: {config.MAX_WORKERS})")
    print("=" * 60)

    # 1. 提取目标 ID
    print("\n[1/2] 提取并解析目标 autoscene_id...")
    target_dict = extract_target_autoscene_ids(
        config.TRAIN_JSON_PATH, config.CLASS0_EXCEL_PATH, config.POSITIVE_LABEL, config.NEGATIVE_LABEL
    )
    
    if not target_dict:
        print("未找到任何目标 ID，退出。")
        return

    all_crop_data = []
    all_long_intervals = []
    missing_image_ids = []
    
    # 新增统计指标
    stats_tracker = {
        "SUCCESS_LABEL_1": 0,
        "SUCCESS_LABEL_0": 0,
        "LOSS_MISSING_EGO_POSE": 0,
        "LOSS_EMPTY_EGO_POSE": 0,
        "LOSS_NO_HARD_BRAKE": 0,
        "LOSS_ALL_BRAKES_OUT_OF_BOUNDS": 0
    }
    
    print(f"\n[2/2] 启动多进程并发处理 {len(target_dict)} 条数据...")
    
    # 2. 核心：启动进程池
    with ProcessPoolExecutor(max_workers=config.MAX_WORKERS) as executor:
        # 注意传参的变化，把 label 一并传进去
        futures = {executor.submit(process_single_scene, uid, label, config): uid for uid, label in target_dict.items()}
        
        for future in tqdm(as_completed(futures), total=len(target_dict), desc="处理进度", unit="场景"):
            try:
                crop_dict, long_interval_list, log_msg, status = future.result()
                
                # 记录失败原因
                if status != "SUCCESS":
                    stats_tracker[f"LOSS_{status}"] += 1
                
                # 打印异常日志
                if log_msg:
                    tqdm.write(log_msg.strip())
                    if "[图片缺失]" in log_msg:
                        uid = futures[future]
                        missing_image_ids.append(uid)
                
                # 收集成功结果
                if crop_dict:
                    all_crop_data.append(crop_dict)
                    if crop_dict['label'] == config.POSITIVE_LABEL:
                        stats_tracker["SUCCESS_LABEL_1"] += 1
                    elif crop_dict['label'] == config.NEGATIVE_LABEL:
                        stats_tracker["SUCCESS_LABEL_0"] += 1

                if long_interval_list:
                    all_long_intervals.extend(long_interval_list)
                    
            except Exception as e:
                uid = futures[future]
                tqdm.write(f"  ❌ [致命错误] 处理 {uid} 时崩溃: {e}")

    # 3. 输出汇总结果
    total_loss = sum([v for k, v in stats_tracker.items() if k.startswith("LOSS")])
    
    print("\n" + "=" * 60)
    print("📊 [数据处理统计面板]")
    print(f"🎯 目标处理总数: {len(target_dict)} 条")
    print(f"✅ 成功生成配置: {len(all_crop_data)} 条")
    print(f"   ├─ 正样例 (Label 1) 成功: {stats_tracker['SUCCESS_LABEL_1']} 条")
    print(f"   └─ 负样例 (Label 0) 成功: {stats_tracker['SUCCESS_LABEL_0']} 条")
    print("-" * 60)
    print(f"📉 数据总损耗量: {total_loss} 条")
    print(f"   ├─ 缺少 ego_pose 文件 (MISSING_EGO_POSE):     {stats_tracker['LOSS_MISSING_EGO_POSE']} 条")
    print(f"   ├─ ego_pose 数据为空 (EMPTY_EGO_POSE):        {stats_tracker['LOSS_EMPTY_EGO_POSE']} 条")
    print(f"   ├─ 未检测到满足阈值的急刹 (NO_HARD_BRAKE):    {stats_tracker['LOSS_NO_HARD_BRAKE']} 条")
    print(f"   └─ 刹车发生在视频首帧之前 (OUT_OF_BOUNDS):    {stats_tracker['LOSS_ALL_BRAKES_OUT_OF_BOUNDS']} 条")
    print("=" * 60)

    crop_df = pd.DataFrame(all_crop_data)
    if not crop_df.empty:
        # 新增: 排序一下更整洁
        crop_df = crop_df.sort_values(by=['label', 'autoscene_id'], ascending=[False, True])
        crop_csv_path = os.path.join(output_dir, 'video_crop_config_3s.csv')
        crop_df.to_csv(crop_csv_path, index=False)
        print(f"✅ 截短配置文件已保存至: {crop_csv_path} (已包含 label 字段)")
    
    long_interval_df = pd.DataFrame(all_long_intervals)
    if not long_interval_df.empty:
        long_interval_csv_path = os.path.join(output_dir, 'long_interval_brakes_to_review.csv')
        long_interval_df.to_csv(long_interval_csv_path, index=False)
        print(f"⚠️ 长时间间隔(>5s)多刹车场景已保存至: {long_interval_csv_path} (共 {len(long_interval_df)} 条)")

    if missing_image_ids:
        missing_file_path = os.path.join(output_dir, 'missing_images_ids.txt')
        with open(missing_file_path, 'w', encoding='utf-8') as f:
            for uid in missing_image_ids:
                f.write(f"{uid}\n")
        print(f"📁 缺失图片的 ID 列表已保存至: {missing_file_path}")

if __name__ == "__main__":
    generate_crop_and_filter_configs_mp()