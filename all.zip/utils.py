"""
通用工具模块
提供配置管理、日志设置、文件处理等公共功能
"""
import os
import sys
import logging
import random
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import yaml
import pandas as pd
import cv2


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = Path(config_path)
        self.config = self._load_config()
    
    def _load_config(self) -> Dict:
        """加载YAML配置文件"""
        if not self.config_path.exists():
            raise FileNotFoundError(f"配置文件不存在: {self.config_path}")
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        return config
    
    def get(self, *keys, default=None):
        """获取嵌套配置值"""
        value = self.config
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                return default
            if value is None:
                return default
        return value
    
    def get_dataset_config(self, dataset_name: str) -> Dict:
        """获取数据集配置"""
        datasets = self.get("datasets", default={})
        if dataset_name not in datasets:
            raise ValueError(f"数据集配置不存在: {dataset_name}")
        return datasets[dataset_name]


def setup_logger(name: str, log_file: Optional[str] = None, level=logging.INFO) -> logging.Logger:
    """设置日志器"""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 清除已有的handlers
    logger.handlers.clear()
    
    # 控制台输出
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # 文件输出
    if log_file:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def load_autoscene_list(file_path: str, id_column: str = "autoscene_id") -> List[str]:
    """从CSV或Excel文件加载autoscene_id列表"""
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    # 根据扩展名选择读取方法
    if file_path.suffix.lower() == '.csv':
        df = pd.read_csv(file_path)
    elif file_path.suffix.lower() in ['.xlsx', '.xls']:
        df = pd.read_excel(file_path)
    else:
        raise ValueError(f"不支持的文件类型: {file_path.suffix}")
    
    if id_column not in df.columns:
        raise ValueError(f"列 '{id_column}' 不存在于文件中")
    
    # 提取并清洗ID
    autoscene_ids = []
    for aid in df[id_column].astype(str):
        aid = aid.strip()
        if aid and len(aid) == 32:
            autoscene_ids.append(aid)
    
    return autoscene_ids


def extract_autoscene_id(path: str) -> str:
    """从路径中提取autoscene_id（文件名不含扩展名）"""
    return Path(path).stem


def check_video_exists(video_dir: str, autoscene_id: str) -> bool:
    """检查视频文件是否存在"""
    video_path = Path(video_dir) / f"{autoscene_id}.mp4"
    return video_path.exists()


def get_video_info(video_path: str) -> Tuple[float, float, int, float, bool]:
    """
    获取视频详细信息
    
    Returns:
        (duration_sec, file_size_mb, frame_count, fps, is_valid)
    """
    video_path = Path(video_path)
    
    if not video_path.exists():
        return 0, 0, 0, 0, False
    
    file_size_mb = video_path.stat().st_size / (1024 * 1024)
    
    cap = cv2.VideoCapture(str(video_path))
    try:
        if not cap.isOpened():
            return 0, file_size_mb, 0, 0, False
        
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        if fps <= 0:
            return 0, file_size_mb, frame_count, 0, False
        
        duration_sec = frame_count / fps
        is_valid = True
        
    except Exception:
        return 0, file_size_mb, 0, 0, False
    finally:
        cap.release()
    
    return duration_sec, file_size_mb, frame_count, fps, is_valid


def is_video_corrupted(video_path: str) -> bool:
    """检查视频是否损坏（尝试读取第一帧和最后一帧）"""
    cap = cv2.VideoCapture(str(video_path))
    try:
        if not cap.isOpened():
            return True
        
        # 读取第一帧
        ret, _ = cap.read()
        if not ret:
            return True
        
        # 读取最后一帧
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, frame_count - 2))
        ret, _ = cap.read()
        
        return not ret
    except Exception:
        return True
    finally:
        cap.release()


def parse_timestamp_from_filename(filename: str) -> Optional[float]:
    """
    从文件名解析时间戳
    
    格式: {name}_{timestamp_us}.jpg
    返回: 时间戳（秒）
    """
    try:
        parts = filename.rsplit("_", 1)
        if len(parts) != 2:
            return None
        
        timestamp_us_str = parts[1].rsplit(".", 1)[0]
        timestamp_us = int(timestamp_us_str)
        timestamp_sec = timestamp_us / 1_000_000.0
        
        return timestamp_sec
    except Exception:
        return None


def get_image_timestamps(image_dir: str) -> List[Tuple[str, float]]:
    """
    获取目录中所有图片的时间戳
    
    Returns:
        [(filename, timestamp_sec), ...]
    """
    image_dir = Path(image_dir)
    
    if not image_dir.exists():
        return []
    
    image_timestamps = []
    for img_file in image_dir.iterdir():
        if img_file.suffix.lower() in ['.jpg', '.jpeg', '.png']:
            timestamp = parse_timestamp_from_filename(img_file.name)
            if timestamp is not None:
                image_timestamps.append((img_file.name, timestamp))
    
    return image_timestamps


def ensure_dir(path: str) -> Path:
    """确保目录存在"""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def sample_from_source(
    source_config: Dict,
    label: int,
    label_description: str,
    logger=None
) -> List[Dict]:
    """
    从单个数据源加载并采样autoscene_id
    
    Args:
        source_config: 数据源配置
        label: 类别标签
        label_description: 类别描述
        logger: 日志器（可选）
    
    Returns:
        采样后的样本列表 [{"autoscene_id": "...", "label": ..., "source": "..."}, ...]
    """
    source_path = source_config["path"]
    source_name = source_config.get("description", "未知来源")
    sample_count = source_config.get("sample_count", -1)
    
    try:
        # 加载所有ID
        ids = load_autoscene_list(
            source_path,
            source_config.get("id_column", "autoscene_id")
        )
        
        available_count = len(ids)
        
        # 根据 sample_count 采样
        if sample_count == -1:
            # -1 表示全部使用
            sampled_ids = ids
            if logger:
                logger.info(
                    f"类别 {label} - {source_name}: "
                    f"全部使用 {len(sampled_ids)} 个ID"
                )
        elif sample_count > available_count:
            # 样本不足，全部使用并警告
            sampled_ids = ids
            if logger:
                logger.warning(
                    f"类别 {label} - {source_name}: "
                    f"配置需要 {sample_count} 个，实际只有 {available_count} 个（全部使用）"
                )
        else:
            # 随机采样指定数量
            sampled_ids = random.sample(ids, sample_count)
            if logger:
                logger.info(
                    f"类别 {label} - {source_name}: "
                    f"从 {available_count} 个中采样 {len(sampled_ids)} 个"
                )
        
        # 构造样本列表
        samples = []
        for aid in sampled_ids:
            samples.append({
                "autoscene_id": aid,
                "label": label,
                "label_description": label_description,
                "source": source_name
            })
        
        return samples
        
    except Exception as e:
        if logger:
            logger.error(f"加载失败: {source_path}, 错误: {e}")
        return []