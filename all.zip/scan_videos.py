"""
视频扫描模块
检查视频质量和前后摄像头一致性，生成详细统计报告
支持增量扫描和结果合并
"""
import argparse
import json
from pathlib import Path
from typing import List, Dict
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

from utils import (
    ConfigManager, setup_logger, load_autoscene_list,
    get_video_info, is_video_corrupted, ensure_dir, sample_from_source
)


class VideoScanner:
    """视频扫描器（增量合并版）"""
    
    def __init__(self, config: ConfigManager, dataset_name: str):
        self.config = config
        self.dataset_name = dataset_name
        self.dataset_config = config.get_dataset_config(dataset_name)
        
        # 路径配置
        self.front_video_dir = Path(config.get("paths", "front_video_dir"))
        self.back_video_dir = Path(config.get("paths", "back_video_dir"))
        self.data_dir = Path(config.get("paths", "data_dir"))
        
        # 质量阈值
        self.max_duration = config.get("video_quality", "max_duration")
        self.max_size_mb = config.get("video_quality", "max_size_mb")
        self.frame_tolerance = config.get("video_quality", "frame_tolerance")
        self.duration_tolerance = config.get("video_quality", "duration_tolerance")
        
        # # 处理配置
        # self.max_workers = config.get("processing", "max_workers")
        # 处理配置
        self.max_workers = config.get("processing", "max_workers")
        
        # ========== 新增：读取使用的摄像头配置 ==========
        self.use_cameras = config.get("cameras", "use_cameras", default=["front", "back"])
        
        # 动态加载摄像头校验路径
        self.cam_configs = {}
        for cam in self.use_cameras:
            self.cam_configs[cam] = Path(config.get("paths", f"{cam}_video_dir"))
        # ===============================================
        
        # 设置日志
        # 设置日志
        output_dir = self.data_dir / self.dataset_config["name"]
        ensure_dir(output_dir)
        self.logger = setup_logger(
            "VideoScanner",
            log_file=output_dir / "scan_videos.log"
        )
        
        self.report_path = output_dir / "video_scan_report.json"
        
        self.logger.info("初始化扫描器: 增量合并模式")
    
    def _load_all_samples(self) -> List[Dict]:
        """加载所有样本信息（优先读取采样文件，兼容批次格式）"""
        # 检查是否存在采样文件
        output_dir = self.data_dir / self.dataset_config["name"]
        sampled_ids_file = output_dir / "sampled_autoscene_ids.json"
        
        if sampled_ids_file.exists():
            # 读取采样文件
            self.logger.info(f"📂 读取采样文件: {sampled_ids_file}")
            with open(sampled_ids_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # ========== 兼容新旧格式 ==========
            if isinstance(data, list):
                # 旧格式：列表
                samples = data
                self.logger.info(f"✅ 从采样文件加载 {len(samples)} 个样本（旧格式）")
            elif isinstance(data, dict):
                # 新格式：字典（批次）
                samples = []
                for batch in data.get("batches", []):
                    batch_samples = batch.get("samples", [])
                    samples.extend(batch_samples)
                    self.logger.info(
                        f"✅ 批次 {batch['batch_id']}: "
                        f"{len(batch_samples)} 个样本"
                    )
                self.logger.info(f"✅ 总计: {len(samples)} 个样本")
            else:
                self.logger.error("未知的采样文件格式")
                samples = []
            # ================================
            
            return samples
        else:
            # 如果没有采样文件，按原逻辑采样
            self.logger.warning(
                f"⚠️ 采样文件不存在: {sampled_ids_file}\n"
                "   将重新采样（可能与 download 阶段不一致）"
            )
            
            all_samples = []
            
            for class_cfg in self.dataset_config["classes"]:
                label = class_cfg["label"]
                label_description = class_cfg.get("description", f"Label {label}")
                
                for source in class_cfg["sources"]:
                    # 使用通用采样函数
                    source_samples = sample_from_source(
                        source, label, label_description, self.logger
                    )
                    all_samples.extend(source_samples)
            
            return all_samples
    
    def _load_existing_report(self) -> Dict:
        """加载已有的扫描报告"""
        if not self.report_path.exists():
            return None
        
        try:
            with open(self.report_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"加载已有报告失败: {e}")
            return None
    
    def _merge_scan_results(
        self,
        existing_report: Dict,
        new_valid_samples: List[Dict],
        new_invalid_samples: List[Dict]
    ) -> tuple[List[Dict], List[Dict]]:
        """
        合并新旧扫描结果
        
        Args:
            existing_report: 已有的报告
            new_valid_samples: 新扫描的有效样本
            new_invalid_samples: 新扫描的无效样本
        
        Returns:
            (merged_valid, merged_invalid): 合并后的有效和无效样本列表
        """
        if not existing_report:
            # 没有旧报告，直接返回新结果
            return new_valid_samples, new_invalid_samples
        
        self.logger.info(f"\n{'='*70}")
        self.logger.info(f"合并扫描结果")
        self.logger.info(f"{'='*70}")
        
        # ========== 提取旧数据 ==========
        old_valid = existing_report.get("valid_samples", [])
        old_invalid = existing_report.get("invalid_samples", [])
        
        self.logger.info(f"旧报告: 有效 {len(old_valid)} 个，无效 {len(old_invalid)} 个")
        self.logger.info(f"新扫描: 有效 {len(new_valid_samples)} 个，无效 {len(new_invalid_samples)} 个")
        
        # ========== 建立ID索引（便于更新） ==========
        # 旧数据的ID集合
        old_valid_ids = {s["autoscene_id"]: s for s in old_valid}
        old_invalid_ids = {s["autoscene_id"]: s for s in old_invalid}
        
        # ========== 合并逻辑 ==========
        merged_valid = {}
        merged_invalid = {}
        
        # 1. 先加入所有旧的有效样本
        merged_valid.update(old_valid_ids)
        
        # 2. 先加入所有旧的无效样本
        merged_invalid.update(old_invalid_ids)
        
        # 3. 处理新扫描的有效样本
        updated_count = 0
        new_count = 0
        
        for sample in new_valid_samples:
            aid = sample["autoscene_id"]
            
            if aid in merged_invalid:
                # 之前无效，现在有效 → 从无效移到有效
                del merged_invalid[aid]
                merged_valid[aid] = sample
                updated_count += 1
            elif aid in merged_valid:
                # 之前有效，现在也有效 → 更新
                merged_valid[aid] = sample
                updated_count += 1
            else:
                # 全新样本
                merged_valid[aid] = sample
                new_count += 1
        
        # 4. 处理新扫描的无效样本
        for sample in new_invalid_samples:
            aid = sample["autoscene_id"]
            
            if aid in merged_valid:
                # 之前有效，现在无效 → 从有效移到无效（罕见）
                del merged_valid[aid]
                merged_invalid[aid] = sample
                updated_count += 1
            elif aid in merged_invalid:
                # 之前无效，现在也无效 → 更新
                merged_invalid[aid] = sample
                updated_count += 1
            else:
                # 全新样本
                merged_invalid[aid] = sample
                new_count += 1
        
        self.logger.info(f"合并结果:")
        self.logger.info(f"  更新: {updated_count} 个")
        self.logger.info(f"  新增: {new_count} 个")
        self.logger.info(f"  总有效: {len(merged_valid)} 个")
        self.logger.info(f"  总无效: {len(merged_invalid)} 个")
        self.logger.info(f"{'='*70}\n")
        
        # ========== 转换为列表 ==========
        final_valid = list(merged_valid.values())
        final_invalid = list(merged_invalid.values())
        
        return final_valid, final_invalid
    
    # def _check_single_video(self, sample: Dict) -> Dict:
    #     """检查单个样本的视频"""
    #     autoscene_id = sample["autoscene_id"]
        
    #     front_video = self.front_video_dir / f"{autoscene_id}.mp4"
    #     back_video = self.back_video_dir / f"{autoscene_id}.mp4"
        
    #     result = {
    #         "autoscene_id": autoscene_id,
    #         "label": sample["label"],
    #         "label_description": sample.get("label_description", f"Label {sample['label']}"),
    #         "source": sample["source"],
    #         "front_video": str(front_video),
    #         "back_video": str(back_video),
    #         "valid": True,
    #         "issues": []
    #     }
        
    #     # 检查文件存在性
    #     if not front_video.exists():
    #         result["valid"] = False
    #         result["issues"].append("front_video_not_found")
    #         return result
        
    #     if not back_video.exists():
    #         result["valid"] = False
    #         result["issues"].append("back_video_not_found")
    #         return result
        
    #     # 获取视频信息
    #     front_info = get_video_info(str(front_video))
    #     back_info = get_video_info(str(back_video))
        
    #     front_duration, front_size, front_frames, front_fps, front_valid = front_info
    #     back_duration, back_size, back_frames, back_fps, back_valid = back_info
        
    #     # 检查视频是否有效
    #     if not front_valid:
    #         result["valid"] = False
    #         result["issues"].append("front_video_invalid")
    #         return result
        
    #     if not back_valid:
    #         result["valid"] = False
    #         result["issues"].append("back_video_invalid")
    #         return result
        
    #     # 记录视频信息
    #     result["front_duration"] = round(front_duration, 2)
    #     result["back_duration"] = round(back_duration, 2)
    #     result["front_frames"] = front_frames
    #     result["back_frames"] = back_frames
    #     result["front_size_mb"] = round(front_size, 2)
    #     result["back_size_mb"] = round(back_size, 2)
    #     result["frame_count"] = min(front_frames, back_frames)
        
    #     # 检查时长
    #     if front_duration > self.max_duration:
    #         result["valid"] = False
    #         result["issues"].append("front_too_long")
        
    #     if back_duration > self.max_duration:
    #         result["valid"] = False
    #         result["issues"].append("back_too_long")
        
    #     # 检查大小
    #     if front_size > self.max_size_mb:
    #         result["valid"] = False
    #         result["issues"].append("front_too_large")
        
    #     if back_size > self.max_size_mb:
    #         result["valid"] = False
    #         result["issues"].append("back_too_large")
        
    #     # 检查前后一致性
    #     frame_diff = abs(front_frames - back_frames)
    #     duration_diff = abs(front_duration - back_duration)
        
    #     if frame_diff > self.frame_tolerance:
    #         result["valid"] = False
    #         result["issues"].append("frame_count_mismatch")
    #         result["frame_diff"] = frame_diff
        
    #     if duration_diff > self.duration_tolerance:
    #         result["valid"] = False
    #         result["issues"].append("duration_mismatch")
    #         result["duration_diff"] = round(duration_diff, 2)
        
    #     return result
    # def _check_single_video(self, sample: Dict) -> Dict:
    #     """检查单个样本的视频 (支持动态单/双摄)"""
    #     autoscene_id = sample["autoscene_id"]
        
    #     result = {
    #         "autoscene_id": autoscene_id,
    #         "label": sample["label"],
    #         "label_description": sample.get("label_description", f"Label {sample['label']}"),
    #         "source": sample["source"],
    #         "valid": True,
    #         "issues": []
    #     }
        
    #     front_video = self.front_video_dir / f"{autoscene_id}.mp4"
    #     back_video = self.back_video_dir / f"{autoscene_id}.mp4"
        
    #     # 按需记录视频路径
    #     if "front" in self.use_cameras:
    #         result["front_video"] = str(front_video)
    #     if "back" in self.use_cameras:
    #         result["back_video"] = str(back_video)
            
    #     # ==================== 1. 检查前视 ====================
    #     if "front" in self.use_cameras:
    #         if not front_video.exists():
    #             result["valid"] = False
    #             result["issues"].append("front_video_not_found")
    #             return result
            
    #         f_dur, f_size, f_frames, f_fps, f_valid = get_video_info(str(front_video))
            
    #         if not f_valid:
    #             result["valid"] = False
    #             result["issues"].append("front_video_invalid")
    #             return result
                
    #         result["front_duration"] = round(f_dur, 2)
    #         result["front_size_mb"] = round(f_size, 2)
    #         result["front_frames"] = f_frames
    #         result["frame_count"] = f_frames  # 暂定基准帧数
            
    #         if f_dur > self.max_duration:
    #             result["valid"] = False
    #             result["issues"].append("front_too_long")
    #         if f_size > self.max_size_mb:
    #             result["valid"] = False
    #             result["issues"].append("front_too_large")

    #     # ==================== 2. 检查后视 ====================
    #     if "back" in self.use_cameras:
    #         if not back_video.exists():
    #             result["valid"] = False
    #             result["issues"].append("back_video_not_found")
    #             return result
                
    #         b_dur, b_size, b_frames, b_fps, b_valid = get_video_info(str(back_video))
            
    #         if not b_valid:
    #             result["valid"] = False
    #             result["issues"].append("back_video_invalid")
    #             return result
                
    #         result["back_duration"] = round(b_dur, 2)
    #         result["back_size_mb"] = round(b_size, 2)
    #         result["back_frames"] = b_frames
    #         result["frame_count"] = b_frames  # 如果没有前视，则以此为基准
            
    #         if b_dur > self.max_duration:
    #             result["valid"] = False
    #             result["issues"].append("back_too_long")
    #         if b_size > self.max_size_mb:
    #             result["valid"] = False
    #             result["issues"].append("back_too_large")

    #     # ==================== 3. 检查前后一致性 ====================
    #     # （仅在同时启用了前视和后视时才进行对比）
    #     if "front" in self.use_cameras and "back" in self.use_cameras:
    #         frame_diff = abs(result["front_frames"] - result["back_frames"])
    #         duration_diff = abs(result["front_duration"] - result["back_duration"])
            
    #         if frame_diff > self.frame_tolerance:
    #             result["valid"] = False
    #             result["issues"].append("frame_count_mismatch")
    #             result["frame_diff"] = frame_diff
                
    #         if duration_diff > self.duration_tolerance:
    #             result["valid"] = False
    #             result["issues"].append("duration_mismatch")
    #             result["duration_diff"] = round(duration_diff, 2)
                
    #         # 最终帧数取两者中的较小值
    #         result["frame_count"] = min(result["front_frames"], result["back_frames"])

    #     return result
    def _check_single_video(self, sample: Dict) -> Dict:
        """检查单个样本的视频 (完全动态兼容任意多摄)"""
        autoscene_id = sample["autoscene_id"]
        
        result = {
            "autoscene_id": autoscene_id,
            "label": sample["label"],
            "label_description": sample.get("label_description", f"Label {sample['label']}"),
            "source": sample["source"],
            "valid": True,
            "issues": []
        }
        
        cam_results = {}
        
        # 1. 动态检查所有配置的摄像头
        for cam, video_dir in self.cam_configs.items():
            video_path = video_dir / f"{autoscene_id}.mp4"
            result[f"{cam}_video"] = str(video_path)
            
            if not video_path.exists():
                result["valid"] = False
                result["issues"].append(f"{cam}_video_not_found")
                return result
                
            dur, size, frames, fps, valid = get_video_info(str(video_path))
            
            if not valid:
                result["valid"] = False
                result["issues"].append(f"{cam}_video_invalid")
                return result
                
            # 记录数据
            result[f"{cam}_duration"] = round(dur, 2)
            result[f"{cam}_size_mb"] = round(size, 2)
            result[f"{cam}_frames"] = frames
            cam_results[cam] = {"dur": dur, "frames": frames, "size": size}
            
            # 质量校验
            if dur > self.max_duration:
                result["valid"] = False
                result["issues"].append(f"{cam}_too_long")
            if size > self.max_size_mb:
                result["valid"] = False
                result["issues"].append(f"{cam}_too_large")
                
        if not result["valid"]:
            return result

        # 2. 检查多摄一致性 (仅在使用了2个及以上摄像头时触发)
        if len(cam_results) >= 2:
            frames_list = [v["frames"] for v in cam_results.values()]
            durations_list = [v["dur"] for v in cam_results.values()]
            
            max_frame_diff = max(frames_list) - min(frames_list)
            max_dur_diff = max(durations_list) - min(durations_list)
            
            if max_frame_diff > self.frame_tolerance:
                result["valid"] = False
                result["issues"].append("frame_count_mismatch")
                result["frame_diff"] = max_frame_diff
                
            if max_dur_diff > self.duration_tolerance:
                result["valid"] = False
                result["issues"].append("duration_mismatch")
                result["duration_diff"] = round(max_dur_diff, 2)
                
        # 3. 最终帧数取所有摄像头中的最小值作为基准
        if cam_results:
            result["frame_count"] = min(v["frames"] for v in cam_results.values())
        else:
            result["frame_count"] = 0

        return result
    def _generate_statistics(self, valid_samples: List[Dict], invalid_samples: List[Dict]) -> Dict:
        """生成统计报告"""
        stats = {
            "summary": {
                "total_samples": len(valid_samples) + len(invalid_samples),
                "valid_samples": len(valid_samples),
                "invalid_samples": len(invalid_samples)
            },
            "by_label": defaultdict(lambda: {
                "description": "",
                "total": 0,
                "valid": 0,
                "by_source": defaultdict(lambda: {
                    "total": 0,
                    "valid": 0,
                    "invalid": defaultdict(int)
                })
            }),
            "valid_samples": valid_samples,
            "invalid_samples": invalid_samples
        }
        
        # 处理有效样本
        for r in valid_samples:
            label = r["label"]
            source = r["source"]
            
            stats["by_label"][label]["description"] = r["label_description"]
            stats["by_label"][label]["total"] += 1
            stats["by_label"][label]["valid"] += 1
            
            source_stats = stats["by_label"][label]["by_source"][source]
            source_stats["total"] += 1
            source_stats["valid"] += 1
        
        # 处理无效样本
        for r in invalid_samples:
            label = r["label"]
            source = r["source"]
            
            stats["by_label"][label]["description"] = r["label_description"]
            stats["by_label"][label]["total"] += 1
            
            source_stats = stats["by_label"][label]["by_source"][source]
            source_stats["total"] += 1
            
            for issue in r["issues"]:
                source_stats["invalid"][issue] += 1
        
        # 转换defaultdict为普通dict
        stats["by_label"] = dict(stats["by_label"])
        for label in stats["by_label"]:
            stats["by_label"][label]["by_source"] = dict(
                stats["by_label"][label]["by_source"]
            )
            for source in stats["by_label"][label]["by_source"]:
                stats["by_label"][label]["by_source"][source]["invalid"] = dict(
                    stats["by_label"][label]["by_source"][source]["invalid"]
                )
        
        return stats
    
    def _print_statistics(self, stats: Dict):
        """打印统计信息"""
        self.logger.info("\n" + "=" * 70)
        self.logger.info("📊 视频扫描统计报告")
        self.logger.info("=" * 70)
        
        summary = stats["summary"]
        self.logger.info(f"\n总计: {summary['total_samples']} 个样本")
        self.logger.info(f"✅ 有效: {summary['valid_samples']} 个")
        self.logger.info(f"❌ 无效: {summary['invalid_samples']} 个")
        
        # 按类别打印
        for label, label_stats in sorted(stats["by_label"].items()):
            self.logger.info(f"\n{'─' * 70}")
            self.logger.info(
                f"类别 {label}: {label_stats['description']} "
                f"(总计: {label_stats['total']}, 有效: {label_stats['valid']})"
            )
            
            for source, source_stats in label_stats["by_source"].items():
                valid_rate = (
                    source_stats["valid"] / source_stats["total"] * 100
                    if source_stats["total"] > 0 else 0
                )
                
                self.logger.info(
                    f"  📁 {source}: {source_stats['valid']}/{source_stats['total']} "
                    f"({valid_rate:.1f}%)"
                )
                
                if source_stats["invalid"]:
                    for issue, count in source_stats["invalid"].items():
                        self.logger.info(f"     ❌ {issue}: {count}")
        
        self.logger.info("=" * 70)
    
    def scan_all_videos(self):
        """扫描所有视频（增量模式）"""
        self.logger.info(f"=" * 70)
        self.logger.info(f"开始扫描视频: {self.dataset_name}")
        self.logger.info(f"模式: 增量合并")
        self.logger.info(f"=" * 70)
        
        # 加载所有样本（兼容批次格式）
        samples = self._load_all_samples()
        self.logger.info(f"总计: {len(samples)} 个样本")
        
        # ========== 增量模式：只扫描新样本 ==========
        existing_report = self._load_existing_report()
        
        if existing_report:
            # 提取已扫描的ID
            scanned_ids = set()
            for s in existing_report.get("valid_samples", []):
                scanned_ids.add(s["autoscene_id"])
            for s in existing_report.get("invalid_samples", []):
                scanned_ids.add(s["autoscene_id"])
            
            # 过滤已扫描的
            original_count = len(samples)
            samples = [s for s in samples if s["autoscene_id"] not in scanned_ids]
            
            self.logger.info(f"已扫描: {len(scanned_ids)} 个")
            self.logger.info(f"待扫描: {len(samples)} 个（新增）")
        else:
            self.logger.info("未找到已有报告，执行完整扫描")
        # ==========================================
        
        if not samples:
            self.logger.info("✅ 没有新样本需要扫描")
            
            # 如果有旧报告，重新打印统计
            if existing_report:
                self._print_statistics(existing_report)
            
            return
        
        self.logger.info(f"开始扫描: {len(samples)} 个样本")
        
        # 多进程扫描
        results = []
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self._check_single_video, sample): sample
                for sample in samples
            }
            
            for future in tqdm(
                as_completed(futures),
                total=len(samples),
                desc="扫描视频"
            ):
                result = future.result()
                results.append(result)
        
        # 分离有效和无效样本
        new_valid_samples = [r for r in results if r.get("valid", False)]
        new_invalid_samples = [r for r in results if not r.get("valid", False)]
        
        # ========== 合并新旧结果 ==========
        merged_valid, merged_invalid = self._merge_scan_results(
            existing_report,
            new_valid_samples,
            new_invalid_samples
        )
        # ================================
        
        # 生成统计报告
        stats = self._generate_statistics(merged_valid, merged_invalid)
        
        # 打印统计
        self._print_statistics(stats)
        
        # 保存报告
        with open(self.report_path, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)
        
        self.logger.info(f"\n📁 扫描报告已保存: {self.report_path}")


def main():
    parser = argparse.ArgumentParser(description="扫描视频质量和一致性（增量合并模式）")
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    
    args = parser.parse_args()
    
    config = ConfigManager(args.config)
    scanner = VideoScanner(config, args.dataset)
    scanner.scan_all_videos()


if __name__ == "__main__":
    main()