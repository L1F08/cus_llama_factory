"""
数据集构建模块
从扫描报告中采样生成训练/测试集JSON
支持摄像头选择：front、back、或 front+back
支持车辆信息增强：可选择添加速度、加速度等信息
"""
import argparse
import json
import random
from pathlib import Path
from typing import List, Dict, Set, Optional
from collections import defaultdict

from utils import (
    ConfigManager, setup_logger, ensure_dir, extract_autoscene_id
)

# 导入车辆信息管理模块
try:
    from ego_info_manager import create_ego_info_manager_from_config, EgoInfoManager
    EGO_INFO_AVAILABLE = True
except ImportError:
    EgoInfoManager = None
    EGO_INFO_AVAILABLE = False


class DatasetBuilder:
    """数据集构建器（支持摄像头选择和车辆信息增强）"""
    
    def __init__(self, config: ConfigManager, dataset_name: str, 
                 use_cameras=None, use_ego_info=None):
        self.config = config
        self.dataset_name = dataset_name
        self.dataset_config = config.get_dataset_config(dataset_name)
        
        # 路径配置
        self.data_dir = Path(config.get("paths", "data_dir"))
        
        # 数据集配置
        self.dataset_type = self.dataset_config["type"]
        self.prompt_key = self.dataset_config.get("prompt_key")
        self.instruction_prompt = config.get("prompts", self.prompt_key, default="")
        
        # ========== 摄像头配置 ==========
        if use_cameras is not None:
            # 优先使用命令行参数
            self.use_cameras = use_cameras
        else:
            # 读取配置文件
            self.use_cameras = config.get("cameras", "use_cameras", 
                                          default=["front", "back"])
        
        # 归一化为小写列表
        if isinstance(self.use_cameras, str):
            self.use_cameras = [self.use_cameras.lower()]
        else:
            self.use_cameras = [cam.lower() for cam in self.use_cameras]
        
        # 验证配置（与 scan/make_video/download 保持一致，支持前后及左右鱼眼）
        valid_cameras = {"front", "back", "left", "right"}
        for cam in self.use_cameras:
            if cam not in valid_cameras:
                raise ValueError(f"无效的摄像头配置: {cam}")

        if not self.use_cameras:
            raise ValueError("至少需要指定一个摄像头")

        # 各摄像头在 prompt 中的中文显示名（可在 config.yaml 的 cameras.<cam>.prompt_name 覆盖）
        default_prompt_names = {
            "front": "前视视角",
            "back": "后视视角",
            "left": "左视视角",
            "right": "右视视角",
        }
        self.cam_prompt_names = {
            cam: self.config.get("cameras", cam, "prompt_name",
                                 default=default_prompt_names.get(cam, cam))
            for cam in self.use_cameras
        }
        # ================================
        
        # ========== EgoInfo 配置 ==========
        if use_ego_info is not None:
            # 命令行参数优先
            self.use_ego_info = use_ego_info
        else:
            # 读取数据集配置
            self.use_ego_info = self.dataset_config.get("use_ego_info", False)
        
        # 初始化 EgoInfoManager
        self.ego_info_manager: Optional[EgoInfoManager] = None
        
        if self.use_ego_info:
            if not EGO_INFO_AVAILABLE:
                raise ImportError(
                    "ego_info_manager.py 模块不可用！\n"
                    "请确保 ego_info_manager.py 在同一目录下"
                )
            
            # 准备配置
            ego_info_config = self._prepare_ego_info_config()
            
            # 创建管理器
            self.ego_info_manager = create_ego_info_manager_from_config(ego_info_config)
        # ==================================
        
        # 处理配置
        self.seed = config.get("processing", "seed")
        random.seed(self.seed)
        
        # 设置日志
        self.output_dir = self.data_dir / self.dataset_config["name"]
        ensure_dir(self.output_dir)
        self.logger = setup_logger(
            "DatasetBuilder",
            log_file=self.output_dir / "build_dataset.log"
        )
        
        # 输入路径
        self.report_path = self.output_dir / "video_scan_report.json"
        
        # 输出路径会在build_dataset中根据样本数设置
        self.output_path = None
        self.output_path_jsonl = None
        
        self.logger.info(f"使用摄像头: {', '.join(self.use_cameras)}")
        
        if self.use_ego_info:
            enabled_fields = self.ego_info_manager.get_enabled_fields()
            self.logger.info(f"使用车辆信息: {', '.join(enabled_fields)}")
    
    def _prepare_ego_info_config(self) -> Dict:
        """准备 EgoInfo 配置"""
        # 读取全局配置
        ego_info_config = {
            "cache_dir": self.config.get("ego_info", "cache_dir"),
            "interval_seconds": self.config.get("ego_info", "interval_seconds", default=0.5),
            "enabled_fields": self.config.get("ego_info", "enabled_fields", 
                                             default=["velocity", "acc_long", "acc_lat", "steer"]),
            "download": self.config.get("ego_info", "download", default={}),
            "prompt": self.config.get("ego_info", "prompt", default={}),
            "storage": {
                "guiyang": self.config.get("storage", "guiyang", default={}),
                "yd": self.config.get("storage", "yd", default={})
            }
        }
        
        # 数据集特定配置可以覆盖全局配置
        dataset_fields = self.dataset_config.get("ego_info_fields")
        if dataset_fields is not None:
            ego_info_config["enabled_fields"] = dataset_fields
        
        return ego_info_config
    
    def _load_scan_report(self) -> Dict:
        """加载扫描报告"""
        if not self.report_path.exists():
            raise FileNotFoundError(
                f"扫描报告不存在: {self.report_path}\n"
                "请先运行 scan_videos.py"
            )
        
        with open(self.report_path, 'r', encoding='utf-8') as f:
            report = json.load(f)
        
        return report
    
    def _load_excluded_ids(self) -> Set[str]:
        """加载需要排除的训练集ID（测试集模式）"""
        excluded_ids = set()
        
        exclude_path = self.dataset_config.get("exclude_train_json")
        if not exclude_path:
            return excluded_ids
        
        exclude_path = Path(exclude_path)
        if not exclude_path.exists():
            self.logger.warning(f"排除文件不存在: {exclude_path}")
            return excluded_ids
        
        try:
            with open(exclude_path, 'r', encoding='utf-8') as f:
                train_data = json.load(f)
            
            for item in train_data:
                if "videos" in item and len(item["videos"]) > 0:
                    video_path = item["videos"][0]
                    autoscene_id = extract_autoscene_id(video_path)
                    excluded_ids.add(autoscene_id)
            
            self.logger.info(f"从训练集排除 {len(excluded_ids)} 个ID")
        
        except Exception as e:
            self.logger.error(f"加载排除文件失败: {e}")
        
        return excluded_ids
    
    def _load_ids_from_csv(self, source_cfg: Dict) -> Set[str]:
        """从CSV或Excel加载ID集合"""
        csv_path = source_cfg.get("path")
        if not csv_path:
            return set()
        
        csv_path = Path(csv_path)
        if not csv_path.exists():
            self.logger.warning(f"文件不存在: {csv_path}")
            return set()
        
        try:
            import pandas as pd
            id_column = source_cfg.get("id_column", "autoscene_id")
            
            # 根据文件扩展名选择读取方法
            suffix = csv_path.suffix.lower()
            
            if suffix == ".xlsx" or suffix == ".xls":
                # Excel文件
                df = pd.read_excel(csv_path)
            else:
                # CSV文件，尝试多种编码
                for encoding in ['utf-8', 'gbk', 'gb18030', 'latin1']:
                    try:
                        df = pd.read_csv(csv_path, encoding=encoding)
                        break
                    except UnicodeDecodeError:
                        continue
            
            ids = set(df[id_column].astype(str).tolist())
            return ids
        except Exception as e:
            self.logger.error(f"加载文件失败 {csv_path}: {e}")
            return set()
    
    def _deduplicate_samples(self, samples: List[Dict]) -> List[Dict]:
        """
        按autoscene_id去重，每个ID只保留第一个样本
        """
        seen_ids = set()
        deduplicated = []
        
        for sample in samples:
            aid = sample["autoscene_id"]
            if aid not in seen_ids:
                deduplicated.append(sample)
                seen_ids.add(aid)
        
        return deduplicated
    
    def _collect_source_samples(
        self,
        label: int,
        source_cfg: Dict,
        grouped: Dict,
        used_ids: Set[str]
    ) -> tuple[List[Dict], bool]:
        """
        收集某个source的样本
        
        Returns:
            (samples, is_hard): 样本列表和是否为难例标识
        """
        source_description = source_cfg.get("description", "未知来源")
        is_hard = (source_description == "hard")
        
        # 从CSV加载该source的ID列表
        source_ids = self._load_ids_from_csv(source_cfg)
        
        if not source_ids:
            self.logger.warning(f"   {source_description}: 未能加载任何ID")
            return [], is_hard
        
        self.logger.info(f"   {source_description}: CSV中有 {len(source_ids)} 个唯一ID")
        
        # 从grouped中查找匹配的样本（任意source）
        all_samples_for_label = []
        for source_name, samples in grouped[label].items():
            all_samples_for_label.extend(samples)
        
        # 筛选：ID在source_ids中 且 未被使用
        available = [
            s for s in all_samples_for_label
            if s["autoscene_id"] in source_ids and s["autoscene_id"] not in used_ids
        ]
        
        # 按ID去重
        deduplicated = self._deduplicate_samples(available)
        
        self.logger.info(
            f"      扫描到样本: {len(available)} 个, "
            f"去重后: {len(deduplicated)} 个"
        )
        
        # ========== 根据 sample_count 采样 ==========
        sample_count = source_cfg.get("sample_count", -1)
        
        if sample_count == -1:
            # 使用所有可用样本
            sampled = deduplicated
            self.logger.info(f"      sample_count=-1: 使用所有 {len(sampled)} 个")
        elif sample_count == 0:
            # 不使用任何样本
            sampled = []
            self.logger.info(f"      sample_count=0: 不使用任何样本")
        elif sample_count >= len(deduplicated):
            # 需要的比可用的多，全部使用
            sampled = deduplicated
            self.logger.info(
                f"      sample_count={sample_count}: "
                f"可用 {len(deduplicated)} 个，全部使用"
            )
        else:
            # 随机采样指定数量
            sampled = random.sample(deduplicated, sample_count)
            self.logger.info(
                f"      sample_count={sample_count}: "
                f"从 {len(deduplicated)} 个中采样 {sample_count} 个"
            )
        # ===========================================
        
        return sampled, is_hard
    
    def _sample_by_config(
        self,
        valid_samples: List[Dict],
        excluded_ids: Set[str]
    ) -> List[Dict]:
        """按配置采样"""
        # 按label和source分组
        grouped = defaultdict(lambda: defaultdict(list))
        
        for sample in valid_samples:
            if sample["autoscene_id"] not in excluded_ids:
                label = sample["label"]
                source = sample["source"]
                grouped[label][source].append(sample)
        
        # 全局已使用ID集合（确保不重复）
        used_ids = set()
        sampled_samples = []
        
        for class_cfg in self.dataset_config["classes"]:
            label = class_cfg["label"]
            description = class_cfg.get("description", f"Label {label}")
            
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"类别 {label}: {description}")
            self.logger.info(f"{'='*60}")
            
            # 先收集所有source的样本，区分难例和普通样本
            hard_samples = []
            normal_samples = []
            
            for source_cfg in class_cfg["sources"]:
                samples, is_hard = self._collect_source_samples(
                    label, source_cfg, grouped, used_ids
                )
                # 【修改点：拿到样本后，立刻将 ID 加入 used_ids，防止下一个 source 再次抽到！】
                for s in samples:
                    used_ids.add(s["autoscene_id"])
                if is_hard:
                    hard_samples.extend(samples)
                else:
                    normal_samples.extend(samples)
            
            self.logger.info(f"\n汇总:")
            self.logger.info(f"   难例样本数: {len(hard_samples)}")
            self.logger.info(f"   普通样本数: {len(normal_samples)}")
            
            # ========== 所有样本已经按 sample_count 采样好了 ==========
            # 直接合并所有样本
            sampled = hard_samples + normal_samples
            
            self.logger.info(f"   实际采样总数: {len(sampled)}")
            # =======================================================
            
            # # 记录已使用ID（关键：确保跨类别也不重复）
            # for s in sampled:
            #     used_ids.add(s["autoscene_id"])
            
            sampled_samples.extend(sampled)
        
        return sampled_samples
    
    def _create_train_item(self, sample: Dict) -> Dict:
        """创建训练集格式数据项（支持摄像头选择和车辆信息）"""
        # ========== 根据摄像头配置动态构建 ==========
        videos = []
        prompt_parts = []

        for cam in self.use_cameras:
            prompt_parts.append(f"{self.cam_prompt_names[cam]}<video>")
            videos.append(sample[f"{cam}_video"])
        
        # ========== 车辆信息放在最后一个视频之后 ==========
        if self.use_ego_info and self.ego_info_manager:
            ego_info_prompt = self.ego_info_manager.get_prompt(
                sample["autoscene_id"]
            )
            # 车辆信息在视频之后，任务说明之前
            base_prompt = "".join(prompt_parts) + ego_info_prompt + self.instruction_prompt
        else:
            base_prompt = "".join(prompt_parts) + self.instruction_prompt
        # ================================================
        
        user_content = f"{base_prompt}"
        assistant_content = str(sample["label"])
        
        return {
            "messages": [
                {"role": "user", "content": user_content},
                {"role": "assistant", "content": assistant_content}
            ],
            "videos": videos
        }

    def _create_test_item(self, sample: Dict) -> Dict:
        """创建测试集格式数据项（不带label，支持摄像头选择和车辆信息）"""
        # ========== 根据摄像头配置动态构建 ==========
        content = []
        
        for cam in self.use_cameras:
            content.extend([
                {"type": "text", "text": self.cam_prompt_names[cam]},
                {
                    "type": "video",
                    "video": sample[f"{cam}_video"],
                    "max_pixels": 336000
                }
            ])
        
        # ========== 车辆信息放在最后一个视频之后 ==========
        if self.use_ego_info and self.ego_info_manager:
            ego_info_prompt = self.ego_info_manager.get_prompt(
                sample["autoscene_id"]
            )
            content.append({"type": "text", "text": ego_info_prompt})
        # ================================================
        
        content.append({"type": "text", "text": self.instruction_prompt})
        # ==========================================
        
        return [{
            "role": "user",
            "content": content
        }]

    def _create_test_item_with_label(self, sample: Dict) -> Dict:
        """创建带标签的测试集格式数据项（用于JSONL，支持摄像头选择和车辆信息）"""
        # ========== 根据摄像头配置动态构建 ==========
        content = []
        
        for cam in self.use_cameras:
            content.extend([
                {"type": "text", "text": self.cam_prompt_names[cam]},
                {
                    "type": "video",
                    "video": sample[f"{cam}_video"],
                    "max_pixels": 336000
                }
            ])
        
        # ========== 车辆信息放在最后一个视频之后 ==========
        if self.use_ego_info and self.ego_info_manager:
            ego_info_prompt = self.ego_info_manager.get_prompt(
                sample["autoscene_id"]
            )
            content.append({"type": "text", "text": ego_info_prompt})
        # ================================================
        
        content.append({"type": "text", "text": self.instruction_prompt})
        # ==========================================
        
        return {
            "id": sample["autoscene_id"],
            "label": sample["label"],
            "content": content
        }
    
    def build_dataset(self):
        """构建数据集"""
        self.logger.info(f"=" * 60)
        self.logger.info(f"开始构建数据集: {self.dataset_name}")
        self.logger.info(f"数据集类型: {self.dataset_type}")
        self.logger.info(f"使用摄像头: {', '.join(self.use_cameras)}")
        if self.use_ego_info:
            enabled_fields = self.ego_info_manager.get_enabled_fields()
            self.logger.info(f"使用车辆信息: {', '.join(enabled_fields)}")
        self.logger.info(f"=" * 60)
        
        # 加载扫描报告
        report = self._load_scan_report()
        valid_samples = report["valid_samples"]
        
        self.logger.info(f"有效样本总数: {len(valid_samples)}")
        
        # 加载排除ID
        excluded_ids = self._load_excluded_ids()
        
        # 按配置采样
        sampled_samples = self._sample_by_config(valid_samples, excluded_ids)
        
        self.logger.info(f"\n采样后总数: {len(sampled_samples)}")
        
        # 验证：检查是否有重复ID
        sampled_ids = [s["autoscene_id"] for s in sampled_samples]
        unique_ids = set(sampled_ids)
        if len(sampled_ids) != len(unique_ids):
            self.logger.warning(
                f"警告：发现重复ID！总样本数: {len(sampled_ids)}, "
                f"唯一ID数: {len(unique_ids)}"
            )
        else:
            self.logger.info(f"验证通过：所有样本ID唯一")
        
        # 打乱顺序
        random.shuffle(sampled_samples)
        
        # 生成数据项
        total_samples = len(sampled_samples)
        
        # ========== 根据摄像头和车辆信息生成文件名后缀 ==========
        camera_suffix = "_".join(self.use_cameras)
        
        if self.use_ego_info:
            ego_info_suffix = "_with_ego_info"
        else:
            ego_info_suffix = ""
        # =========================================================

        # ================== 【新增】并发预下载车辆信息 ==================
        if self.use_ego_info and self.ego_info_manager and self.ego_info_manager.config.download_enabled:
            self.logger.info(f"\n" + "=" * 60)
            self.logger.info("开始准备车辆信息 (ego_pose.json)...")
            
            from concurrent.futures import ThreadPoolExecutor, as_completed
            from tqdm import tqdm
            
            max_workers = self.ego_info_manager.config.max_workers
            cache_dir = self.ego_info_manager.cache_dir
            
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = []
                for sample in sampled_samples:
                    aid = sample["autoscene_id"]
                    # 拼接目标文件路径，检查是否已缓存
                    ego_pose_file = cache_dir / aid / "v1.1.6" / "ego_pose.json"
                    
                    # 只有本地不存在时，才丢进线程池下载
                    if not ego_pose_file.exists():
                        futures.append(executor.submit(self.ego_info_manager.download_ego_pose, aid))
                
                if futures:
                    self.logger.info(f"发现 {len(futures)} 个样本需要从云端下载车辆信息，启动 {max_workers} 并发...")
                    # 带有进度条的等待
                    for future in tqdm(as_completed(futures), total=len(futures), desc="下载 ego_info"):
                        pass # 内部已经处理了异常，这里只需等待全部完成
                else:
                    self.logger.info("所有样本的车辆信息均已在本地缓存，无需下载！")
                    
            self.logger.info("车辆信息准备完毕！")
            self.logger.info("=" * 60 + "\n")
        # ===============================================================
        
        if self.dataset_type == "train":
            # 训练集：只生成JSON格式
            dataset_items = []
            for sample in sampled_samples:
                item = self._create_train_item(sample)
                dataset_items.append(item)
            
            # 设置输出文件名（包含摄像头和车辆信息标识）
            self.output_path = self.output_dir / \
                f"train_{self.dataset_config['name']}_{camera_suffix}{ego_info_suffix}_{total_samples}.json"
            
            # 写入JSON
            with open(self.output_path, 'w', encoding='utf-8') as f:
                json.dump(dataset_items, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"\n输出文件: {self.output_path}")
        
        else:
            # 测试集：生成两个文件
            # 1. JSON格式（不带label，用于评测）
            dataset_items_json = []
            for sample in sampled_samples:
                item = self._create_test_item(sample)
                dataset_items_json.append(item)

            # 2. JSONL格式（带label，用于分析）
            dataset_items_jsonl = []
            for sample in sampled_samples:
                item = self._create_test_item_with_label(sample)
                dataset_items_jsonl.append(item)
            
            # 设置输出文件名（包含摄像头和车辆信息标识）
            self.output_path = self.output_dir / \
                f"test_{self.dataset_config['name']}_{camera_suffix}{ego_info_suffix}_{total_samples}.json"
            self.output_path_jsonl = self.output_dir / \
                f"test_{self.dataset_config['name']}_{camera_suffix}{ego_info_suffix}_{total_samples}.jsonl"
            
            # 写入JSON（不带label）
            with open(self.output_path, 'w', encoding='utf-8') as f:
                json.dump(dataset_items_json, f, ensure_ascii=False, indent=2)
            
            # 写入JSONL（带label）
            with open(self.output_path_jsonl, 'w', encoding='utf-8') as f:
                for item in dataset_items_jsonl:
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")
            
            self.logger.info(f"\n输出文件:")
            self.logger.info(f"  JSON (评测用): {self.output_path}")
            self.logger.info(f"  JSONL (分析用): {self.output_path_jsonl}")
        
        self.logger.info(f"\n" + "=" * 60)
        self.logger.info(f"数据集构建完成")
        self.logger.info(f"总样本数: {total_samples}")
        self.logger.info(f"=" * 60)
        
        # 打印类别分布
        label_counts = defaultdict(int)
        for sample in sampled_samples:
            label_counts[sample["label"]] += 1
        
        self.logger.info(f"\n类别分布:")
        for label, count in sorted(label_counts.items()):
            # 查找类别描述
            description = "未知"
            for class_cfg in self.dataset_config["classes"]:
                if class_cfg["label"] == label:
                    description = class_cfg.get("description", "未知")
                    break
            
            self.logger.info(f"  类别 {label} ({description}): {count} 个")


def main():
    parser = argparse.ArgumentParser(
        description="构建训练/测试数据集（支持摄像头和车辆信息）"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    
    # ========== 摄像头选择参数 ==========
    parser.add_argument(
        "--cameras",
        type=str,
        nargs='+',
        choices=['front', 'back', 'left', 'right'],
        default=None,
        help="使用的摄像头（front, back, left, right）。示例: --cameras left right"
    )
    # =========================================
    
    # ========== 车辆信息参数 ==========
    parser.add_argument(
        "--use-ego-info",
        action="store_true",
        help="启用车辆信息增强（速度、加速度等）"
    )
    
    parser.add_argument(
        "--ego-info-fields",
        type=str,
        nargs='+',
        default=None,
        help="选择启用的车辆信息字段。示例: --ego-info-fields velocity acc_long"
    )
    
    parser.add_argument(
        "--ego-info-cache",
        type=str,
        default=None,
        help="ego_pose.json 缓存目录（覆盖配置文件）"
    )
    # ==================================
    
    args = parser.parse_args()
    
    config = ConfigManager(args.config)
    
    # 如果命令行指定了字段，需要在创建 builder 之前修改配置
    if args.ego_info_fields:
        # 临时修改配置
        if not hasattr(config, 'config'):
            raise AttributeError("ConfigManager 缺少 config 属性")
        
        if "ego_info" not in config.config:
            config.config["ego_info"] = {}
        
        config.config["ego_info"]["enabled_fields"] = args.ego_info_fields
    
    # 如果命令行指定了缓存目录
    if args.ego_info_cache:
        if "ego_info" not in config.config:
            config.config["ego_info"] = {}
        
        config.config["ego_info"]["cache_dir"] = args.ego_info_cache
    
    builder = DatasetBuilder(
        config, 
        args.dataset, 
        use_cameras=args.cameras,
        use_ego_info=args.use_ego_info
    )
    builder.build_dataset()


if __name__ == "__main__":
    main()