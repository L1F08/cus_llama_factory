"""
Pipeline编排脚本
支持顺序执行或单独运行各个步骤
"""
import argparse
import sys
import time
from pathlib import Path

from utils import ConfigManager, setup_logger


class PipelineRunner:
    """Pipeline执行器"""
    
    STEPS = ["download_images", "make_video", "scan_videos", "build_dataset"]
    STEP_MODULES = {
        "download_images": "download_images",
        "make_video": "make_video",
        "scan_videos": "scan_videos",
        "build_dataset": "build_dataset"
    }
    
    def __init__(self, config_path: str, dataset_name: str):
        self.config = ConfigManager(config_path)
        self.dataset_name = dataset_name
        self.logger = setup_logger("PipelineRunner")
    
    def _run_step(self, step: str, **kwargs) -> bool:
        """运行单个步骤"""
        if step not in self.STEPS:
            self.logger.error(f"未知步骤: {step}")
            return False
        
        module_name = self.STEP_MODULES[step]
        
        self.logger.info(f"\n{'=' * 70}")
        self.logger.info(f" 运行步骤: {step} ({module_name})")
        self.logger.info(f"{'=' * 70}\n")
        
        start_time = time.time()
        
        try:
            # # 动态导入模块
            # if step == "download_images":
            #     from download_images import ImageDownloader
            #     runner = ImageDownloader(self.config, self.dataset_name)
            #     runner.download_all()
            # 动态导入模块
            if step == "download_images":
                from download_images import ImageDownloader
                # 获取 kwargs 中的 retry_failed，默认 False
                retry_failed = kwargs.get("retry_failed", False)
                runner = ImageDownloader(self.config, self.dataset_name, retry_failed=retry_failed)
                runner.download_all()
            elif step == "make_video":
                from make_video import VideoMaker
                runner = VideoMaker(self.config, self.dataset_name)
                runner.make_all_videos()
            
            elif step == "scan_videos":
                from scan_videos import VideoScanner
                runner = VideoScanner(self.config, self.dataset_name)
                runner.scan_all_videos()
            
            elif step == "build_dataset":
                from build_dataset import DatasetBuilder
                runner = DatasetBuilder(self.config, self.dataset_name)
                runner.build_dataset()
            
            elapsed = time.time() - start_time
            self.logger.info(f"\n 步骤 {step} 完成，耗时: {elapsed:.2f}秒\n")
            return True
        
        except Exception as e:
            self.logger.error(f"\n 步骤 {step} 失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def run_all(self):
        """运行完整pipeline"""
        self.logger.info(f"\n{'=' * 70}")
        self.logger.info(f" 运行完整Pipeline: {self.dataset_name}")
        self.logger.info(f"{'=' * 70}\n")
        
        total_start = time.time()
        
        for step in self.STEPS:
            success = self._run_step(step)
            if not success:
                self.logger.error(f"\nPipeline在步骤 {step} 失败，停止执行")
                return False
        
        total_elapsed = time.time() - total_start
        
        self.logger.info(f"\n{'=' * 70}")
        self.logger.info(f" Pipeline全部完成！")
        self.logger.info(f"总耗时: {total_elapsed:.2f}秒 ({total_elapsed/60:.2f}分钟)")
        self.logger.info(f"{'=' * 70}\n")
        
        return True
    
    def run_from_step(self, start_step: str):
        """从指定步骤开始运行"""
        if start_step not in self.STEPS:
            self.logger.error(f"未知步骤: {start_step}")
            return False
        
        start_idx = self.STEPS.index(start_step)
        steps_to_run = self.STEPS[start_idx:]
        
        self.logger.info(f"\n{'=' * 70}")
        self.logger.info(f" 从步骤 {start_step} 开始运行")
        self.logger.info(f"将执行: {', '.join(steps_to_run)}")
        self.logger.info(f"{'=' * 70}\n")
        
        total_start = time.time()
        
        for step in steps_to_run:
            success = self._run_step(step)
            if not success:
                self.logger.error(f"\nPipeline在步骤 {step} 失败，停止执行")
                return False
        
        total_elapsed = time.time() - total_start
        
        self.logger.info(f"\n{'=' * 70}")
        self.logger.info(f" Pipeline完成！")
        self.logger.info(f"总耗时: {total_elapsed:.2f}秒 ({total_elapsed/60:.2f}分钟)")
        self.logger.info(f"{'=' * 70}\n")
        
        return True
    
    def run_single_step(self, step: str):
        """运行单个步骤"""
        return self._run_step(step)


def main():
    parser = argparse.ArgumentParser(
        description="视频处理Pipeline编排器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 运行完整pipeline（包含重试失败项）
  python run_all.py --dataset train_6class --retry-failed

  # 单独运行下载步骤并重试失败项
  python run_all.py --dataset train_6class --step download_images --retry-failed

可用步骤:
  download_images - 下载autoscene图片
  make_video      - 生成对齐的视频
  scan_videos     - 扫描视频质量
  build_dataset   - 构建数据集
        """
    )
    
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="数据集名称（config.yaml中的datasets配置）"
    )
    
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="配置文件路径"
    )
    
    parser.add_argument(
        "--step",
        type=str,
        choices=PipelineRunner.STEPS,
        help="单独运行指定步骤"
    )
    
    parser.add_argument(
        "--from-step",
        type=str,
        choices=PipelineRunner.STEPS,
        help="从指定步骤开始运行"
    )

    parser.add_argument(
        "--retry-failed",
        action="store_true",
        help="[download_images 步骤专用] 是否尝试重新下载之前因为缺少时间戳而生成视频失败的样本"
    )

    args = parser.parse_args()
    
    # 1. 检查参数冲突
    if args.step and args.from_step:
        print("错误: --step 和 --from-step 不能同时使用")
        sys.exit(1)
    
    # 2. 创建 runner
    runner = PipelineRunner(args.config, args.dataset)
    
    # 3. 核心执行逻辑 (统一调用 _run_step 以支持 retry_failed 参数)
    success = True
    
    if args.step:
        # 单步运行
        success = runner._run_step(args.step, retry_failed=args.retry_failed)
    
    elif args.from_step:
        # 从某一步开始运行
        start_idx = runner.STEPS.index(args.from_step)
        for step in runner.STEPS[start_idx:]:
            if not runner._run_step(step, retry_failed=args.retry_failed):
                success = False
                break
    
    else:
        # 运行完整 pipeline
        for step in runner.STEPS:
            if not runner._run_step(step, retry_failed=args.retry_failed):
                success = False
                break
    
    # 4. 退出
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()