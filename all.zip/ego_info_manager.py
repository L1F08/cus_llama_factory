"""
负责下载、解析 ego 相关数据（ego_pose.json 等）并生成信息 prompt
支持可扩展的字段配置，可以任意添加新字段

当前支持的字段:
- velocity: 速度
- acc_long: 纵向加速度
- acc_lat: 侧向加速度
- steer: 方向盘转角

未来可扩展的字段示例:
- lane_distance: 到车道中心线的距离
- lane_offset: 车道偏移量
- heading_error: 航向角误差
- distance_to_front: 与前车距离
- etc.
"""

import json
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Set, Any, Callable
from dataclasses import dataclass, field
from collections import defaultdict
import time


# ==================== 字段注册表 ====================
class FieldRegistry:
    """字段注册表 - 用于管理所有可用字段"""
    
    def __init__(self):
        self._fields = {}
    
    def register(
        self,
        name: str,
        display_name: str,
        unit: str,
        description: str,
        extractor: Callable,
        **metadata
    ):
        """
        注册一个新字段
        
        Args:
            name: 字段名称（用于配置）
            display_name: 显示名称（用于prompt）
            unit: 单位
            description: 描述
            extractor: 提取函数 (pose_data) -> Optional[float]
            **metadata: 其他元数据
        """
        self._fields[name] = {
            "name": name,
            "display_name": display_name,
            "unit": unit,
            "description": description,
            "extractor": extractor,
            "metadata": metadata
        }
    
    def get(self, name: str) -> Optional[Dict]:
        """获取字段定义"""
        return self._fields.get(name)
    
    def get_all(self) -> Dict[str, Dict]:
        """获取所有字段"""
        return self._fields.copy()
    
    def list_names(self) -> List[str]:
        """列出所有字段名称"""
        return list(self._fields.keys())


# 创建全局注册表
FIELD_REGISTRY = FieldRegistry()


# ==================== 内置字段定义 ====================
def _extract_velocity(pose: Dict) -> Optional[float]:
    """提取速度"""
    return pose.get('chassis_velocity')


def _extract_acc_long(pose: Dict) -> Optional[float]:
    """提取纵向加速度"""
    acc = pose.get('acceleration')
    if acc and len(acc) >= 1:
        return acc[0]
    return None


def _extract_acc_lat(pose: Dict) -> Optional[float]:
    """提取侧向加速度"""
    acc = pose.get('acceleration')
    if acc and len(acc) >= 2:
        return acc[1]
    return None


def _extract_steer(pose: Dict) -> Optional[float]:
    """提取方向盘转角"""
    return pose.get('chassis_steer_angle')


# 注册内置字段
FIELD_REGISTRY.register(
    name="velocity",
    display_name="平均速度",
    unit="m/s",
    description="",
    extractor=_extract_velocity,
    source="ego_pose.json"
)

FIELD_REGISTRY.register(
    name="acc_long",
    display_name="平均纵向加速度",
    unit="m/s²",
    description="正值表示加速，负值表示减速",
    extractor=_extract_acc_long,
    source="ego_pose.json"
)

FIELD_REGISTRY.register(
    name="acc_lat",
    display_name="平均侧向加速度",
    unit="m/s²",
    description="左正右负",
    extractor=_extract_acc_lat,
    source="ego_pose.json"
)

FIELD_REGISTRY.register(
    name="steer",
    display_name="平均方向盘转角",
    unit="rad",
    description="左正右负",
    extractor=_extract_steer,
    source="ego_pose.json"
)


# ==================== 预留字段示例（注释） ====================
# 未来可以通过以下方式添加新字段：

# def _extract_lane_distance(pose: Dict) -> Optional[float]:
#     """提取到车道中心线的距离"""
#     return pose.get('lane_center_distance')
# 
# FIELD_REGISTRY.register(
#     name="lane_distance",
#     display_name="到车道中心线距离",
#     unit="m",
#     description="正值表示在右侧，负值表示在左侧",
#     extractor=_extract_lane_distance,
#     source="ego_pose.json"  # 或其他数据源
# )

# def _extract_lane_offset(pose: Dict) -> Optional[float]:
#     """提取车道偏移量"""
#     return pose.get('lane_offset')
# 
# FIELD_REGISTRY.register(
#     name="lane_offset",
#     display_name="车道偏移量",
#     unit="m",
#     description="相对于车道中心的偏移",
#     extractor=_extract_lane_offset,
#     source="lane_data.json"
# )


# ==================== 配置类 ====================
@dataclass
class EgoInfoConfig:
    """EgoInfo 配置"""
    cache_dir: Path
    interval_seconds: float = 0.5
    
    # ========== 字段选择（核心配置）==========
    # 启用的字段集合，支持注册表中的任意字段
    enabled_fields: Set[str] = field(default_factory=lambda: {
        "velocity", "acc_long", "acc_lat", "steer"
    })
    # ==========================================
    
    # 下载配置
    download_enabled: bool = True
    max_workers: int = 160
    
    # Prompt 配置
    prompt_header: str = ""
    no_data_message: str = "此段视频无可用车辆信息"
    
    # 存储桶配置
    yw_bucket_url: str = ""
    yw_ak: str = ""
    yw_sk: str = ""
    yd_bucket_url: str = ""
    yd_ak: str = ""
    yd_sk: str = ""
    
    def __post_init__(self):
        """验证配置"""
        # 验证字段是否都在注册表中
        available_fields = set(FIELD_REGISTRY.list_names())
        invalid_fields = self.enabled_fields - available_fields
        
        if invalid_fields:
            raise ValueError(
                f"未知的字段: {invalid_fields}\n"
                f"可用字段: {available_fields}"
            )


# ==================== 统计数据类 ====================
@dataclass
class IntervalStats:
    """时间区间统计"""
    start_time: float
    end_time: float
    
    # 动态存储所有字段的值
    field_values: Dict[str, Optional[float]] = field(default_factory=dict)
    
    def set_value(self, field_name: str, value: Optional[float]):
        """设置字段值"""
        self.field_values[field_name] = value
    
    def get_value(self, field_name: str) -> Optional[float]:
        """获取字段值"""
        return self.field_values.get(field_name)
    
    def to_string(self, enabled_fields: List[str]) -> str:
        """
        根据启用的字段顺序生成字符串
        
        Args:
            enabled_fields: 启用的字段列表（保持顺序）
        
        Returns:
            格式化的字符串，如 "5.2,0.3,-0.1,0.05"
        """
        parts = []
        
        for field_name in enabled_fields:
            value = self.field_values.get(field_name)
            if value is not None:
                parts.append(f"{value:.1f}")
            else:
                parts.append("None")
        
        return ",".join(parts)


# ==================== 核心管理器类 ====================
class EgoInfoManager:
    """EgoInfo 管理器 - 支持可扩展的字段配置"""
    
    def __init__(self, config: EgoInfoConfig):
        self.config = config
        self.cache_dir = config.cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 验证所有启用的字段都已注册
        for field_name in config.enabled_fields:
            if not FIELD_REGISTRY.get(field_name):
                raise ValueError(f"未注册的字段: {field_name}")
    
    def download_ego_pose(self, autoscene_id: str) -> bool:
        """下载 ego_pose.json"""
        try:
            from download_data import download_autoscenes_data_by_devkit
            
            download_paths = ["v1.1.6/ego_pose.json"]
            
            success = download_autoscenes_data_by_devkit(
                autoscene_id,
                download_paths,
                self.cache_dir,
                is_guiyang=False,
                yw_bucket_url=self.config.yw_bucket_url,
                yw_ak=self.config.yw_ak,
                yw_sk=self.config.yw_sk,
                yd_bucket_url=self.config.yd_bucket_url,
                yd_ak=self.config.yd_ak,
                yd_sk=self.config.yd_sk,
            )
            
            return success
        
        except Exception:
            return False
    
    def parse_ego_pose(self, ego_pose_file: Path) -> List[Dict]:
        """解析 ego_pose.json"""
        with open(ego_pose_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return sorted(data, key=lambda x: x['timestamp'])
    
    def calculate_interval_stats(
        self,
        ego_poses: List[Dict],
        start_time: int,
        end_time: int
    ) -> IntervalStats:
        """
        计算指定时间区间内的统计值
        使用注册表中的提取器，支持任意字段
        """
        # 按字段收集数据
        field_data = defaultdict(list)
        
        enabled_fields = self.config.enabled_fields
        
        for pose in ego_poses:
            timestamp = pose['timestamp']
            
            if start_time <= timestamp < end_time:
                # 遍历所有启用的字段
                for field_name in enabled_fields:
                    field_def = FIELD_REGISTRY.get(field_name)
                    if field_def:
                        extractor = field_def['extractor']
                        value = extractor(pose)
                        if value is not None:
                            field_data[field_name].append(value)
        
        # 计算平均值
        stats = IntervalStats(start_time=start_time, end_time=end_time)
        
        for field_name in enabled_fields:
            values = field_data.get(field_name, [])
            if values:
                avg_value = sum(values) / len(values)
                stats.set_value(field_name, avg_value)
            else:
                stats.set_value(field_name, None)
        
        return stats
    
    def generate_field_description(self) -> str:
        descriptions = []
        
        # 保持字段顺序（按照配置中的顺序）
        for field_name in sorted(self.config.enabled_fields):
            field_def = FIELD_REGISTRY.get(field_name)
            if field_def:
                desc_parts = [field_def['display_name']]
                
                # 添加单位
                if field_def['unit']:
                    desc_parts.append(f"({field_def['unit']})")
                
                # 添加描述（如果有）
                if field_def['description']:
                    desc_parts.append(f"，{field_def['description']}")
                
                descriptions.append("".join(desc_parts))
        
        return "，".join(descriptions)
    
    def generate_prompt(self, ego_pose_file: Path) -> str:
        """
        生成车辆信息 prompt
        根据启用的字段动态生成
        """
        try:
            ego_poses = self.parse_ego_pose(ego_pose_file)
            
            if not ego_poses:
                return self.config.no_data_message + "\n"
            
            start_timestamp = ego_poses[0]['timestamp']
            end_timestamp = ego_poses[-1]['timestamp']
            interval_us = int(self.config.interval_seconds * 1e6)
            
            # 收集所有时间段的统计
            interval_stats_list = []
            current_time = start_timestamp
            time_counter = 0.0
            
            while current_time < end_timestamp:
                next_time = current_time + interval_us
                
                stats = self.calculate_interval_stats(
                    ego_poses, current_time, next_time
                )
                
                stats.start_time = time_counter
                stats.end_time = time_counter + self.config.interval_seconds
                
                interval_stats_list.append(stats)
                
                current_time = next_time
                time_counter += self.config.interval_seconds
            
            if not interval_stats_list:
                return self.config.no_data_message + "\n"
            
            # 生成统计字符串（保持字段顺序）
            enabled_fields_list = sorted(self.config.enabled_fields)
            stats_parts = []
            
            for stats in interval_stats_list:
                stats_str = stats.to_string(enabled_fields_list)
                if stats_str:
                    # stats_parts.append(
                    #     f"{stats.start_time:.2f}~{stats.end_time:.2f}s:{stats_str}"
                    # )
                    stats_parts.append(stats_str)
            
            if not stats_parts:
                return self.config.no_data_message + "\n"
            
            stats_info = " ".join(stats_parts)
            
            # 生成字段说明
            field_description = self.generate_field_description()
            
            # 生成完整 prompt
            full_prompt = (
                self.config.prompt_header + f"{field_description}:"
                f"{stats_info}\n" + "结合车辆信息, "
            )
            
            return full_prompt
        
        except Exception as e:
            return self.config.no_data_message + "\n"
    
    def get_prompt(self, autoscene_id: str) -> str:
    # === 添加进度监控（简化版）===
        if not hasattr(self, '_progress'):
            self._progress = {'total': 0, 'cached': 0, 'downloaded': 0, 'failed': 0}
        
        self._progress['total'] += 1
        
        # 每500个打印一次，不计算速度
        if self._progress['total'] % 5 == 0:
            print(f"\n[EgoInfo进度] "
                f"已处理: {self._progress['total']}, "
                f"缓存: {self._progress['cached']}, "
                f"下载: {self._progress['downloaded']}, "
                f"失败: {self._progress['failed']}")
        # === 进度监控结束 ===
        ego_pose_file = self.cache_dir / autoscene_id / "v1.1.6" / "ego_pose.json"
        
        # 检查缓存
        if ego_pose_file.exists():
            return self.generate_prompt(ego_pose_file)
        
        # 下载（如果启用）
        if self.config.download_enabled:
            success = self.download_ego_pose(autoscene_id)
            
            if success and ego_pose_file.exists():
                return self.generate_prompt(ego_pose_file)
        
        # 无数据
        return self.config.no_data_message + "\n"
    
    def get_enabled_fields(self) -> List[str]:
        """获取启用的字段列表"""
        return sorted(self.config.enabled_fields)
    
    def get_field_info(self, field_name: str) -> Optional[Dict]:
        """获取字段信息"""
        return FIELD_REGISTRY.get(field_name)
    
    def list_available_fields(self) -> List[str]:
        """列出所有可用字段"""
        return FIELD_REGISTRY.list_names()


# ==================== 工厂函数 ====================
def create_ego_info_manager_from_config(config_dict: Dict) -> EgoInfoManager:
    # 处理字段配置
    enabled_fields = config_dict.get("enabled_fields", ["velocity", "acc_long", "acc_lat", "steer"])
    if isinstance(enabled_fields, list):
        enabled_fields = set(enabled_fields)
    
    ego_info_cfg = EgoInfoConfig(
        cache_dir=Path(config_dict.get("cache_dir", "/tmp/ego_info_cache")),
        interval_seconds=config_dict.get("interval_seconds", 0.5),
        enabled_fields=enabled_fields,
        download_enabled=config_dict.get("download", {}).get("enabled", True),
        max_workers=config_dict.get("download", {}).get("max_workers", 60),
        prompt_header=config_dict.get("prompt", {}).get("header", ""),
        no_data_message=config_dict.get("prompt", {}).get("no_data_message", "此段视频无可用车辆信息"),
        yw_bucket_url=config_dict.get("storage", {}).get("guiyang", {}).get("url", ""),
        yw_ak=config_dict.get("storage", {}).get("guiyang", {}).get("ak", ""),
        yw_sk=config_dict.get("storage", {}).get("guiyang", {}).get("sk", ""),
        yd_bucket_url=config_dict.get("storage", {}).get("yd", {}).get("url", ""),
        yd_ak=config_dict.get("storage", {}).get("yd", {}).get("ak", ""),
        yd_sk=config_dict.get("storage", {}).get("yd", {}).get("sk", ""),
    )
    
    return EgoInfoManager(ego_info_cfg)


# ==================== 辅助函数 ====================
def register_custom_field(
    name: str,
    display_name: str,
    unit: str,
    description: str,
    extractor: Callable,
    **metadata
):
    """
    注册自定义字段（用户可调用）
    
    Args:
        name: 字段名称
        display_name: 显示名称
        unit: 单位
        description: 描述
        extractor: 提取函数 (pose_data) -> Optional[float]
        **metadata: 其他元数据
    
    Example:
        def extract_custom_field(pose):
            return pose.get('custom_field_key')
        
        register_custom_field(
            name="custom_field",
            display_name="自定义字段",
            unit="单位",
            description="描述",
            extractor=extract_custom_field,
            source="custom_data.json"
        )
    """
    FIELD_REGISTRY.register(
        name=name,
        display_name=display_name,
        unit=unit,
        description=description,
        extractor=extractor,
        **metadata
    )


def list_available_fields() -> List[str]:
    """列出所有可用字段"""
    return FIELD_REGISTRY.list_names()


def get_field_info(field_name: str) -> Optional[Dict]:
    """获取字段信息"""
    return FIELD_REGISTRY.get(field_name)


# ==================== 使用示例（在模块末尾，注释掉）====================
"""
# 使用示例1: 使用默认字段
config = {
    "cache_dir": "/path/to/cache",
    "interval_seconds": 0.5,
    "enabled_fields": ["velocity", "acc_long", "acc_lat", "steer"],
    "storage": {...},
    "download": {...},
    "prompt": {...}
}

manager = create_ego_info_manager_from_config(config)
prompt = manager.get_prompt("autoscene_xxx")


# 使用示例2: 只使用速度
config = {
    "cache_dir": "/path/to/cache",
    "enabled_fields": ["velocity"],
    ...
}

manager = create_ego_info_manager_from_config(config)


# 使用示例3: 添加自定义字段
def extract_lane_distance(pose: Dict) -> Optional[float]:
    '''提取到车道中心线的距离'''
    return pose.get('lane_center_distance')

register_custom_field(
    name="lane_distance",
    display_name="到车道中心线距离",
    unit="m",
    description="正值在右侧，负值在左侧",
    extractor=extract_lane_distance,
    source="lane_data.json"
)

# 然后在配置中启用
config = {
    "enabled_fields": ["velocity", "lane_distance"],
    ...
}


# 使用示例4: 查询可用字段
available_fields = list_available_fields()
print(f"可用字段: {available_fields}")

field_info = get_field_info("velocity")
print(f"速度字段信息: {field_info}")
"""